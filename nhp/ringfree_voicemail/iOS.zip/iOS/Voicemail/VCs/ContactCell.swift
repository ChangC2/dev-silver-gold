//
//  ContactCell.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/9/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit

class ContactCell: UITableViewCell {

    @IBOutlet var vBack: UIView!
    @IBOutlet var lName: UILabel!
    @IBOutlet var lPhoneNumber: UILabel!
    @IBOutlet weak var lEmail: UILabel!
    @IBOutlet weak var lGroup: UILabel!
    
    var contact = MContacts()
    
    var delegate: ClickDelegate?
    var ind = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        vBack.setCornerRadius(radius: 12)
        vBack.setBorder(color: .lightGray, width: 1)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func generateCell(contact: MContacts){
        self.contact = contact
        lName.text = contact.name
        lPhoneNumber.text = "Mobile Number : \(contact.phone)"
        lEmail.text = "Email Address : \(contact.email)"
        lGroup.text = "Group : \(contact.group_name)"
    }
    
    @IBAction func bEditTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 0)
    }
    
    @IBAction func bDeleteTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 1)
    }

}
