//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire

class LogsVC: BaseVC {
    
    @IBOutlet weak var tableView: UITableView!
    
    var logs = [MLog]()
    
    var orderId = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        apiCallForGetLogs()
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func viewContent(index: Int){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "AudioPlayerVC") as?  AudioPlayerVC{
            var order = MOrder()
            order.type = logs[index].type
            order.record_name = logs[index].record_name
            order.url = logs[index].url
            order.content = logs[index].content
            vc.order = order
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    
    func apiCallForGetLogs() {
        GF.showLoading()
        let params: Parameters = ["order_id": orderId]
        
        API.postRequest(api: API.getMailLogs, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    if let arry = dict["mail_logs"] as? [NSDictionary]{
                        for item in arry{
                            self.logs.append(MLog.init(dict: item))
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
}

extension LogsVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return logs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LogCell") as! LogCell
        cell.selectionStyle = .none
        cell.delegate = self
        cell.index = indexPath.row
        cell.generateCell(log: logs[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}

extension LogsVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        switch (type){
        case 0://Play Audio
            viewContent(index: index)
            break
        default:
            break
        }
    }
}


