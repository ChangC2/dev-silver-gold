//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire

class ScriptsVC: BaseVC {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var lEmpty: UILabel!
    
    var scriptings = [MScript]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bottomSheetTransitioningDelegate = BottomSheetTransitioningDelegate(
            contentHeights: [330, UIScreen.main.bounds.size.height - 200],
            presentationDelegate: self
        )
        apiCallForGetScript()
    }
    
    
    func setUI(){
        tableView.reloadData()
        if scriptings.count == 0{
            lEmpty.showView()
            onEdit()
        }else{
            lEmpty.hideView()
        }
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func bAddScriptTapped(_ sender: UIButton) {
        onEdit()
    }
    
    func onEdit(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "EditScriptVC") as?  EditScriptVC{
            //vc.script = scriptings[index]
            vc.delegate = self
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    
    func refreshTable(index: Int, script: MScript){
        if (index == -1){
            scriptings.insert(script, at: 0)
        }else{
            scriptings[index].name = script.name
            scriptings[index].salutation = script.salutation
            scriptings[index].content = script.content
        }
        tableView.reloadData()
    }
    
    func apiCallForGetScript() {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken()]
        
        API.postRequest(api: API.getScripts, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    if let arry = dict["scripts"] as? [NSDictionary]{
                        for item in arry{
                            self.scriptings.append(MScript.init(dict: item))
                        }
                    }
                    DispatchQueue.main.async {
                        self.setUI()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForDeleteScript(index: Int) {
        GF.showLoading()
        let params: Parameters = ["id": "\(scriptings[index].id)"]
        
        API.postRequest(api: API.deleteScript, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    self.scriptings.remove(at: index)
                    DispatchQueue.main.async {
                        self.setUI()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
}

extension ScriptsVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return scriptings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ScriptCell") as! ScriptCell
        cell.selectionStyle = .none
        cell.delegate = self
        cell.ind = indexPath.row
        cell.generateCell(script: scriptings[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}


extension ScriptsVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        switch (type){
        case 1://Edit Script
            let stb = UIStoryboard(name: "Main", bundle: nil)
            if let vc = stb.instantiateViewController(withIdentifier: "EditScriptVC") as?  EditScriptVC{
                vc.script = scriptings[index]
                vc.index = index
                vc.delegate = self
                self.present(vc, animated: true, completion: nil)
            }
            break
        case 2://Delete Script
            apiCallForDeleteScript(index: index)
            break
        default:
            break
        }
    }
}

extension ScriptsVC: RefreshScriptDelegate{
    func refresh(index: Int, script: MScript){
        refreshTable(index: index, script: script)
    }
}

