//
//  LoginVC.swift
//  seemesave
//
//  Created by XiaoYan on 6/16/22.
//

import UIKit
import CountryPickerView
import Alamofire

class SignUpVC: BaseVC {
    
    @IBOutlet weak var vName: UIView!
    @IBOutlet weak var vEmail: UIView!
    @IBOutlet weak var vPass: UIView!
    @IBOutlet var vRePass: UIView!
    
    @IBOutlet weak var tName: UITextField!
    @IBOutlet weak var tEmail: UITextField!
    @IBOutlet weak var tPass: UITextField!
    @IBOutlet var tRePass: UITextField!
    
    @IBOutlet weak var bAgree: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    
    
    @IBAction func bAgreeTapped(_ sender: UIButton) {
        bAgree.isSelected = !bAgree.isSelected
    }
    
    @IBAction func bTermsTapped(_ sender: UIButton) {
        GF.openLink(urlString: "https://seemesave.com/terms")
    }
   
    @IBAction func bSignUpTapped(_ sender: UIButton) {
        apiCallForRegisterWithEmail()
    }
    
    @IBAction func bSignInTapped(_ sender: UIButton) {
        GF.goLoginVC()
    }
    
    func initUI(){
      
        vName.setBorder(color: .lightGray, width: 1)
        vName.setCornerRadius(radius: 10)
        
        vEmail.setBorder(color: .lightGray, width: 1)
        vEmail.setCornerRadius(radius: 10)
        
        vPass.setBorder(color: .lightGray, width: 1)
        vPass.setCornerRadius(radius: 10)
        
        vRePass.setBorder(color: .lightGray, width: 1)
        vRePass.setCornerRadius(radius: 10)
    }
    
    
    func goOTPVC(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "OtpVC") as?  OtpVC{
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}


//***************************************//
//           Mark - Extentions           //
//***************************************//


//***************************************//
//         Mark - API Call               //
//***************************************//
extension SignUpVC{
    
    func apiCallForRegisterWithEmail() {
        if !tEmail.isValidEmail || tPass.isEmpty || tName.isEmpty{
            GF.showToastMissingParam()
            return
        }
        
        if !tPass.text!.elementsEqual(tRePass.text!){
            GF.showToast(msg: "Mismatch Password")
            return
        }

        let params: Parameters = ["accountname": "\(tName.text!)",
                                  "email": tEmail.text!,
                                  "password" : tPass.text!]

        GF.showLoading()
        API.postRequest(api: API.register_account, params: params, completion: { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: "We have sent mail to your email address to activate your account", buttonTitles: ["OK"], viewController: self, completion: {result in
                            userDefault.set(dict.parseString(param: "token"), forKey: C.TOKEN)
                            self.goOTPVC()
                        })
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
}
