//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire

class RecordingsVC: BaseVC {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var lEmpty: UILabel!
    
    var recordings = [MRecording]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bottomSheetTransitioningDelegate = BottomSheetTransitioningDelegate(
            contentHeights: [330, UIScreen.main.bounds.size.height - 200],
            presentationDelegate: self
        )
        apiCallForGetRecording()
    }
    
    
    func setUI(){
        tableView.reloadData()
        if recordings.count == 0{
            lEmpty.showView()
            onRecord()
        }else{
            lEmpty.hideView()
        }
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func bAddRecordingTapped(_ sender: UIButton) {
        onRecord()
    }
    
    func onRecord(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "AudioRecordVC") as?  AudioRecordVC{
            //vc.record = recordings[index]
            vc.delegate = self
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    
    
    func playAudio(index: Int){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "AudioPlayerVC") as?  AudioPlayerVC{
            var order = MOrder()
            order.type = 0
            order.url = recordings[index].url
            order.record_name = recordings[index].name
            vc.order = order
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    func refreshTable(index: Int, record: MRecording){
        if (index == -1){
            recordings.insert(record, at: 0)
        }else{
            recordings[index].name = record.name
            recordings[index].url = record.url
        }
        tableView.reloadData()
    }
    
    func apiCallForGetRecording() {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken()]
        
        API.postRequest(api: API.getRecordings, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    if let arry = dict["recordings"] as? [NSDictionary]{
                        for item in arry{
                            self.recordings.append(MRecording.init(dict: item))
                        }
                    }
                    DispatchQueue.main.async {
                        self.setUI()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForDeleteRecording(index: Int) {
        GF.showLoading()
        let params: Parameters = ["id": "\(recordings[index].id)"]
        
        API.postRequest(api: API.deleteRecording, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    self.recordings.remove(at: index)
                    DispatchQueue.main.async {
                        self.setUI()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
}

extension RecordingsVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recordings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecordingCell") as! RecordingCell
        cell.selectionStyle = .none
        cell.delegate = self
        cell.ind = indexPath.row
        cell.generateCell(record: recordings[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}


extension RecordingsVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        switch (type){
        case 0://Play Audio
            playAudio(index: index)
            break
        case 1://Edit Recording
            let stb = UIStoryboard(name: "Main", bundle: nil)
            if let vc = stb.instantiateViewController(withIdentifier: "AudioRecordVC") as?  AudioRecordVC{
                vc.record = recordings[index]
                vc.index = index
                vc.delegate = self
                self.present(vc, animated: true, completion: nil)
            }
            break
        case 2://Delete Recording
            apiCallForDeleteRecording(index: index)
            break
        default:
            break
        }
    }
}

extension RecordingsVC: RefreshRecordingDelegate{
    func refresh(index: Int, record: MRecording){
        refreshTable(index: index, record: record)
    }
}

