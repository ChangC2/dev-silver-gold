import UIKit

class SplashVC: BaseVC {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
            if userDefault.bool(forKey: C.IS_LOGINED){
                GF.goMainVC()
            }else{
                GF.goLoginVC()
            }
        })
    }
}
