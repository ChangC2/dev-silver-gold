//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire
import Contacts

class ContactDetailsVC: BaseVC {
    
    @IBOutlet weak var vTabContainer: UIView!
    @IBOutlet var bManual: UIButton!
    @IBOutlet var bImport: UIButton!
    
    @IBOutlet weak var vContactGroupSpinner: UIView!
    @IBOutlet weak var lContactGroupSpinnerValue: UILabel!
    @IBOutlet weak var vManual: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var vEmail: UIView!
    @IBOutlet weak var vName: UIView!
    @IBOutlet weak var vPhone: UIView!
    
    @IBOutlet weak var tEmail: UITextField!
    @IBOutlet weak var tName: UITextField!
    @IBOutlet weak var tPhone: UITextField!
    
    var groups = [MContactGroup]()
    var contacts = [MContacts]()
    var contact: MContacts?
    var groupId = ""
    var type = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        apiCallForGetContactGroups()
        getContactsInfo()
    }
    
    func initUI(){
        vContactGroupSpinner.setCornerRadius(radius: 8)
        vContactGroupSpinner.setBorder(color: .lightGray, width: 1)
        
        vTabContainer.showView()
        vTabContainer.setCornerRadius(radius: 7)
        vTabContainer.setBorder(color: UIColor(named: "appMainColor")!, width: 1)
        
        vEmail.setBorder(color: .lightGray, width: 1)
        vEmail.setCornerRadius(radius: 10)
      
        vName.setBorder(color: .lightGray, width: 1)
        vName.setCornerRadius(radius: 10)
        
        vPhone.setBorder(color: .lightGray, width: 1)
        vPhone.setCornerRadius(radius: 10)
        
        if contact != nil{
            vTabContainer.hideView()
            groupId = contact!.group
            tName.text = contact!.name
            tEmail.text = contact!.email
            tPhone.text = contact!.phone
        }
      
        onManual()
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func bManualTapped(_ sender: UIButton) {
        onManual()
    }
    
    @IBAction func bImportTapped(_ sender: UIButton) {
        onImport()
    }
    
    
    @IBAction func bContactGroupSpinnerTapped(_ sender: UIButton) {
       if let vc = self.storyboard?.instantiateViewController(withIdentifier: "ContactGroupVC") as?  ContactGroupVC{
            vc.delegate = self
            vc.groups = self.groups
            vc.transitioningDelegate = self.bottomSheetTransitioningDelegate
            vc.modalPresentationStyle = .custom
            present(vc, animated: true)
        }
    }
    
    @IBAction func bSaveTapped(_ sender: UIButton) {
        if type ==  0{
            if contact == nil{
                apiCallForAddContact()
            }else{
                apiCallForUpdateContact()
            }
        }else{
            apiCallForAddContacts()
        }
    }
    
    func onManual(){
        type = 0
        bManual.setTitleColor(.white, for: .normal)
        bManual.backgroundColor = UIColor(named: "appMainColor")!
        bImport.setTitleColor(UIColor(named: "appMainColor")!, for: .normal)
        bImport.backgroundColor = .white
        
        vManual.showView()
        tableView.hideView()
    }
    
    func onImport(){
        type = 1
        bImport.setTitleColor(.white, for: .normal)
        bImport.backgroundColor = UIColor(named: "appMainColor")!
        bManual.setTitleColor(UIColor(named: "appMainColor")!, for: .normal)
        bManual.backgroundColor = .white
        
        vManual.hideView()
        for c in contacts{
            c.isSelected = false
        }
        tableView.showView()
    }
    
    func getContactsInfo(){
        contacts.removeAll()
        let cnContacts: [CNContact] = GF.getContacts()
        for item in cnContacts{
            let c = MContacts()
            c.name = item.givenName
            if item.phoneNumbers.count > 0{
                let val = item.phoneNumbers[0].value
                c.phone = val.stringValue.replacingOccurrences(of: "(", with: "")
                .replacingOccurrences(of: ")", with: "")
                .replacingOccurrences(of: " ", with: "")
                .replacingOccurrences(of: "-", with: "")
                .replacingOccurrences(of: "*", with: "")
                .replacingOccurrences(of: "#", with: "")
                .replacingOccurrences(of: "+", with: "")
                .replacingOccurrences(of: ";", with: "")
                .replacingOccurrences(of: ",", with: "")
            }
            if item.emailAddresses.count > 0{
                c.email = "\(item.emailAddresses[0].value)"
            }
            contacts.append(c)
        }
        self.tableView.reloadData()
    }
    
    func apiCallForGetContactGroups() {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken()]
        
        API.postRequest(api: API.getContactGroups, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    self.groups.removeAll()
                    if let arry = dict["groups"] as? [NSDictionary]{
                        for item in arry{
                            self.groups.append(MContactGroup.init(dict: item))
                        }
                    }
                    DispatchQueue.main.async {
                        self.setContactsInfo()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForAddGroup(name: String) {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken(), "name":name]
        
        API.postRequest(api: API.addContactGroup, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    self.groups.removeAll()
                    if let arry = dict["groups"] as? [NSDictionary]{
                        for item in arry{
                            self.groups.append(MContactGroup.init(dict: item))
                        }
                    }
                    GF.showToast(msg: "Added Successfully")
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForUpdateContactGroup(id: String, name: String) {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken(), "id":id, "name":name]
        
        API.postRequest(api: API.updateContactGroup, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    self.groups.removeAll()
                    if let arry = dict["groups"] as? [NSDictionary]{
                        for item in arry{
                            self.groups.append(MContactGroup.init(dict: item))
                        }
                    }
                    GF.showToast(msg: "Updated Successfully")
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForDeleteContactGroup(id: String) {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken(), "id":id]
        
        API.postRequest(api: API.deleteContactGroup, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    self.groups.removeAll()
                    if let arry = dict["groups"] as? [NSDictionary]{
                        for item in arry{
                            self.groups.append(MContactGroup.init(dict: item))
                        }
                    }
                    GF.showToast(msg: "Deleted Successfully")
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForAddContact(){
        if groupId.isEmpty{
            GF.showToast(msg: "Please select a group")
            return
        }
        if tPhone.isEmpty || tName.isEmpty{
            GF.showToastMissingParam()
            return
        }
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken(),
                                  "name":tName.text!,
                                  "group":groupId,
                                  "email":tEmail.text!,
                                  "phone":tPhone.text!]
        API.postRequest(api: API.addContact, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    GF.postNotification(name: "update_contacts", info: nil)
                    GF.showToast(msg: "Added Successfully")
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForAddContacts(){
        if groupId.isEmpty{
            GF.showToast(msg: "Please select a group")
            return
        }
        var names = ""
        var phones = ""
        var emails = ""
        for c in contacts{
            if c.isSelected{
                var email = c.email.isEmpty ? "-" : c.email
                names = names.isEmpty ? c.name : "\(names),\(c.name)"
                phones = phones.isEmpty ? c.phone : "\(phones),\(c.phone)"
                emails = emails.isEmpty ? email : "\(emails),\(email)"
            }
        }
        if phones.isEmpty{
            GF.showToast(msg: "Please select contacts")
            return
        }
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken(),
                                  "names":names,
                                  "group":groupId,
                                  "emails":emails,
                                  "phones":phones]
        API.postRequest(api: API.addContacts, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    GF.postNotification(name: "update_contacts", info: nil)
                    GF.showToast(msg: "Added Successfully")
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForUpdateContact(){
        if groupId.isEmpty{
            GF.showToast(msg: "Please select a group")
            return
        }
        if tPhone.isEmpty || tName.isEmpty{
            GF.showToastMissingParam()
            return
        }
        GF.showLoading()
        let params: Parameters = ["id": contact!.id,
                                  "name":tName.text!,
                                  "group":groupId,
                                  "email":tEmail.text!,
                                  "phone":tPhone.text!]
        API.postRequest(api: API.updateContact, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    GF.postNotification(name: "update_contacts", info: nil)
                    GF.showToast(msg: "Updated Successfully")
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
}

extension ContactDetailsVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactImportCell") as! ContactImportCell
        cell.selectionStyle = .none
        cell.delegate = self
        cell.ind = indexPath.row
        cell.generateCell(contact: self.contacts[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        contacts[indexPath.row].isSelected = !contacts[indexPath.row].isSelected
        self.tableView.reloadData()
    }
}


extension ContactDetailsVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        switch (type){
        case 0:
            self.groupId = self.groups[index].id
            setContactsInfo()
            break
        case 1:
            let alertController = UIAlertController(title: "Add Group", message: "", preferredStyle: .alert)
            alertController .addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action:UIAlertAction) in
                
            }))
            alertController .addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                let tName = alertController.textFields![0] as UITextField
                if tName.isEmpty{
                    GF.showToast(msg: "Please enter name")
                    return
                }
                self.apiCallForAddGroup(name: tName.text!)
            }))
            alertController.addTextField { (textField) in
                textField.placeholder = "Enter Name"
                textField.text = "New Group"
            }
            self.present(alertController, animated: true, completion: nil)
            break
        case 2:
            let alertController = UIAlertController(title: "Edit Group", message: "", preferredStyle: .alert)
            alertController .addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action:UIAlertAction) in
                
            }))
            alertController .addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                let tName = alertController.textFields![0] as UITextField
                if tName.isEmpty{
                    GF.showToast(msg: "Please enter name")
                    return
                }
                self.apiCallForUpdateContactGroup(id: self.groups[index].id, name: tName.text!)
            }))
            alertController.addTextField { (textField) in
                textField.placeholder = "Enter Name"
                textField.text = self.groups[index].name
            }
            self.present(alertController, animated: true, completion: nil)
            break
        case 3:
            self.apiCallForDeleteContactGroup(id: groups[index].id)
            break
        default:
            break
        }
    }
}

extension ContactDetailsVC: SelectDelegate{
    func onSelect(id: String, type: Int) {
        
    }
    
    func onSelect(index: Int) {
        dismiss(animated: true)
        groupId = groups[index].id
        setContactsInfo()
    }
    
    func setContactsInfo(){
        var groupName = "Select Group"
        if !groupId.isEmpty{
            for g in groups{
                if g.id.elementsEqual(groupId){
                    groupName = g.name
                    break
                }
            }
        }
        lContactGroupSpinnerValue.text = groupName
    }
}
