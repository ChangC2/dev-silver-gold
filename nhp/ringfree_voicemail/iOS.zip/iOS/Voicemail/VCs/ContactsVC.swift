//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire

class ContactsVC: BaseVC {
    
    @IBOutlet weak var vContactGroupSpinner: UIView!
    @IBOutlet weak var lContactGroupSpinnerValue: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var groups = [MContactGroup]()
    var contacts = [MContacts]()
    var filteredContacts = [MContacts]()
    var groupId = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        vContactGroupSpinner.setCornerRadius(radius: 8)
        vContactGroupSpinner.setBorder(color: .lightGray, width: 1)
        apiCallForGetContacts(showLoading: true)
        GF.observeNotification(name: "update_contacts", completion: {userInfo in 
            self.apiCallForGetContacts(showLoading: false)
        })
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func bContactGroupSpinnerTapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let sVC = stb.instantiateViewController(withIdentifier: "SelectVC") as?  SelectVC{
            var listTitles = [String]()
            listTitles.append("All Contacts")
            for i in 0..<groups.count{
                listTitles.append(groups[i].name)
            }
            sVC.datas = listTitles
            sVC.delegate = self
            self.present(sVC, animated: true, completion: nil)
        }
    }
    
    
    @IBAction func bAddTapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "ContactDetailsVC") as?  ContactDetailsVC{
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func apiCallForGetContacts(showLoading: Bool) {
        if showLoading{
            GF.showLoading()
        }
        let params: Parameters = ["token": GF.getToken()]
        
        API.postRequest(api: API.getContacts, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    
                    self.groups.removeAll()
                    if let arry = dict["groups"] as? [NSDictionary]{
                        for item in arry{
                            self.groups.append(MContactGroup.init(dict: item))
                        }
                    }
                    self.contacts.removeAll()
                    if let arry = dict["contacts"] as? [NSDictionary]{
                        for item in arry{
                            self.contacts.append(MContacts.init(dict: item))
                        }
                    }
                   
                    DispatchQueue.main.async {
                        self.setContactsInfo()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForDeleteContact(index: Int){
        GF.showLoading()
        let params: Parameters = ["id": filteredContacts[index].id]
        API.postRequest(api: API.deleteContact, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    GF.showToast(msg: "Deleted Successfully")
                    for i in 0..<self.contacts.count{
                        if self.contacts[i].id.elementsEqual(self.filteredContacts[index].id){
                            self.contacts.remove(at: i)
                            break
                        }
                    }
                    self.filteredContacts.remove(at: index)
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
}

extension ContactsVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredContacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactCell") as! ContactCell
        cell.selectionStyle = .none
        cell.delegate = self
        cell.ind = indexPath.row
        cell.generateCell(contact: self.filteredContacts[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}


extension ContactsVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        switch (type){
        case 0://Edit
            let stb = UIStoryboard(name: "Main", bundle: nil)
            if let vc = stb.instantiateViewController(withIdentifier: "ContactDetailsVC") as?  ContactDetailsVC{
                vc.contact = contacts[index]
                self.navigationController?.pushViewController(vc, animated: true)
            }
            break
        case 1://Delete
            apiCallForDeleteContact(index: index)
            break
        default:
            break
        }
    }
}

extension ContactsVC: SelectDelegate{
    func onSelect(id: String, type: Int) {
        
    }
    
    func onSelect(index: Int) {
        dismiss(animated: true)
        if index == 0{
            groupId = ""
        }else{
            groupId = groups[index-1].id
        }
        setContactsInfo()
    }
    
    func setContactsInfo(){
        var groupName = "All Contacts"
        filteredContacts.removeAll()
        if groupId.isEmpty{
            filteredContacts.append(contentsOf: contacts)
        }else{
            for g in groups{
                if g.id.elementsEqual(groupId){
                    groupName = g.name
                    break
                }
            }
            for c in contacts{
                if c.group.elementsEqual(groupId){
                    filteredContacts.append(c)
                }
            }
        }
        lContactGroupSpinnerValue.text = groupName
        tableView.reloadData()
    }
}
