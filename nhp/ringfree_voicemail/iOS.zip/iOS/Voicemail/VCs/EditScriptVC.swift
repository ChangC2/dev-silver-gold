//
//  AudioPlayerVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/7/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer
import Alamofire

class EditScriptVC: UIViewController {
    
    @IBOutlet weak var vCenter: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet var tName: UITextField!
    
    @IBOutlet weak var vSalutationSpinner: UIView!
    @IBOutlet weak var lSalutationSpinnerValue: UILabel!
    @IBOutlet var tContent: UITextView!
    
    
    
    var script: MScript?
    var index = 0
    var salutationIndex = 0
    var salutations = ["First Name", "Hello First Name", "Hey First Name", "Hope all is well First Name", "Good Afternoon First Name", "Good Morning First Name", "Good Evening First Name", "- No salutation -"]
    
    var delegate: RefreshScriptDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        self.vCenter.setBorder3()
        // Do any additional setup after loading the view.
        
        
        vSalutationSpinner.setCornerRadius(radius: 8)
        vSalutationSpinner.setBorder(color: .lightGray, width: 1)
        
        tContent.setCornerRadius(radius: 8)
        tContent.setBorder(color: .lightGray, width: 1)
        
        if script != nil{
            titleLabel.text = "Edit Script"
            tName.text = script!.name
            lSalutationSpinnerValue.text = script!.salutation == "" ? salutations[7] : script!.salutation
            tContent.text = script!.content
        }
    }
    
    @IBAction func bCancalTapped(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func bSalutationSpinnerTapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let sVC = stb.instantiateViewController(withIdentifier: "SelectVC") as?  SelectVC{
            sVC.datas = salutations
            sVC.delegate = self
            self.present(sVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func bSaveTapped(_ sender: UIButton) {
        if tName.isEmpty{
            GF.showToast(msg: "Please input name.")
            return
        }
        if tContent.isEmpty{
            GF.showToast(msg: "Please input content.")
            return
        }
        if script == nil{
            apiCallForAddScript(name:tName.text!, content: tContent.text!, salutation: salutationIndex == 7 ? "" : lSalutationSpinnerValue.text!)
        }else{
            apiCallForUpdateScript(name:tName.text!, content: tContent.text!, salutation: salutationIndex == 7 ? "" : lSalutationSpinnerValue.text!)
        }
    }
    
    
    func apiCallForAddScript(name: String, content: String, salutation: String){
        let params: Parameters = ["token": "\(GF.getToken())",
                                  "name": name,
                                  "salutation": salutation,
                                  "content": content]
        GF.showLoading()
        API.postRequest(api: API.addScript, params: params, completion: { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"), let recDic = dict["script"] as? NSDictionary{
                    let newScript = MScript.init(dict: recDic)
                    GF.showAlertViewWithTitle("", message: "Congrats ! You saved your Script", buttonTitles: ["OK"], viewController: self, completion: {result in
                        self.delegate?.refresh(index: -1, script: newScript)
                        self.navigationController?.popViewController(animated: true)
                    })
                }else{
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: dict.parseString(param: "message"), buttonTitles: ["Ok"], viewController: self, completion: {result in
                        })
                    }
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForUpdateScript(name: String, content: String, salutation: String){
        let params: Parameters = ["id": "\(self.script!.id)",
                                  "name": name,
                                  "salutation": salutation,
                                  "content": content]
        GF.showLoading()
        API.postRequest(api: API.updateScript, params: params, completion: { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"), let recDic = dict["script"] as? NSDictionary{
                    let newScript = MScript.init(dict: recDic)
                    GF.showAlertViewWithTitle("", message: "Congrats ! You saved your Script", buttonTitles: ["OK"], viewController: self, completion: {result in
                        self.delegate?.refresh(index: -1, script: newScript)
                        self.navigationController?.popViewController(animated: true)
                    })
                }else{
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: dict.parseString(param: "message"), buttonTitles: ["Ok"], viewController: self, completion: {result in
                        })
                    }
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
}


extension EditScriptVC: SelectDelegate{
    func onSelect(id: String, type: Int) {
        
    }
    
    func onSelect(index: Int) {
        dismiss(animated: true)
        salutationIndex = index
        lSalutationSpinnerValue.text = salutations[salutationIndex]
    }
}

