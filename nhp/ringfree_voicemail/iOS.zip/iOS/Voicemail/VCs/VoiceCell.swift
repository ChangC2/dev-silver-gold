//
//  RecordingCell.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/4/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit

class VoiceCell: UITableViewCell {
    
    @IBOutlet weak var vBack: UIView!
    @IBOutlet var lName: UILabel!
    @IBOutlet var lStatus: UILabel!
    @IBOutlet var lTime: UILabel!
    @IBOutlet var bEdit: UIButton!
    @IBOutlet var bDel: UIButton!
    var delegate: ClickDelegate?
    var ind = 0
    var voice = MVoice()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        vBack.setBorder5()
    }
    
    func generateCell(voice: MVoice){
        self.voice = voice
        lName.text = voice.name
        lStatus.text = (voice.active == 0) ? "Processing" : "Approved"
        lTime.text = voice.created_at.dateFromString(format: .dateTimeee)?.stringFromDate(format: .MMddyyyyHHmm)
    }
    
    @IBAction func bPlayTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 0)
    }
    
    @IBAction func bEditTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 1)
    }
    
    @IBAction func bDeleteTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 2)
    }
    
}
