//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire

class PastVoicemailsVC: BaseVC {
  
    @IBOutlet var lTitle: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var orders = [MOrder]()
    @objc var type = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if (type == 0){
            lTitle.text = "Pending Orders"
        }else if (type == 1){
            lTitle.text = "Scheduled Orders"
        }else{
            lTitle.text = "Delivered Orders"
        }
        apiCallForGetOrders()
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    func viewContent(index: Int){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "AudioPlayerVC") as?  AudioPlayerVC{
            vc.order = orders[index]
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    
    func apiCallForGetOrders() {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken()]
        var api = ""
        if (type == 0){
            api = API.getPendingOrders
        }else if (type == 1){
            api = API.getScheduledOrders
        }else{
            api = API.getDeliveredOrders
        }
        API.postRequest(api: api, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    if let arry = dict["orders"] as? [NSDictionary]{
                        for item in arry{
                            self.orders.append(MOrder.init(dict: item))
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForCancelOrder(index: Int){
        GF.showLoading()
        let params: Parameters = ["id": orders[index].id]
        API.postRequest(api: API.cancelOrder, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    GF.showToast(msg: "Canceled Successfully")
                    self.orders.remove(at: index)
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
}

extension PastVoicemailsVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PastVoicemailCell") as! PastVoicemailCell
        cell.selectionStyle = .none
        cell.delegate = self
        cell.index = indexPath.row
        cell.generateCell(order: orders[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}


extension PastVoicemailsVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        switch (type){
        case 0://Play Audio
            viewContent(index: index)
            break
        case 1://Edit Recording
            let stb = UIStoryboard(name: "Main", bundle: nil)
            if let vc = stb.instantiateViewController(withIdentifier: "LogsVC") as?  LogsVC{
                vc.orderId = self.orders[index].id
                self.navigationController?.pushViewController(vc, animated: true)
            }
            break
        case 2://Delete Recording
            self.apiCallForCancelOrder(index: index)
            break
        default:
            break
        }
    }
}

