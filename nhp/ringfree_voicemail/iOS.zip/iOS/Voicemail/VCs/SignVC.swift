//
//  SignVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 3/18/24.
//  Copyright © 2024 NewHomePage LLC. All rights reserved.
//

import UIKit
import SignaturePad
import Alamofire

class SignVC: UIViewController , SignaturePadDelegate{
    
    @IBOutlet weak var bNext: UIButton!
    @IBOutlet weak var bBack: UIButton!
    @IBOutlet weak var bDecline: UIButton!
    @IBOutlet weak var vStart: UIView!
    @IBOutlet weak var vStep: UIView!
    @IBOutlet weak var lStepTitle: UILabel!
    @IBOutlet weak var lStepContent: UILabel!
    @IBOutlet weak var bAgree: UIButton!
    @IBOutlet weak var vSign: UIView!
    @IBOutlet weak var vScroll: UIScrollView!
    @IBOutlet weak var tAgree: UITextField!
    @IBOutlet weak var vSignature: SignaturePad!
    
    var step = -1
    
    var titles = ["Part I", "Part II", "Part III"]
    var contents = [String]()
    var isSigned = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        vSignature.setBorder5()
        
        vStart.showView()
        vStep.hideView()
        vSign.hideView()
        bBack.hideView()
        bDecline.hideView()
        loadHtmlContents()
    }
    
    func loadHtmlContents(){
        if let filepath = Bundle.main.path(forResource: "step_1", ofType: "html") {
            do {
                let content = try String(contentsOfFile: filepath, encoding: .utf8)
                contents.append(content)
            } catch {
                print("Error reading the HTML file: \(error)")
            }
        } else {
            print("HTML file not found")
        }
        if let filepath = Bundle.main.path(forResource: "step_2", ofType: "html") {
            do {
                let content = try String(contentsOfFile: filepath, encoding: .utf8)
                contents.append(content)
            } catch {
                print("Error reading the HTML file: \(error)")
            }
        } else {
            print("HTML file not found")
        }
        if let filepath = Bundle.main.path(forResource: "step_3", ofType: "html") {
            do {
                let content = try String(contentsOfFile: filepath, encoding: .utf8)
                contents.append(content)
            } catch {
                print("Error reading the HTML file: \(error)")
            }
        } else {
            print("HTML file not found")
        }
    }
    
    @IBAction func bClearTapped(_ sender: UIButton) {
        vSignature.clear()
    }
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func bNextTapped(_ sender: UIButton) {
        if step > -1 && step < 3 && !bAgree.isSelected{
            GF.showToast(msg: "Please click 'I Agree'")
            return
        }
        vScroll.scrollToTop(animated: true)
        if step<2{
            step += 1
            bAgree.isSelected = false
            vStart.hideView()
            vStep.showView()
            vSign.hideView()
            bBack.isHidden = step < 1
            bNext.setTitle("Next", for: .normal)
            bDecline.hideView()
            lStepTitle.text = titles[step]
            lStepContent.attributedText = contents[step].htmlToAttributedString
        }else if step == 2{
            step += 1
            vStart.hideView()
            vStep.hideView()
            vSign.showView()
            bNext.setTitle("Accept the Terms and Conditions", for: .normal)
            bDecline.showView()
        }else{
            let acceptString = tAgree.text!
            if acceptString.elementsEqual("I Accept"), let signature = vSignature.getSignature(){
                if let data = signature.pngData() as? NSData{
                    apiCallForSignature(data: data.base64EncodedString(options: []))
                }
            }else{
                GF.showToast(msg: "Please type 'I Accept' and sign.")
            }
        }
    }
    
    @IBAction func bPrevTapped(_ sender: UIButton) {
        if step > 0{
            step -= 1
        }
        vStart.hideView()
        vStep.showView()
        vScroll.scrollToTop(animated: true)
        vSign.hideView()
        bBack.isHidden = step < 1
        bNext.setTitle("Next", for: .normal)
        bDecline.hideView()
        lStepTitle.text = titles[step]
        lStepContent.attributedText = contents[step].htmlToAttributedString
    }
    
    @IBAction func bDeclineTapped(_ sender: UIButton) {
        GV.isDeclined = true
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func bAgreeTapped(_ sender: UIButton) {
        bAgree.isSelected = true
    }
    
    func didStart() {
        isSigned = false
    }
    
    func didFinish() {
        isSigned = true
    }
    
    func apiCallForSignature(data: String){
        let params: Parameters = ["token": "\(GF.getToken())",
                                  "data": "\(data)"]
        GF.showLoading()
        API.postRequest(api: API.signature, params: params, completion: { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    self.navigationController?.popViewController(animated: true)
                }else{
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: dict.parseString(param: "message"), buttonTitles: ["Ok"], viewController: self, completion: {result in
                        })
                    }
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
}
