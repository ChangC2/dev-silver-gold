//
//  MainVC.swift
//  Sagor
//
//  Created by SilverGold on 1/13/21.
//  Copyright © 2021 Sagor. All rights reserved.
//

import UIKit
import SnapKit
import Alamofire
import DatePicker

class SendVoicemailsVC: BaseVC {
    
    
    @IBOutlet weak var vTabContainer: UIView!
    @IBOutlet var bPreRecorded: UIButton!
    @IBOutlet var bAIVoiceCloning: UIButton!
    @IBOutlet weak var lTitle: UILabel!
    @IBOutlet weak var consMenuL: NSLayoutConstraint!
    @IBOutlet weak var vHideMenu: UIView!
    @IBOutlet weak var vMenu: UIView!
    @IBOutlet weak var bMenu: UIButton!
    
    @IBOutlet weak var vContactGroupSpinner: UIView!
    @IBOutlet weak var lContactGroupSpinnerValue: UILabel!
    
    @IBOutlet weak var lAudioSpinnerDesc: UILabel!
    @IBOutlet weak var vAudioSpinner: UIView!
    @IBOutlet weak var lAudioSpinnerValue: UILabel!
    
    @IBOutlet var vScriptsContainer: UIView!
    @IBOutlet weak var vScriptSpinner: UIView!
    @IBOutlet weak var lScriptSpinnerValue: UILabel!
    @IBOutlet var vMsgContent: UIView!
    @IBOutlet var tContent: UITextView!
    
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var remainingTimeLabel: UILabel!
    @IBOutlet weak var elapsedTimeLabel: UILabel!
    @IBOutlet var lContacts: UILabel!
    @IBOutlet var lCosts: UILabel!
    
    @IBOutlet var tForwardingNumber: UITextField!
    @IBOutlet var tReForwardingNumber: UITextField!
    
    @IBOutlet var vSalutationContainer: UIView!
    @IBOutlet weak var vSalutationSpinner: UIView!
    @IBOutlet weak var lSalutationSpinnerValue: UILabel!
   
    
    @IBOutlet weak var bSendImmediately: UIButton!
    @IBOutlet weak var bSendOn: UIButton!
    
    @IBOutlet weak var vSchedule: UIView!
    @IBOutlet weak var vDate: UIView!
    @IBOutlet weak var VTime: UIView!
    @IBOutlet weak var tDate: UITextField!
    @IBOutlet weak var tTime: UITextField!
    
    
    @IBOutlet var bBreakup: UIButton!
    @IBOutlet var vNumberBroadcasts: UIView!
    @IBOutlet var tNumberBroadcasts: UITextField!
    @IBOutlet var lNumberPerday: UILabel!
    @IBOutlet var vDaysBetweenEach: UIView!
    @IBOutlet var tDaysBetweenEach: UITextField!
    
    
    let audioPlayer = AudioPlayer()
    
    var type = 0
    var spinnerType = 0 // 0 : Audio Spinner, 1 : Scripts Spinner
    var audioIndex = -1
    var scriptIndex = 0
    
    var recordings = [MRecording]()
    var voices = [MVoice]()
    var scripts = [MScript]()
    var groups = [MContactGroup]()
    var contacts = [MContacts]()
    var filteredContacts = [MContacts]()
    var groupId = ""
    
    var currentVC: UIViewController?
    
    var dateStr = ""
    var timeStr = ""
    let datePicker = UIDatePicker()
    var signed = false
    
    var salutationIndex = 7
    var salutations = ["First Name", "Hello First Name", "Hey First Name", "Hope all is well First Name", "Good Afternoon First Name", "Good Morning First Name", "Good Evening First Name", "- No salutation -"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if GV.isDeclined{
            GV.isDeclined = false
            GF.goLoginVC()
        }else{
            apiCallForGetMainData()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        audioPlayer.stop()
    }
    
    func initUI(){
        consMenuL.constant = -270
        vHideMenu.hideView()
        embedMenuVC()
        vTabContainer.setCornerRadius(radius: 7)
        vTabContainer.setBorder(color: UIColor(named: "appMainColor")!, width: 1)
        
        vContactGroupSpinner.setCornerRadius(radius: 8)
        vContactGroupSpinner.setBorder(color: .lightGray, width: 1)
        
        vAudioSpinner.setCornerRadius(radius: 8)
        vAudioSpinner.setBorder(color: .lightGray, width: 1)
        onPreRecorded()
        
        vScriptSpinner.setCornerRadius(radius: 8)
        vScriptSpinner.setBorder(color: .lightGray, width: 1)
        
        tContent.setCornerRadius(radius: 8)
        tContent.setBorder(color: .lightGray, width: 1)
        
        lScriptSpinnerValue.text = "Manual Input"
        lSalutationSpinnerValue.text = salutations[7]
        
        self.slider.setThumbImage(UIImage(named: "ic_green_dot"), for: .normal)
        
        audioPlayer.event.stateChange.addListener(self, handleAudioPlayerStateChange)
        audioPlayer.remoteCommands = [
            .play,
            .pause,
            .skipForward(preferredIntervals: [30]),
            .skipBackward(preferredIntervals: [30]),
        ]
        audioPlayer.event.stateChange.addListener(self, handleAudioPlayerStateChange)
        audioPlayer.event.secondElapse.addListener(self, handleAudioPlayerSecondElapsed)
        audioPlayer.event.seek.addListener(self, handleAudioPlayerDidSeek)
        audioPlayer.event.updateDuration.addListener(self, handleAudioPlayerUpdateDuration)
        audioPlayer.event.fail.addListener(self, handlePlayerFailure)
        updateMetaData()
        handleAudioPlayerStateChange(data: audioPlayer.playerState)
        vSalutationSpinner.setCornerRadius(radius: 8)
        vSalutationSpinner.setBorder(color: .lightGray, width: 1)
        vDate.setCornerRadius(radius: 8)
        vDate.setBorder(color: .lightGray, width: 1)
        VTime.setCornerRadius(radius: 8)
        VTime.setBorder(color: .lightGray, width: 1)
        vSchedule.hideView()
        setDatePicker()
        bSendImmediately.isSelected = true
        bSendOn.isSelected = false
    }
    
    func setUI(){
        if !signed{
            let stb = UIStoryboard(name: "Main", bundle: nil)
            if let vc = stb.instantiateViewController(withIdentifier: "SignVC") as?  SignVC{
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
        setContactsInfo()
        tForwardingNumber.text = "\(GV.forwarding_number)"
        tReForwardingNumber.text = "\(GV.forwarding_number)"
        onPreRecorded()
    }
    
    func setContactsInfo(){
        var groupName = "All Contacts"
        filteredContacts.removeAll()
        if groupId.isEmpty{
            filteredContacts.append(contentsOf: contacts)
        }else{
            for g in groups{
                if g.id.elementsEqual(groupId){
                    groupName = g.name
                    break
                }
            }
            for c in contacts{
                if c.group.elementsEqual(groupId){
                    filteredContacts.append(c)
                }
            }
        }
        lContactGroupSpinnerValue.text = groupName
        lContacts.text = "# of Records : \(filteredContacts.count)"
        tForwardingNumber.text = "\(GV.forwarding_number)"
        tReForwardingNumber.text = "\(GV.forwarding_number)"
        lCosts.text = String(format: "Potential Cost : %.1f", Double(filteredContacts.count) * GV.credits_to_send)
        setNumberBroadcast()
    }
    
    func setDatePicker(){
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        }
        datePicker.datePickerMode = .date
        datePicker.locale = Locale(identifier: "en_US")
        
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneDatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        
        self.tDate.inputAccessoryView = toolbar
        self.tDate.inputView = datePicker
    }
    
    func showTimePicker() {
        let timeSelector = TimeSelector()
        timeSelector.timeSelected = {
            (timeSelector) in
            self.setTimeFromDate(timeSelector.date)
        }
        timeSelector.overlayAlpha = 0.8
        timeSelector.clockTint = timeSelector_rgb(0, 230, 0)
        timeSelector.minutes = 30
        timeSelector.hours = 5
        timeSelector.isAm = false
        timeSelector.presentOnView(view: self.view)
    }
    
    @objc func doneDatePicker(){
        self.setDayFromDate(datePicker.date)
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    func setTimeFromDate(_ date: Date) {
        tTime.text = date.localTimeString(format:  .time)
        timeStr = date.localTimeString(format:  .time)
    }
    
    func setDayFromDate(_ date: Date) {
        tDate.text = date.localTimeString(format:  .MMddyyyy)
        dateStr = date.localTimeString(format:  .dateSlash)
    }
    
    func showMenu(){
        UIView.animate(withDuration: 0.3, animations: {
            self.consMenuL.constant = 0
            self.view.layoutIfNeeded()
        }, completion: { (finished: Bool) in
            self.vHideMenu.showView()
        })
    }
    
    func hideMenu(){
        UIView.animate(withDuration: 0.3, animations: {
            self.consMenuL.constant = -270
            self.view.layoutIfNeeded()
        }, completion: { (finished: Bool) in
            self.vHideMenu.hideView()
        })
    }
    
    func moveRecordingsVC(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "RecordingsVC") as?  RecordingsVC{
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func moveVoicesVC(type: Int){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "VoicesVC") as?  VoicesVC{
            vc.type = type
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func moveScriptsVC(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "ScriptsVC") as?  ScriptsVC{
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func movePastVoicemailsVC(type: Int){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "PastVoicemailsVC") as?  PastVoicemailsVC{
            vc.type = type
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func moveCredits(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "ManageCreditsVC") as?  ManageCreditsVC{
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func moveContacts(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "ContactsVC") as?  ContactsVC{
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func moveAccount(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "AccountVC") as?  AccountVC{
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func moveFAQ(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "FAQVC") as?  FAQVC{
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    
    func onLogout(){
        GF.showAlertViewWithTitle("Logout", message: "Do you want to logout?", buttonTitles: ["Yes", "No"], viewController: self, completion: {index in
            if index == 0{
                userDefault.setValue(false, forKey: C.IS_LOGINED)
                userDefault.setValue("", forKey: C.TOKEN)
                GF.goLoginVC()
            }
        })
    }
    
    func embedMenuVC(){
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "MenuVC") as? MenuVC  {
            vc.delegate = self
            vc.willMove(toParent: self)
            self.vMenu.addSubview(vc.view)
            vc.view.snp.makeConstraints { (make) in
                make.top.left.bottom.right.equalTo(self.vMenu)
            }
            self.addChild(vc)
        }
    }
    // ######################### Actions ######################### //
    @IBAction func onChangeForwardingNumber(_ sender: UITextField) {
        GV.forwarding_number = tForwardingNumber.text!
    }
    
    @IBAction func bNavTapped(_ sender: UIButton) {
        if consMenuL.constant == 0{
            hideMenu()
        }else{
            showMenu()
        }
    }
    @IBAction func bHideMenuTapped(_ sender: UITapGestureRecognizer) {
        hideMenu()
    }
    
    @IBAction func bPreRecoredTapped(_ sender: UIButton) {
        onPreRecorded()
    }
    
    @IBAction func bAIVoiceCloningTapped(_ sender: UIButton) {
        onAIVoiceCloning()
    }
    
    @IBAction func bTimeTapped(_ sender: UIButton) {
        showTimePicker()
    }
    
    
    @IBAction func bBreakupTapped(_ sender: UIButton) {
        bBreakup.isSelected = !bBreakup.isSelected
        if bBreakup.isSelected{
            onSendOn()
            vNumberBroadcasts.showView()
            vDaysBetweenEach.showView()
        }else{
            vNumberBroadcasts.hideView()
            vDaysBetweenEach.hideView()
        }
    }
    
    @IBAction func onNumberBroadcasts(_ sender: UITextField) {
        setNumberBroadcast()
    }
    
    func setNumberBroadcast(){
        let numPerDay = Int((filteredContacts.count - 1) / tNumberBroadcasts.text!.intValue) + 1
        lNumberPerday.text = "= \(numPerDay) Attempts per day"
    }
    
    @IBAction func bSendTapped(_ sender: UIButton) {
        if filteredContacts.count == 0{
            GF.showToast(msg: "No Record")
            return
        }
        if self.audioIndex == -1{
            GF.showToast(msg: type == 0 ? "Please select a Recording." : "Please select a voice.")
            return
        }
        if tForwardingNumber.isEmpty{
            GF.showToast(msg: "Please input a forwarding number.")
            return
        }
        
        if !tForwardingNumber.text!.elementsEqual(tReForwardingNumber.text!){
            GF.showToast(msg: "Mismatch Forwarding Number.")
            return
        }
        
        if bSendOn.isSelected{
            if dateStr.isEmpty || timeStr.isEmpty{
                GF.showToast(msg: "Please set scheduled time.")
                return
            }
        }
        
        if type == 1 && tContent.isEmpty{
            GF.showToast(msg: "Please input a message.")
            return
        }
        
        if type == 0{
            moveToConfirm(audioUrl: recordings[self.audioIndex].url)
        }else{
            getVoiceUrl()
        }
        
    }
    
    func moveToConfirm(audioUrl: String){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "ConfirmVoicemailVC") as?  ConfirmVoicemailVC{
            vc.groupId = self.groupId
            vc.contacts.removeAll()
            vc.contacts.append(contentsOf: filteredContacts)
            vc.type = self.type
            if type == 0{
                vc.audioUrl = recordings[self.audioIndex].url
            }else{
                vc.audioUrl = voices[self.audioIndex].url
            }
            vc.previewUrl = audioUrl
            vc.audioName = type == 0 ? recordings[self.audioIndex].name : voices[self.audioIndex].name
            vc.msgContent = tContent.text!
            vc.isScheduled = bSendOn.isSelected
            if bSendOn.isSelected{
                vc.sendTime = "\(dateStr) \(timeStr)".dateFromString(format: .yyyyMMddhhmma)?.stringFromDate(format: .dateTimeee) ?? ""
            }
            vc.voiceId = voices[self.audioIndex].id
            vc.break_up = bBreakup.isSelected
            vc.broadcasts_number = tNumberBroadcasts.text!.intValue
            vc.between_days = tDaysBetweenEach.text!.intValue
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func getVoiceUrl(){
        let voiceUrl = voices[self.audioIndex].url
        let msgContent = tContent.text!.replacingOccurrences(of: "First Name", with: contacts[0].name)
        let params: Parameters = ["voice_url": voiceUrl, "contents":msgContent]
        GF.showLoading()
        AF.sessionConfiguration.timeoutIntervalForRequest = 500
        AF.sessionConfiguration.timeoutIntervalForResource = 500
        AF.request(URL(string: "https://aivalet.leadmarketer.com/tts_from_url.php")!, method: .post, parameters: params).responseData { (response) in
            GF.hideLoading()
            var audioUrl = ""
            let statusCode = response.response?.statusCode
            if statusCode == 200 || statusCode == 204 || statusCode == 201 {
                switch response.result {
                case .success(let data):
                    do {
                        if let dic =  try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary{
                            audioUrl = dic.parseString(param: "url")
                        }
                    } catch {
                    }
                    break
                case .failure(_):
                    break
                }
            }
            self.moveToConfirm(audioUrl: audioUrl)
        }
    }
    
    
    // ######################### Actions ######################### //
    
    func onPreRecorded(){
        type = 0
        bPreRecorded.setTitleColor(.white, for: .normal)
        bPreRecorded.backgroundColor = UIColor(named: "appMainColor")!
        bAIVoiceCloning.setTitleColor(UIColor(named: "appMainColor")!, for: .normal)
        bAIVoiceCloning.backgroundColor = .white
        
        lAudioSpinnerDesc.text = "The pre-recorded message to deliver into your contact's voicemail inbox"
        lAudioSpinnerValue.text = "Select Recording"
        vScriptsContainer.hideView()
        vSalutationContainer.hideView()
        vMsgContent.hideView()
        clearTimeValues()
    }
    
    func onAIVoiceCloning(){
        type = 1
        bAIVoiceCloning.setTitleColor(.white, for: .normal)
        bAIVoiceCloning.backgroundColor = UIColor(named: "appMainColor")!
        bPreRecorded.setTitleColor(UIColor(named: "appMainColor")!, for: .normal)
        bPreRecorded.backgroundColor = .white
        
        lAudioSpinnerDesc.text = "AI Avatar Voice to replicate personalized voicemails sending to each of your contacts"
        lAudioSpinnerValue.text = "Select AI Avatar Voice"
        vScriptsContainer.showView()
        vSalutationContainer.showView()
        vMsgContent.showView()
        clearTimeValues()
    }
    
    @IBAction func togglePlay(_ sender: Any) {
        audioPlayer.togglePlaying()
    }
    
    @IBAction func bView10Tapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "ContactsVC") as?  ContactsVC{
            vc.groupId = self.groupId
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func bAudioSpinnerTapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let sVC = stb.instantiateViewController(withIdentifier: "SelectVC") as?  SelectVC{
            var listTitles = [String]()
            if type == 0{
                for i in 0..<recordings.count{
                    listTitles.append(recordings[i].name)
                }
            }else{
                for i in 0..<voices.count{
                    listTitles.append(voices[i].name)
                }
            }
            sVC.datas = listTitles
            sVC.delegate = self
            spinnerType = 0
            self.present(sVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func bContactGroupSpinnerTapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let sVC = stb.instantiateViewController(withIdentifier: "SelectVC") as?  SelectVC{
            var listTitles = [String]()
            listTitles.append("All Contacts")
            for i in 0..<groups.count{
                listTitles.append(groups[i].name)
            }
            sVC.datas = listTitles
            sVC.delegate = self
            spinnerType = 3
            self.present(sVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func bScriptsSpinnerTapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let sVC = stb.instantiateViewController(withIdentifier: "SelectVC") as?  SelectVC{
            var listTitles = [String]()
            listTitles.append("Manual Input")
            for i in 0..<scripts.count{
                listTitles.append(scripts[i].name)
            }
            sVC.datas = listTitles
            sVC.delegate = self
            spinnerType = 1
            self.present(sVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func bSalutationSpinnerTapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let sVC = stb.instantiateViewController(withIdentifier: "SelectVC") as?  SelectVC{
            sVC.datas = salutations
            sVC.delegate = self
            spinnerType = 2
            self.present(sVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func bSendImmediatelyTapped(_ sender: UIButton) {
        if bBreakup.isSelected{
            return
        }
        bSendImmediately.isSelected = true
        bSendOn.isSelected = false
        vSchedule.hideView()
    }
    
    @IBAction func bSendOnTapped(_ sender: UIButton) {
        onSendOn()
    }
    
    func onSendOn(){
        bSendImmediately.isSelected = false
        bSendOn.isSelected = true
        vSchedule.showView()
    }
    
    func loadAudio(audioUrl: String){
        if let url = URL(string: audioUrl) {
            GF.showLoading()
            GF.loadData(url: url) { (url, error) in
                GF.hideLoading()
                if url == "" || error != nil{
                    GF.showToast(msg: "Error loading audio")
                    return
                }
                DispatchQueue.main.async {
                    let audioItem = DefaultAudioItem(audioUrl: url, sourceType: .stream)
                    try? self.audioPlayer.load(item: audioItem, playWhenReady: false) // Load the item and start playing when the player is ready.
                }
            }
        }
    }
    
    func clearTimeValues() {
        self.audioIndex = -1
        audioPlayer.stop()
        playButton.isEnabled = false
        self.slider.maximumValue = Float(0.0)
        self.slider.setValue(Float(0.0), animated: true)
        self.elapsedTimeLabel.text = "00:00"
        self.remainingTimeLabel.text = "00:00"
    }
    
    func updateTimeValues() {
        self.slider.maximumValue = Float(self.audioPlayer.duration)
        self.slider.setValue(Float(self.audioPlayer.currentTime), animated: true)
        self.elapsedTimeLabel.text = self.audioPlayer.currentTime.secondsToString()
        self.remainingTimeLabel.text = self.audioPlayer.duration.secondsToString()
    }
    
    func updateMetaData() {
    }
    
    func setPlayButtonState(forAudioPlayerState state: AudioPlayerState) {
        playButton.setImage(state == .playing ? UIImage(named: "ic_player_pause")! : UIImage(named: "ic_player_play")!, for: .normal)
    }
    
    
    // MARK: - AudioPlayer Event Handlers
    func handleAudioPlayerStateChange(data: AudioPlayer.StateChangeEventData) {
        print(data)
        DispatchQueue.main.async {
            self.setPlayButtonState(forAudioPlayerState: data)
            switch data {
            case .loading:
                self.updateMetaData()
                self.updateTimeValues()
            case .buffering: break
            case .ready:
                self.updateMetaData()
                self.updateTimeValues()
            case .playing, .idle:
                self.updateTimeValues()
            case .paused:
                if self.slider.value == self.slider.maximumValue{
                    self.audioPlayer.seek(to: 0)
                }
            }
        }
    }
    
    func handleAudioPlayerSecondElapsed(data: AudioPlayer.SecondElapseEventData) {
        DispatchQueue.main.async {
            self.updateTimeValues()
        }
    }
    
    func handleAudioPlayerDidSeek(data: AudioPlayer.SeekEventData) {
    }
    
    func handleAudioPlayerUpdateDuration(data: AudioPlayer.UpdateDurationEventData) {
        DispatchQueue.main.async {
            self.updateTimeValues()
        }
    }
    
    func handlePlayerFailure(data: AudioPlayer.FailEventData) {
        GF.hideLoading()
    }
    
    func apiCallForGetMainData() {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken()]
        API.postRequest(api: API.getMainData, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"), let dataDic = dict["data"] as? NSDictionary{
                    GV.forwarding_number = dataDic.parseString(param: "forwarding_number")
                    GV.credits = dataDic.parseDouble(param: "credits")
                    GV.credits_to_send = dataDic.parseDouble(param: "credits_to_send")
                    self.signed = dataDic.parseBool(param: "signed")
                    self.recordings.removeAll()
                    if let arry = dataDic["recordings"] as? [NSDictionary]{
                        for item in arry{
                            self.recordings.append(MRecording.init(dict: item))
                        }
                    }
                    self.voices.removeAll()
                    let voicePro = MVoice()
                    voicePro.name = "--- Pro Voices ---"
                    self.voices.append(voicePro)
                    if let arry = dataDic["pro_voices"] as? [NSDictionary]{
                        for item in arry{
                            self.voices.append(MVoice.init(dict: item))
                        }
                    }
                    
                    if let arry = dataDic["user_voices"] as? [NSDictionary]{
                        if arry.count > 0{
                            let voiceUser = MVoice()
                            voiceUser.name = "--- Your Cloned Voices ---"
                            self.voices.append(voiceUser)
                            for item in arry{
                                self.voices.append(MVoice.init(dict: item))
                            }
                        }
                    }
                    self.scripts.removeAll()
                    if let arry = dataDic["scripts"] as? [NSDictionary]{
                        for item in arry{
                            self.scripts.append(MScript.init(dict: item))
                        }
                    }
                    self.groups.removeAll()
                    if let arry = dataDic["contact_groups"] as? [NSDictionary]{
                        for item in arry{
                            self.groups.append(MContactGroup.init(dict: item))
                        }
                    }
                    self.contacts.removeAll()
                    if let arry = dataDic["contacts"] as? [NSDictionary]{
                        for item in arry{
                            self.contacts.append(MContacts.init(dict: item))
                        }
                    }
                    DispatchQueue.main.async {
                        self.setUI()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
}

extension SendVoicemailsVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        hideMenu()
        switch index {
        case 0:
            moveRecordingsVC()
            break
        case 1:
            moveVoicesVC(type: 1) // Pro Voices
            break
        case 2:
            moveVoicesVC(type: 0) // Your Cloned Voices
            break
        case 3:
            moveScriptsVC()
            break
        case 4:
            movePastVoicemailsVC(type: type)
            break
        case 5:
            moveContacts()
            break
        case 6:
            moveCredits()
            break
        case 7:
            moveAccount()
            break
        case 8:
            moveFAQ()
            break
        case 9:
            onLogout()
            break
        default:
            break
        }
    }
}

extension SendVoicemailsVC: SelectDelegate{
    func onSelect(id: String, type: Int) {
        
    }
    
    func onSelect(index: Int) {
        dismiss(animated: true)
        if spinnerType == 0{
            self.audioIndex = index
            lAudioSpinnerValue.text = type == 0 ? recordings[audioIndex].name  : voices[audioIndex].name
            audioPlayer.stop()
            playButton.isEnabled = true
            loadAudio(audioUrl: type == 0 ? recordings[audioIndex].url  : voices[audioIndex].url)
        }else if spinnerType == 1{
            scriptIndex = index
            lScriptSpinnerValue.text = scriptIndex == 0 ? "Manual Input"  : scripts[scriptIndex-1].name
            tContent.text = scriptIndex == 0 ? "" : scripts[scriptIndex-1].salutation == "" ? scripts[scriptIndex-1].content : "\(scripts[scriptIndex-1].salutation)\n\(scripts[scriptIndex-1].content)"
            
            if scriptIndex == 0{
                salutationIndex = 7
            }else if scripts[scriptIndex-1].salutation == ""{
                salutationIndex = 7
            }else{
                for i in 0..<salutations.count{
                    if salutations[i].elementsEqual(scripts[scriptIndex-1].salutation){
                        salutationIndex = i
                        break
                    }
                }
            }
            lSalutationSpinnerValue.text = salutations[salutationIndex]
            if scriptIndex == 0{
                tContent.text = salutationIndex == 7 ? "" : salutations[salutationIndex]
            }else{
                tContent.text = salutationIndex == 7 ? scripts[scriptIndex-1].content : "\(salutations[salutationIndex])\n\(scripts[scriptIndex-1].content)"
            }
        }else if spinnerType == 2{
            salutationIndex = index
            lSalutationSpinnerValue.text = salutations[salutationIndex]
            if scriptIndex == 0{
                tContent.text = salutationIndex == 7 ? "" : salutations[salutationIndex]
            }else{
                tContent.text = salutationIndex == 7 ? scripts[scriptIndex-1].content : "\(salutations[salutationIndex])\n\(scripts[scriptIndex-1].content)"
            }
        }else{
            if index == 0{
                groupId = ""
            }else{
                groupId = groups[index-1].id
            }
            setContactsInfo()
        }
    }
}
