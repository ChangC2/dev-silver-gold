//
//  RecordingCell.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/4/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit

class ScriptCell: UITableViewCell {
    
    @IBOutlet weak var vBack: UIView!
    @IBOutlet var lName: UILabel!
    @IBOutlet var lContent: UILabel!
    var delegate: ClickDelegate?
    var ind = 0
    var script = MScript()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        vBack.setBorder5()
    }
    
    func generateCell(script: MScript){
        self.script = script
        lName.text = script.name
        lContent.text = script.content
    }
    
    
    @IBAction func bEditTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 1)
    }
    
    @IBAction func bDeleteTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 2)
    }
    
}
