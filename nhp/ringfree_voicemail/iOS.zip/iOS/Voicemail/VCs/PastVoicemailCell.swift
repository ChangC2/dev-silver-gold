//
//  OrderCell.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit

class PastVoicemailCell: UITableViewCell {

    @IBOutlet var vBack: UIView!
    @IBOutlet var lOrderNo: UILabel!
    @IBOutlet var lType: UILabel!
    @IBOutlet var lDetails: UILabel!
    @IBOutlet var lTime: UILabel!
    @IBOutlet var bViewContent: UIButton!
    @IBOutlet weak var bCancel: UIButton!
    
    var delegate: ClickDelegate?
    var index = 0
    var order = MOrder()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        vBack.setBorder5()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func generateCell(order: MOrder){
        self.order = order
        lOrderNo.text = "Order Number : \(order.order_no)"
        lType.text = order.type == 0 ? "Pre-Recorded Audio" : "AIValet Voice"
        lDetails.text = order.status == 1 ? "Records:\(order.record_count)  Queue:\(order.queue)  Success:\(order.success)  Failed:\(order.fail) \nCredits Used : \((GV.credits_to_send * Double(order.success)).rounded(toPlaces: 1))" : "Records:\(order.record_count)   Credits Hold : \((GV.credits_to_send * Double(order.record_count)).rounded(toPlaces: 1))"
        lTime.text = order.send_time.isEmpty ? order.created_at.dateFromString(format: .dateTimeee)?.stringFromDate(format: .MMddyyyyHHmm) : order.send_time.dateFromString(format: .dateTimeee)?.stringFromDate(format: .MMddyyyyHHmm)
        bViewContent.setTitle(order.type == 0 ? "Play Recording" : "View Content", for: .normal)
        bCancel.isHidden = order.status == 1
    }

    @IBAction func bViewContentTapped(_ sender: UIButton) {
        delegate?.onClick(index: index, type: 0)
    }
    
    
    @IBAction func bView10Tapped(_ sender: UIButton) {
        delegate?.onClick(index: index, type: 1)
    }
    
    @IBAction func bCancelTapped(_ sender: UIButton) {
        delegate?.onClick(index: index, type: 2)
    }
    
}
