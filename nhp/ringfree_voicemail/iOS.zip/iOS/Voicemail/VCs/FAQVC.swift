//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import WebKit

class FAQVC: BaseVC, WKNavigationDelegate{
    
    @IBOutlet weak var web: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        web.navigationDelegate = self
        GF.showLoading()
        let link = URL(string:"https://leadmarketer.com/el/webeditfiles/31997/Retail_Ringless_Voicemail_FAQ.html")!
        let request = URLRequest(url: link)
        web.load(request)
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!){
        GF.hideLoading()
    }
    

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        GF.hideLoading()
    }
}

