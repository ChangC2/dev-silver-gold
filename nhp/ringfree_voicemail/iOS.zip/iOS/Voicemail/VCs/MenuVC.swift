//
//  MainMenuVC.swift
//  Sagor
//
//  Created by SilverGold on 1/13/21.
//  Copyright © 2021 Sagor. All rights reserved.
//

import UIKit

class MenuVC: BaseVC {
    
    var delegate: ClickDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
// ############### Actions ################ //
    
    @IBAction func vRecordingsTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 0, type: 0)
    }
    
    
    @IBAction func vVoicesTapped(_ sender: UITapGestureRecognizer) {
        //delegate?.onClick(index: 1, type: 0)
    }
    
    @IBAction func vProVoicesTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 1, type: 0)
    }
    
    @IBAction func vYourVoicesTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 2, type: 0)
    }
    
    @IBAction func vScriptsTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 3, type: 0)
    }
    
    
    @IBAction func vPendingOrdersTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 4, type: 0)
    }
    
    @IBAction func vScheduledOrdersTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 4, type: 1)
    }
    
    @IBAction func vDeliveredOrdersTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 4, type: 2)
    }
    
    @IBAction func vContactsTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 5, type: 0)
    }
    
    
    @IBAction func vCreditsTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 6, type: 0)
    }
    
    @IBAction func vAccountTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 7, type: 0)
    }
    
    @IBAction func vFAQTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 8, type: 0)
    }
    
    @IBAction func vCloseTapped(_ sender: UITapGestureRecognizer) {
        delegate?.onClick(index: 9, type: 0)
    }
    
    
}

