//
//  RecordingCell.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/4/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit

class ContactGroupCell: UITableViewCell {
    
    
    @IBOutlet weak var vBack: UIView!
    @IBOutlet var lName: UILabel!
    @IBOutlet var lTime: UILabel!
    
    var delegate: ClickDelegate?
    var ind = 0
    var group = MContactGroup()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        vBack.setCornerRadius(radius: 8)
        vBack.setBorder(color: .lightGray, width: 1)
    }
    
    func generateCell(group: MContactGroup){
        self.group = group
        lName.text = group.name
        lTime.text = group.created_at.dateFromString(format: .dateTimeee)?.stringFromDate(format: .MMddyyyyHHmm)
    }
    
    
    
    
     @IBAction func bEditTapped(_ sender: UIButton) {
         delegate?.onClick(index: ind, type: 0)
     }
     
     @IBAction func bDeleteTapped(_ sender: UIButton) {
         delegate?.onClick(index: ind, type: 1)
     }
}
