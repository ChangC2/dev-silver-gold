//
//  SendRecordVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/21/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire

class ConfirmVoicemailVC: BaseVC {
    
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var remainingTimeLabel: UILabel!
    @IBOutlet weak var elapsedTimeLabel: UILabel!
    @IBOutlet var lContacts: UILabel!
    @IBOutlet var lForwardingNumber: UILabel!
    @IBOutlet var lCosts: UILabel!
    @IBOutlet var bCheck: UIButton!
    @IBOutlet var bSendNow: UIButton!
    
    var contacts = [MContacts]()
    var groupId = ""
    
    var type = 0
    var msgContent = ""
    var voiceId = ""
    var audioUrl = ""
    var previewUrl = ""
    var audioName = "Play Recording"
    let audioPlayer = AudioPlayer()
    var isScheduled = false
    var sendTime = ""
    var break_up = false
    var broadcasts_number = 1
    var between_days = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.slider.setThumbImage(UIImage(named: "ic_green_dot"), for: .normal)
        
        audioPlayer.event.stateChange.addListener(self, handleAudioPlayerStateChange)
        audioPlayer.remoteCommands = [
            .play,
            .pause,
            .skipForward(preferredIntervals: [30]),
            .skipBackward(preferredIntervals: [30]),
        ]
        
        loadAudio()
        loadData()
        
        audioPlayer.event.stateChange.addListener(self, handleAudioPlayerStateChange)
        audioPlayer.event.secondElapse.addListener(self, handleAudioPlayerSecondElapsed)
        audioPlayer.event.seek.addListener(self, handleAudioPlayerDidSeek)
        audioPlayer.event.updateDuration.addListener(self, handleAudioPlayerUpdateDuration)
        audioPlayer.event.fail.addListener(self, handlePlayerFailure)
        updateMetaData()
        handleAudioPlayerStateChange(data: audioPlayer.playerState)
    }
    
    func loadAudio(){
        if let url = URL(string: previewUrl) {
            GF.showLoading()
            GF.loadData(url: url) { (url, error) in
                GF.hideLoading()
                if url == "" || error != nil{
                    GF.showToast(msg: "Error loading audio")
                    return
                }
                DispatchQueue.main.async {
                    let audioItem = DefaultAudioItem(audioUrl: url, sourceType: .stream)
                    try? self.audioPlayer.load(item: audioItem, playWhenReady: false) // Load the item and start playing when the player is ready.
                }
            }
        }
    }
    
    func loadData(){
        lContacts.text = "# of Records : \(contacts.count)"
        lForwardingNumber.text = "Forwarding Number : \(GV.forwarding_number)"
        lCosts.text = String(format: "*%.1f Credits Availalbe.You need %.1f credits to send this message.", GV.credits, Double(contacts.count) * GV.credits_to_send)
        
        bSendNow.isEnabled = false
        bSendNow.alpha = 0.5
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        audioPlayer.stop()
    }
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func togglePlay(_ sender: Any) {
        audioPlayer.togglePlaying()
    }
    
    @IBAction func bSendNowTapped(_ sender: UIButton) {
        self.apiCallForCheckExistInOrder()
    }
    
    @IBAction func bSendTestTapped(_ sender: UIButton) {
        GF.showAlertViewWithTitle("", message: "The test voicemail will be sent to the phone on account!", buttonTitles: ["Yes", "Cancel"], viewController: self, completion: {result in
            if result == 0 {
                self.apiCallForSaveTestMailLog()
            }
        })
    }
    
    
    @IBAction func bView10Tapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "ContactsVC") as?  ContactsVC{
            vc.groupId = self.groupId
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func bCheckTapped(_ sender: UIButton) {
        bCheck.isSelected = !bCheck.isSelected
        bSendNow.isEnabled = bCheck.isSelected
        bSendNow.alpha = bCheck.isSelected ? 1 : 0.5
    }
    
    
    func updateTimeValues() {
        self.slider.maximumValue = Float(self.audioPlayer.duration)
        self.slider.setValue(Float(self.audioPlayer.currentTime), animated: true)
        self.elapsedTimeLabel.text = self.audioPlayer.currentTime.secondsToString()
        self.remainingTimeLabel.text = self.audioPlayer.duration.secondsToString()
    }
    
    func updateMetaData() {
    }
    
    func setPlayButtonState(forAudioPlayerState state: AudioPlayerState) {
        playButton.setImage(state == .playing ? UIImage(named: "ic_player_pause")! : UIImage(named: "ic_player_play")!, for: .normal)
    }
    
    
    // MARK: - AudioPlayer Event Handlers
    func handleAudioPlayerStateChange(data: AudioPlayer.StateChangeEventData) {
        print(data)
        DispatchQueue.main.async {
            self.setPlayButtonState(forAudioPlayerState: data)
            switch data {
            case .loading:
                self.updateMetaData()
                self.updateTimeValues()
            case .buffering: break
            case .ready:
                self.updateMetaData()
                self.updateTimeValues()
            case .playing, .idle:
                self.updateTimeValues()
            case .paused:
                if self.slider.value == self.slider.maximumValue{
                    self.audioPlayer.seek(to: 0)
                }
            }
        }
    }
    
    func handleAudioPlayerSecondElapsed(data: AudioPlayer.SecondElapseEventData) {
        DispatchQueue.main.async {
            self.updateTimeValues()
        }
    }
    
    func handleAudioPlayerDidSeek(data: AudioPlayer.SeekEventData) {
    }
    
    func handleAudioPlayerUpdateDuration(data: AudioPlayer.UpdateDurationEventData) {
        DispatchQueue.main.async {
            self.updateTimeValues()
        }
    }
    
    func handlePlayerFailure(data: AudioPlayer.FailEventData) {
        GF.hideLoading()
    }
    
    func apiCallForCheckExistInOrder() {
        GF.showLoading()
        let params: Parameters = ["token": "\(GF.getToken())",
                                  "type": "\(self.type)",
                                  "audioUrl": "\(self.audioUrl)"]
        
        API.postRequest(api: API.checkExistInOrder, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: "You recently sent a message to this same group within last 24 hours. Please confirm you want to do this by clicking Yes or clicking Cancel.", buttonTitles: ["Yes", "Cancel"], viewController: self, completion: {result in
                            if result == 0 {
                                self.apiCallForSaveMailLog()
                            }else{
                                self.navigationController?.popViewController(animated: true)
                            }
                            
                        })
                    }
                }else{
                    self.apiCallForSaveMailLog()
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForSaveMailLog() {
        GF.showLoading()
        let params: Parameters = ["token": "\(GF.getToken())",
                                  "type": "\(self.type)",
                                  "forwarding_number": "\(GV.forwarding_number)",
                                  "selected_group": "\(self.groupId)",
                                  "record_name": "\(self.audioName)",
                                  "audioUrl": "\(self.audioUrl)",
                                  "content": type == 1 ? msgContent : "",
                                  "voice_id": type == 1 ? voiceId : "",
                                  "send_time": isScheduled ? sendTime : "",
                                  "break_up": "\(break_up)",
                                  "broadcasts_number": broadcasts_number,
                                  "between_days":between_days
                                  ]
        
        API.postRequest(api: API.saveMailLog, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: "Your Voice messages are now in Queue.  You can go to Past Sessions on Left menu to check Status.   You will get an email when they are all sent.", buttonTitles: ["Ok"], viewController: self, completion: {result in
                            self.navigationController?.popViewController(animated: true)
                        })
                    }
                }else{
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: dict.parseString(param: "message"), buttonTitles: ["Ok"], viewController: self, completion: {result in
                            self.navigationController?.popViewController(animated: true)
                        })
                    }
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForSaveTestMailLog() {
        GF.showLoading()
        let params: Parameters = ["token": "\(GF.getToken())",
                                  "type": "\(self.type)",
                                  "forwarding_number": "\(GV.forwarding_number)",
                                  "record_name": "\(self.audioName)",
                                  "audioUrl": "\(self.audioUrl)",
                                  "content": type == 1 ? msgContent : "",
                                  "voice_id": type == 1 ? voiceId : ""
                                  ]
        
        API.postRequest(api: API.saveTestMailLog, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: "Your test message is now in Queue.  You can go to Past Voicemails on Left menu to check Status. You will get an email when it is sent.", buttonTitles: ["Ok"], viewController: self, completion: {result in
                        })
                    }
                }else{
                    DispatchQueue.main.async {
                        GF.showAlertViewWithTitle("", message: dict.parseString(param: "message"), buttonTitles: ["Ok"], viewController: self, completion: {result in
                        })
                    }
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    
}
