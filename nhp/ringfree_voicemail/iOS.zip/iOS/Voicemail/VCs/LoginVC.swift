//
//  LoginVC.swift
//  seemesave
//
//  Created by XiaoYan on 6/16/22.
//

import UIKit
import CountryPickerView
import Alamofire

class LoginVC: BaseVC {
    
    @IBOutlet weak var vEmailContainer: UIView!
    
    @IBOutlet weak var vEmail: UIView!
    @IBOutlet weak var vPass: UIView!
    @IBOutlet weak var tEmail: UITextField!
    @IBOutlet weak var tPass: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
  
    @IBAction func bForgotPassTapped(_ sender: UIButton) {
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "ForgotPassVC") as? ForgotPassVC {
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func bSignInTapped(_ sender: UIButton) {
        apiCallForLoginWithEmail()
    }
    
    @IBAction func bSignUpTapped(_ sender: UIButton) {
        GF.goRegisterVC()
    }
    
    func initUI(){
        vEmail.setBorder(color: .lightGray, width: 1)
        vEmail.setCornerRadius(radius: 10)
        
        vPass.setBorder(color: .lightGray, width: 1)
        vPass.setCornerRadius(radius: 10)
     
        tEmail.text = "mzhou9954@gmail.com"
        tPass.text = "123456"
    }
}

//***************************************//
//           Mark - Extentions           //
//***************************************//


//***************************************//
//         Mark - API Call               //
//***************************************//
extension LoginVC{
    
    func apiCallForLoginWithEmail() {
        if !tEmail.isValidEmail || tPass.isEmpty{
            GF.showToastMissingParam()
            return
        }

        let params: Parameters = ["email": tEmail.text!,
                                  "password" : tPass.text!]
        GF.showLoading()
        API.postRequest(api: API.login_account, params: params, completion: { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    userDefault.set(true, forKey: C.IS_LOGINED)
                    userDefault.set(dict.parseString(param: "token"), forKey: C.TOKEN)
                    GF.goMainVC()
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    
}
