//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire

class VoicesVC: BaseVC {
    
    @IBOutlet var lTitle: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet var lEmpty: UILabel!
    @IBOutlet weak var bAdd: UIButton!
    
    var voices = [MVoice]()
    var type = 0 // 0 : Your Cloned Voice, 1 : Pro Voice
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bottomSheetTransitioningDelegate = BottomSheetTransitioningDelegate(
            contentHeights: [330, UIScreen.main.bounds.size.height - 200],
            presentationDelegate: self
        )
        
        lTitle.text = type == 0 ? "Your Cloned Voices" : "Pro Voices"
        bAdd.isHidden = type == 1
        apiCallForGetVoice()
    }
    
    
    func setUI(){
        tableView.reloadData()
        if voices.count == 0{
            lEmpty.showView()
            onRecord()
        }else{
            lEmpty.hideView()
        }
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func bAddVoiceTapped(_ sender: UIButton) {
        onRecord()
    }
    
    func onRecord(){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "VoiceRecordVC") as?  VoiceRecordVC{
            vc.delegate = self
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    
    
    func playVoice(index: Int){
        let stb = UIStoryboard(name: "Main", bundle: nil)
        if let vc = stb.instantiateViewController(withIdentifier: "AudioPlayerVC") as?  AudioPlayerVC{
            var order = MOrder()
            order.type = 0
            order.url = voices[index].url
            order.record_name = voices[index].name
            vc.order = order
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    func refreshTable(index: Int, voice: MVoice){
        if (index == -1){
            voices.insert(voice, at: 0)
        }else{
            voices[index].name = voice.name
            voices[index].url = voice.url
        }
        tableView.reloadData()
    }
    
    func apiCallForGetVoice() {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken()]
        
        API.postRequest(api: API.getVoices, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    if let arry = dict[self.type == 0 ? "user_voices" : "pro_voices"] as? [NSDictionary]{
                        for item in arry{
                            self.voices.append(MVoice.init(dict: item))
                        }
                    }
                    DispatchQueue.main.async {
                        self.setUI()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForDeleteVoice(index: Int) {
        GF.showLoading()
        let params: Parameters = ["id": "\(voices[index].id)"]
        
        API.postRequest(api: API.deleteVoice, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    self.voices.remove(at: index)
                    DispatchQueue.main.async {
                        self.setUI()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
}

extension VoicesVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return voices.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "VoiceCell") as! VoiceCell
        cell.selectionStyle = .none
        cell.delegate = self
        cell.ind = indexPath.row
        cell.bEdit.isHidden = self.type == 1
        cell.bDel.isHidden = self.type == 1
        cell.generateCell(voice: voices[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}


extension VoicesVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        switch (type){
        case 0://Play Audio
            playVoice(index: index)
            break
        case 1://Edit Voice
            let stb = UIStoryboard(name: "Main", bundle: nil)
            if let vc = stb.instantiateViewController(withIdentifier: "VoiceRecordVC") as?  VoiceRecordVC{
                vc.voice = voices[index]
                vc.index = index
                vc.delegate = self
                self.present(vc, animated: true, completion: nil)
            }
            break
        case 2://Delete Voice
            apiCallForDeleteVoice(index: index)
            break
        default:
            break
        }
    }
}

extension VoicesVC: RefreshVoiceDelegate{
    func refresh(index: Int, voice: MVoice){
        refreshTable(index: index, voice: voice)
    }
}

