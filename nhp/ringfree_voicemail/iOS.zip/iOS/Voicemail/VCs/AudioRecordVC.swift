//
//  AudioPlayerVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/7/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer
import Alamofire

class AudioRecordVC: UIViewController {
    
    @IBOutlet weak var vCenter: UIView!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var remainingTimeLabel: UILabel!
    @IBOutlet weak var elapsedTimeLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet var recordButton: UIButton!
    @IBOutlet var tName: UITextField!
    @IBOutlet var bCheck: UIButton!
    @IBOutlet var bSave: UIButton!
    @IBOutlet var vPlayer: UIView!
    
    var record: MRecording?
    var index = 0
    let audioPlayer = AudioPlayer()
    
    var recordingSession: AVAudioSession!
    var audioRecorder: AVAudioRecorder!
    var audioFilename: URL? = nil
    
    var delegate: RefreshRecordingDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        self.vCenter.setBorder3()
        bSave.isEnabled = false
        bSave.alpha = 0.5
        // Do any additional setup after loading the view.
        
        initPlayer()
        initRecorder()
    }
    
    func initPlayer(){
        vPlayer.hideView()
        recordButton.backgroundColor = UIColor(cgColor: .init(red: 81 / 255, green: 86 / 255, blue: 190 / 255, alpha: 1))
        self.slider.setThumbImage(UIImage(named: "ic_green_dot"), for: .normal)
        
        audioPlayer.event.stateChange.addListener(self, handleAudioPlayerStateChange)
        audioPlayer.remoteCommands = [
            .play,
            .pause,
            .skipForward(preferredIntervals: [30]),
            .skipBackward(preferredIntervals: [30]),
        ]
        
        // Load the item and start playing when the player is ready.
        
        audioPlayer.event.stateChange.addListener(self, handleAudioPlayerStateChange)
        audioPlayer.event.secondElapse.addListener(self, handleAudioPlayerSecondElapsed)
        audioPlayer.event.seek.addListener(self, handleAudioPlayerDidSeek)
        audioPlayer.event.updateDuration.addListener(self, handleAudioPlayerUpdateDuration)
        audioPlayer.event.fail.addListener(self, handlePlayerFailure)
        updateMetaData()
        handleAudioPlayerStateChange(data: audioPlayer.playerState)
    }
    
    func initRecorder(){
        recordingSession = AVAudioSession.sharedInstance()
        do {
            try recordingSession.setCategory(.playAndRecord, mode: .default)
            try recordingSession.setActive(true)
            recordingSession.requestRecordPermission { [unowned self] allowed in
                DispatchQueue.main.async {
                    if allowed {
                        self.loadRecordingUI()
                    } else {
                        // failed to record
                    }
                }
            }
        } catch {
            // failed to record!
        }
    }
    
    func loadRecordingUI() {
        recordButton.isEnabled = true
        playButton.isEnabled = false
        if record != nil{
            tName.text = record!.name
        }
        recordButton.setTitle("Tap to Record", for: .normal)
    }
    
    
    @IBAction func bCancalTapped(_ sender: Any) {
        audioPlayer.stop()
        dismiss(animated: true)
    }
    
    @IBAction func togglePlay(_ sender: Any) {
        if audioFilename == nil{
            return
        }
        let audioItem = DefaultAudioItem(audioUrl: audioFilename!.absoluteString, sourceType: .stream)
        try? audioPlayer.load(item: audioItem, playWhenReady: false)
        audioPlayer.togglePlaying()
    }
    
    
    @IBAction func bRecordTapped(_ sender: UIButton) {
        if audioRecorder == nil {
            audioPlayer.stop()
            vPlayer.hideView()
            recordButton.backgroundColor = .red
            startRecording()
        } else {
            vPlayer.showView()
            recordButton.backgroundColor = UIColor(cgColor: .init(red: 81 / 255, green: 86 / 255, blue: 190 / 255, alpha: 1))
            finishRecording(success: true)
        }
    }
    
    @IBAction func bCheckTapped(_ sender: UIButton) {
        bCheck.isSelected = !bCheck.isSelected
        bSave.isEnabled = bCheck.isSelected
        bSave.alpha = bCheck.isSelected ? 1 : 0.5
    }
    
    @IBAction func bSaveTapped(_ sender: UIButton) {
        if !playButton.isEnabled && record == nil{
            GF.showToast(msg: "Please record voice.")
            return
        }
        if tName.isEmpty{
            GF.showToast(msg: "Please input name.")
            return
        }
        if record == nil{
            apiCallForUploadRecording()
        }else{
            apiCallForUpdateRecording()
        }
    }
    
    func startRecording() {
        audioFilename = GF.getDocumentsDirectory().appendingPathComponent(UUID().uuidString + "_recording.wav")
        let settings = [
            AVFormatIDKey: Int(kAudioFormatLinearPCM),
            AVSampleRateKey: 44100,
            AVNumberOfChannelsKey: 2,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue,
            AVLinearPCMBitDepthKey: 16,
            AVLinearPCMIsFloatKey: false
        ] as [String : Any]
        
        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename!, settings: settings)
            audioRecorder.delegate = self
            audioRecorder.record()
            
            recordButton.setTitle("Tap to Stop", for: .normal)
        } catch {
            finishRecording(success: false)
        }
    }
    
    func finishRecording(success: Bool) {
        audioRecorder.stop()
        audioRecorder = nil
        
        if success {
            recordButton.setTitle("Tap to Re-record", for: .normal)
            //playButton.setTitle("Play Your Recording", for: .normal)
            playButton.isEnabled = true
            let audioItem = DefaultAudioItem(audioUrl: audioFilename!.absoluteString, sourceType: .stream)
            try? audioPlayer.load(item: audioItem, playWhenReady: false)
            audioPlayer.togglePlaying()
             // Load the item and start
        } else {
            recordButton.setTitle("Tap to Record", for: .normal)
            playButton.isEnabled = false
            // recording failed :(
        }
    }
    
    func updateTimeValues() {
        self.slider.maximumValue = Float(self.audioPlayer.duration)
        self.slider.setValue(Float(self.audioPlayer.currentTime), animated: true)
        self.elapsedTimeLabel.text = self.audioPlayer.currentTime.secondsToString()
        self.remainingTimeLabel.text = self.audioPlayer.duration.secondsToString()
    }
    
    func updateMetaData() {
        if record != nil{
            titleLabel.text = "Edit Recording"
        }
    }
    
    func setPlayButtonState(forAudioPlayerState state: AudioPlayerState) {
        playButton.setImage(state == .playing ? UIImage(named: "ic_player_pause")! : UIImage(named: "ic_player_play")!, for: .normal)
    }
    
    
    // MARK: - AudioPlayer Event Handlers
    func handleAudioPlayerStateChange(data: AudioPlayer.StateChangeEventData) {
        print(data)
        DispatchQueue.main.async {
            self.setPlayButtonState(forAudioPlayerState: data)
            switch data {
            case .loading:
                self.updateMetaData()
                self.updateTimeValues()
            case .buffering: break
            case .ready:
                self.updateMetaData()
                self.updateTimeValues()
            case .playing, .idle:
                self.updateTimeValues()
            case .paused:
                if self.slider.value == self.slider.maximumValue{
                    self.audioPlayer.seek(to: 0)
                }
            }
        }
    }
    
    func handleAudioPlayerSecondElapsed(data: AudioPlayer.SecondElapseEventData) {
        DispatchQueue.main.async {
            self.updateTimeValues()
        }
    }
    
    func handleAudioPlayerDidSeek(data: AudioPlayer.SeekEventData) {
    }
    
    func handleAudioPlayerUpdateDuration(data: AudioPlayer.UpdateDurationEventData) {
        DispatchQueue.main.async {
            self.updateTimeValues()
        }
    }
    
    func handlePlayerFailure(data: AudioPlayer.FailEventData) {
    }
    
    func apiCallForUploadRecording(){
        if audioFilename == nil{
            return
        }
        GF.showLoading()
        if let url = URL(string: "\(API.BaseUrl)/addRecording"), API.isConnectedNetwork(){
            AF.upload(multipartFormData: { multipartFormData in
                if let videoData = try? Data(contentsOf: self.audioFilename!){
                    multipartFormData.append(videoData, withName: "file", fileName: "recording.wav", mimeType: "audio/wav")
                }
                
                multipartFormData.append("\(GF.getToken())".data(using: String.Encoding.utf8)!, withName: "token")
                multipartFormData.append("\(self.tName.text!)".data(using: String.Encoding.utf8)!, withName: "name")
                
            }, to: url)
            .responseData { (response) in
                GF.hideLoading()
                switch response.result {
                case .success(let data):
                    do {
                        if let dic =  try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary{
                            if dic.parseBool(param: "status"), let recDic = dic["record"] as? NSDictionary{
                                let newRecord = MRecording.init(dict: recDic)
                                GF.showAlertViewWithTitle("", message: "Congrats ! You saved your Recording", buttonTitles: ["OK"], viewController: self, completion: {result in
                                    self.delegate?.refresh(index: -1, record: newRecord)
                                    self.navigationController?.popViewController(animated: true)
                                })
                            }else{
                                GF.showToastNetworkError()
                            }
                        }else{
                            GF.showToastNetworkError()
                        }
                    } catch {
                        GF.showToastNetworkError()
                    }
                    
                    break
                case .failure(_):
                    GF.showToastNetworkError()
                    break
                }
            }
        }else{
            GF.hideLoading()
            GF.showToastNetworkError()
        }
    }
    
    func apiCallForUpdateRecording(){
        GF.showLoading()
        if let url = URL(string: "\(API.BaseUrl)/updateRecording"), API.isConnectedNetwork(){
            AF.upload(multipartFormData: { multipartFormData in
                if self.playButton.isEnabled && self.audioFilename != nil{
                    if let videoData = try? Data(contentsOf: self.audioFilename!){
                        multipartFormData.append(videoData, withName: "file", fileName: "recording.wav", mimeType: "audio/wav")
                    }
                }
                multipartFormData.append("\(self.tName.text!)".data(using: String.Encoding.utf8)!, withName: "name")
                multipartFormData.append("\(self.record!.id)".data(using: String.Encoding.utf8)!, withName: "id")
                
            }, to: url)
            .responseData { (response) in
                GF.hideLoading()
                switch response.result {
                case .success(let data):
                    do {
                        if let dic =  try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary{
                            if dic.parseBool(param: "status"), let recDic = dic["record"] as? NSDictionary{
                                let newRecord = MRecording.init(dict: recDic)
                                GF.showAlertViewWithTitle("", message: "Congrats ! You saved your Recording", buttonTitles: ["OK"], viewController: self, completion: {result in
                                    self.delegate?.refresh(index: self.index, record: newRecord)
                                    self.navigationController?.popViewController(animated: true)
                                })
                            }else{
                                GF.showToastNetworkError()
                            }
                        }else{
                            GF.showToastNetworkError()
                        }
                    } catch {
                        GF.showToastNetworkError()
                    }
                    
                    break
                case .failure(_):
                    GF.showToastNetworkError()
                    break
                }
            }
        }else{
            GF.hideLoading()
            GF.showToastNetworkError()
        }
    }
}

extension AudioRecordVC: AVAudioRecorderDelegate {
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if !flag {
            finishRecording(success: false)
        }
    }
    
}
