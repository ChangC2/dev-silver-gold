//
//  RecordingCell.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/4/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit

class RecordingCell: UITableViewCell {
    
    @IBOutlet weak var vBack: UIView!
    @IBOutlet var lName: UILabel!
    @IBOutlet var lTime: UILabel!
    var delegate: ClickDelegate?
    var ind = 0
    var record = MRecording()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        vBack.setCornerRadius(radius: 8)
        vBack.setBorder(color: .lightGray, width: 1)
    }
    
    func generateCell(record: MRecording){
        self.record = record
        lName.text = record.name.capitalizingFirstLetter()
        lTime.text = record.created_at.dateFromString(format: .dateTimeee)?.stringFromDate(format: .MMddyyyyHHmm)
    }
    
    @IBAction func bPlayTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 0)
    }
    
    @IBAction func bEditTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 1)
    }
    
    @IBAction func bDeleteTapped(_ sender: UIButton) {
        delegate?.onClick(index: ind, type: 2)
    }
    
}
