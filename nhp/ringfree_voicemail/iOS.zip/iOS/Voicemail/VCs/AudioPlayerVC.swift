//
//  AudioPlayerVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/7/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer

class AudioPlayerVC: UIViewController {
    
    @IBOutlet weak var vCenter: UIView!
    @IBOutlet var vAudio: UIView!
    @IBOutlet var vMsgContent: UIView!
    @IBOutlet var lMsgContent: UILabel!
    
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var remainingTimeLabel: UILabel!
    @IBOutlet weak var elapsedTimeLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    
    var order = MOrder()
    let audioPlayer = AudioPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        self.vCenter.setBorder3()
        
        titleLabel.text = order.type == 0 ? "\(order.record_name)" : "AI Avatar Voice: \(order.record_name)"
        self.slider.setThumbImage(UIImage(named: "ic_green_dot"), for: .normal)
        
        audioPlayer.event.stateChange.addListener(self, handleAudioPlayerStateChange)
        audioPlayer.remoteCommands = [
            .play,
            .pause,
            .skipForward(preferredIntervals: [30]),
            .skipBackward(preferredIntervals: [30]),
        ]
        
        loadAudio()
        
        audioPlayer.event.stateChange.addListener(self, handleAudioPlayerStateChange)
        audioPlayer.event.secondElapse.addListener(self, handleAudioPlayerSecondElapsed)
        audioPlayer.event.seek.addListener(self, handleAudioPlayerDidSeek)
        audioPlayer.event.updateDuration.addListener(self, handleAudioPlayerUpdateDuration)
        audioPlayer.event.fail.addListener(self, handlePlayerFailure)
        updateMetaData()
        handleAudioPlayerStateChange(data: audioPlayer.playerState)
        
        // Do any additional setup after loading the view.
        if order.type == 0{
            vMsgContent.hideView()
        }else{
            vMsgContent.showView()
            lMsgContent.text = "\(order.content)"
        }
    }
    
    func loadAudio(){
        if let url = URL(string: order.url) {
            GF.showLoading()
            GF.loadData(url: url) { (url, error) in
                GF.hideLoading()
                if url == "" || error != nil{
                    GF.showToast(msg: "Error loading audio")
                    return
                }
                DispatchQueue.main.async {
                    let audioItem = DefaultAudioItem(audioUrl: url, sourceType: .stream)
                    try? self.audioPlayer.load(item: audioItem, playWhenReady: true) // Load the item and start playing when the player is ready.
                }
            }
        }
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        audioPlayer.stop()
    }
    
    @IBAction func bCancalTapped(_ sender: Any) {
        audioPlayer.stop()
        dismiss(animated: true)
    }
    
    
    
    @IBAction func togglePlay(_ sender: Any) {
        audioPlayer.togglePlaying()
    }
    
    func updateTimeValues() {
        self.slider.maximumValue = Float(self.audioPlayer.duration)
        self.slider.setValue(Float(self.audioPlayer.currentTime), animated: true)
        self.elapsedTimeLabel.text = self.audioPlayer.currentTime.secondsToString()
        self.remainingTimeLabel.text = self.audioPlayer.duration.secondsToString()
    }
    
    func updateMetaData() {
        
    }
    
    func setPlayButtonState(forAudioPlayerState state: AudioPlayerState) {
        playButton.setImage(state == .playing ? UIImage(named: "ic_player_pause")! : UIImage(named: "ic_player_play")!, for: .normal)
    }
    
    
    // MARK: - AudioPlayer Event Handlers
    func handleAudioPlayerStateChange(data: AudioPlayer.StateChangeEventData) {
        print(data)
        DispatchQueue.main.async {
            self.setPlayButtonState(forAudioPlayerState: data)
            switch data {
            case .loading:
                self.updateMetaData()
                self.updateTimeValues()
            case .buffering: break
            case .ready:
                self.updateMetaData()
                self.updateTimeValues()
            case .playing, .idle:
                self.updateTimeValues()
            case .paused:
                if self.slider.value == self.slider.maximumValue{
                    self.audioPlayer.seek(to: 0)
                }
            }
        }
    }
    
    func handleAudioPlayerSecondElapsed(data: AudioPlayer.SecondElapseEventData) {
        DispatchQueue.main.async {
            self.updateTimeValues()
        }
    }
    
    func handleAudioPlayerDidSeek(data: AudioPlayer.SeekEventData) {
    }
    
    func handleAudioPlayerUpdateDuration(data: AudioPlayer.UpdateDurationEventData) {
        DispatchQueue.main.async {
            self.updateTimeValues()
        }
    }
    
    func handlePlayerFailure(data: AudioPlayer.FailEventData) {
        GF.hideLoading()
    }
    
}
