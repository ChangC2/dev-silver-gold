//
//  ContactGroupVC.swift
//  Voicemail
//
//  Created by XiaoYan on 4/5/24.
//  Copyright © 2024 newhomepage. All rights reserved.
//

import UIKit

class ContactGroupVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var delegate: ClickDelegate?
    var groups = [MContactGroup]()

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.reloadData()
    }
    
    @IBAction func bAddGroupTapped(_ sender: UIButton) {
        self.dismiss(animated: true)
        delegate?.onClick(index: 0, type: 1)
    }
    
    
    @IBAction func bCancelTapped(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
}

extension ContactGroupVC: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groups.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactGroupCell") as! ContactGroupCell
        cell.selectionStyle = .none
        cell.delegate = self
        cell.ind = indexPath.row
        cell.generateCell(group: self.groups[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.dismiss(animated: true)
        delegate?.onClick(index: indexPath.row, type: 0)
    }
}

extension ContactGroupVC: ClickDelegate{
    func onClick(index: Int, type: Int){
        switch (type){
        case 0://Edit
            self.dismiss(animated: true)
            delegate?.onClick(index: index, type: 2)
            break
        case 1://Delete
            delegate?.onClick(index: index, type: 3)
            self.dismiss(animated: true)
            break
        default:
            break
        }
    }
}
