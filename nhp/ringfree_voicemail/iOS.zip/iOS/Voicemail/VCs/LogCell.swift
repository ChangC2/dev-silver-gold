//
//  OrderCell.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit

class LogCell: UITableViewCell {

    @IBOutlet var vBack: UIView!
    @IBOutlet var lForwardingNumber: UILabel!
    @IBOutlet var lPhoneNumber: UILabel!
    @IBOutlet var lStatus: UILabel!
    @IBOutlet var lReason: UILabel!
    @IBOutlet var lTime: UILabel!
    @IBOutlet var lType: UILabel!
    @IBOutlet var bViewContent: UIButton!
    
    var log = MLog()
    var index = 0
    var delegate: ClickDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        vBack.setBorder5()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func generateCell(log: MLog){
        self.log = log
        lType.text = log.type == 0 ? "Pre-Recorded Audio" : "AIValet Voice"
        lForwardingNumber.text = "Forwarding # : \(log.forwarding_number)"
        lPhoneNumber.text = "Phone # : \(log.receiver)"
        lStatus.text = "Status : \(log.status)"
        lReason.text = "Reason : \(log.reason)"
        lTime.text = "Time : \(log.created_at.dateFromString(format: .dateTimeee)?.stringFromDate(format: .MMddyyyyHHmm) ?? "")"
        bViewContent.setTitle(log.type == 0 ? "Play Recording" : "View Content", for: .normal)
    }
    
    @IBAction func bViewContentTapped(_ sender: UIButton) {
        delegate?.onClick(index: index, type:0)
    }

}
