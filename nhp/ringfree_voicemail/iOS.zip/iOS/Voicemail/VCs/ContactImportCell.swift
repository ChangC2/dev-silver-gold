//
//  ContactCell.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 11/9/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit

class ContactImportCell: UITableViewCell {

    @IBOutlet var vBack: UIView!
    @IBOutlet var lName: UILabel!
    @IBOutlet var lPhoneNumber: UILabel!
    @IBOutlet weak var lEmail: UILabel!
    @IBOutlet weak var bSel: UIButton!
    
    var contact = MContacts()
    
    var delegate: ClickDelegate?
    var ind = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        vBack.setCornerRadius(radius: 12)
        vBack.setBorder(color: .lightGray, width: 1)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func generateCell(contact: MContacts){
        self.contact = contact
        lName.text = contact.name
        lPhoneNumber.text = "Mobile Number : \(contact.phone)"
        lEmail.text = "Email Address : \(contact.email)"
        bSel.isSelected = contact.isSelected
    }
    
    @IBAction func bSelTapped(_ sender: UIButton) {
        bSel.isSelected = !bSel.isSelected
        contact.isSelected = !contact.isSelected
    }
    
}
