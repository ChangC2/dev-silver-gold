//
//  ChatGPTVC.swift
//  ChicagoFarming
//
//  Created by XiaoYan on 4/10/23.
//  Copyright © 2023 NewHomePage LLC. All rights reserved.
//

import UIKit
import Alamofire

class AccountVC: BaseVC{
    
    @IBOutlet weak var vEmail: UIView!
    @IBOutlet weak var vName: UIView!
    @IBOutlet weak var vPhone: UIView!
    @IBOutlet weak var vPass: UIView!
    @IBOutlet var vRePass: UIView!
    
    @IBOutlet weak var tEmail: UITextField!
    @IBOutlet weak var tName: UITextField!
    @IBOutlet weak var tPhone: UITextField!
    @IBOutlet weak var tPass: UITextField!
    @IBOutlet var tRePass: UITextField!
    
    var account = MAccount()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        apiCallForGetGetAccount()
    }
    
    func initUI(){
        
        vEmail.setBorder(color: .lightGray, width: 1)
        vEmail.setCornerRadius(radius: 10)
      
        vName.setBorder(color: .lightGray, width: 1)
        vName.setCornerRadius(radius: 10)
        
        vPhone.setBorder(color: .lightGray, width: 1)
        vPhone.setCornerRadius(radius: 10)
        
        vPass.setBorder(color: .lightGray, width: 1)
        vPass.setCornerRadius(radius: 10)
        
        vRePass.setBorder(color: .lightGray, width: 1)
        vRePass.setCornerRadius(radius: 10)
    }
    
    func loadData(){
        tEmail.text = account.email
        tName.text = account.accountname
        tPhone.text = account.mobile_number
    }
    
    
    @IBAction func bBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func bSaveTapped(_ sender: UIButton) {
        apiCallForUpdateAccount()
    }
    
    @IBAction func bDeleteAccountTapped(_ sender: UIButton) {
        let alert = UIAlertController(title: "", message: "Are you sure you want to delete your account?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.0, execute: {
                let alert1 = UIAlertController(title: "", message: "Your deletion request is in process and you will get a confirmation email", preferredStyle: .alert)
                alert1.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                    GF.showLoading()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                        GF.hideLoading()
                        userDefault.set(false, forKey: C.IS_LOGINED)
                        userDefault.set("", forKey: C.TOKEN)
                        GF.goLoginVC()
                    })
                }))
                self.present(alert1, animated: true, completion: nil)
            })
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler:nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func apiCallForGetGetAccount() {
        GF.showLoading()
        let params: Parameters = ["token": GF.getToken()]
        
        API.postRequest(api: API.get_account, params: params, completion:  { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"), let accountDic = dict["account"] as? NSDictionary{
                    self.account = MAccount.init(dict: accountDic)
                    DispatchQueue.main.async {
                        self.loadData()
                    }
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
    func apiCallForUpdateAccount() {
        if tName.isEmpty{
            GF.showToastMissingParam()
            return
        }
        
        if !tPass.text!.elementsEqual(tRePass.text!){
            GF.showToast(msg: "Mismatch Password")
            return
        }

        var params: Parameters = ["token": GF.getToken(),
                                  "accountname": "\(tName.text!)",
                                  "email": tEmail.text!,
                                  "mobile_number": tPhone.text!,
                                  "password" : tPass.text!]
        

        GF.showLoading()
        API.postRequest(api: API.update_account, params: params, completion: { result in
            GF.hideLoading()
            switch result {
            case .success(let dict):
                if dict.parseBool(param: "status"){
                    GF.showToast(msg: "Updated Successfully")
                }else{
                    GF.showToast(msg: dict.parseString(param: "message"))
                }
            case .failure(let err_msg):
                GF.showToast(msg: err_msg)
                break
            }
        })
    }
    
}

