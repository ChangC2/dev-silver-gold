import Foundation
import UIKit


protocol ClickDelegate {
    func onClick(index: Int, type: Int)
}


protocol SelectDelegate{
    func onSelect(id: String, type: Int)
    func onSelect(index: Int)
}


protocol SearchSelectDelegate {
    func onSelect(type: Int, id: String, name: String)
}

protocol InputBoxDelegate {
    func onInput(text: String)
}

protocol RefreshRecordingDelegate {
    func refresh(index: Int, record: MRecording)
}

protocol RefreshVoiceDelegate {
    func refresh(index: Int, voice: MVoice)
}

protocol RefreshScriptDelegate {
    func refresh(index: Int, script: MScript)
}
