import Foundation
import CoreLocation

class GV: NSObject{
    public static var tabIndex = 0
    public static var fcmtoken = ""
    public static var darkMode = true
    
    public static var user = MAccount()
    
    public static var forwarding_number = ""
    public static var credits = 100.0
    public static var credits_to_send = 0.0
    
    public static var user_email = ""
    
    public static var isDeclined = false
}
