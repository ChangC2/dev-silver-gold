import Foundation
import UIKit

let userDefault: UserDefaults = UserDefaults.standard
let appDelegate = UIApplication.shared.delegate as! AppDelegate
let google_api_key = "AIzaSyDb3oLDTkoVpLzE4PxZ0PL1ENW8rVI7OU4"

class C: NSObject{
    
    //For Notification
    public static let GOT_NOTIFICATION = "got_notification"
    
    //For Notification
    
    
    // For Local data
    static let IS_LOGINED = "is_logined"
    static let NOT_FIRST = "not_first"
    
    static let TOKEN = "token"
    static let PASSWORD = "password"
    
    

    // For Local data
    
}


