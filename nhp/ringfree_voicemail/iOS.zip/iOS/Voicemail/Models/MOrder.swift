import Foundation

class MOrder: NSObject{

    var id = ""
    var type = 0
    var forwarding_number = ""
    var created_at = ""
    var send_time = ""
    var user_id = ""
    var user_name = ""
    var url = ""
    var order_no = ""
    var record_name = ""
    var content = ""
    var status = 0
    var user_email = ""
    var record_count = 0
    var success = 0
    var fail = 0
    var queue = 0
    
    
    override init() {
        
    }
    
    init(dict: NSDictionary) {
        id = dict.parseString(param: "id")
        type = dict.parseInt(param: "type")
        forwarding_number = dict.parseString(param: "forwarding_number")
        created_at = dict.parseString(param: "created_at")
        send_time = dict.parseString(param: "send_time")
        user_id = dict.parseString(param: "user_id")
        user_name = dict.parseString(param: "user_name")
        url = dict.parseString(param: "url")
        order_no = dict.parseString(param: "order_no")
        record_name = dict.parseString(param: "record_name") 
        content = dict.parseString(param: "content")
        user_email = dict.parseString(param: "user_email")
        status = dict.parseInt(param: "status")
        record_count = dict.parseInt(param: "record_count")
        success = dict.parseInt(param: "success")
        fail = dict.parseInt(param: "fail")
        queue = dict.parseInt(param: "queue")
    }
}
