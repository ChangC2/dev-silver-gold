import Foundation

class MLog: NSObject{
    var id = ""
    var url = ""
    var created_at = ""
    var user_id = ""
    var user_name = ""
    var receiver = ""
    var status = ""
    var order_id = ""
    var receiver_name = ""
    var reason = ""
    var record_name = ""
    var forwarding_number = ""
    var content = ""
    var type = 0
    
    override init() {
        
    }
    
    init(dict: NSDictionary) {
        id = dict.parseString(param: "id")
        url = dict.parseString(param: "url")
        created_at = dict.parseString(param: "created_at")
        user_id = dict.parseString(param: "user_id")
        user_name = dict.parseString(param: "user_name")
        receiver = dict.parseString(param: "receiver")
        status = dict.parseString(param: "status")
        order_id = dict.parseString(param: "order_id")
        receiver_name = dict.parseString(param: "receiver_name")
        reason = dict.parseString(param: "reason")
        record_name = dict.parseString(param: "record_name")
        forwarding_number = dict.parseString(param: "forwarding_number")
        content = dict.parseString(param: "content")
        type = dict.parseInt(param: "type")
    }
}
