import Foundation

class MRecording: NSObject{

    var id: String = ""
    var name = ""
    var url = ""
    var created_at = ""
    
    override init() {
       
    }
    
    init(dict: NSDictionary) {
        id = dict.parseString(param: "id")
        name = dict.parseString(param: "name")
        url = dict.parseString(param: "url")
        created_at = dict.parseString(param: "created_at")
    }
}
