import Foundation

class MScript: NSObject{

    var id: String = ""
    var name = ""
    var content = ""
    var salutation = ""
    var created_at = ""
    
    override init() {
       
    }
    
    init(dict: NSDictionary) {
        id = dict.parseString(param: "id")
        name = dict.parseString(param: "name")
        salutation = dict.parseString(param: "salutation")
        content = dict.parseString(param: "content")
        created_at = dict.parseString(param: "created_at")
    }
}
