import Foundation

class MContactGroup: NSObject{

    var id: String = ""
    var name = ""
    var user = ""
    var created_at = ""
    
    override init() {
        
    }
    
    init(dict: NSDictionary) {
        id = dict.parseString(param: "id")
        name = dict.parseString(param: "name")
        user = dict.parseString(param: "user")
        created_at = dict.parseString(param: "created_at")
    }
}
