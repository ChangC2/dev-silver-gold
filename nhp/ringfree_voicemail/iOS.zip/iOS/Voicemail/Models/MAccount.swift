import Foundation

class MAccount: NSObject{

    var id = ""
    var accountname = ""
    var password = ""
    var email = ""
    var mobile_number = ""
    var status = ""
    var credits = ""
    var ip_address = ""
    var test_count = ""
    var verification_code = ""
    var caller_id = ""
    var permission = ""
    
    override init() {
        
    }
    
    init(dict: NSDictionary) {
        id = dict.parseString(param: "id")
        accountname = dict.parseString(param: "accountname")
        password = dict.parseString(param: "password")
        email = dict.parseString(param: "email")
        mobile_number = dict.parseString(param: "mobile_number")
        status = dict.parseString(param: "status")
        credits = dict.parseString(param: "credits")
        ip_address = dict.parseString(param: "ip_address")
        test_count = dict.parseString(param: "test_count")
        verification_code = dict.parseString(param: "verification_code")
        caller_id = dict.parseString(param: "caller_id")
        permission = dict.parseString(param: "permission")
    }
}
