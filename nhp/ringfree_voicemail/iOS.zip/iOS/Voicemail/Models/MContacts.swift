import Foundation

class MContacts: NSObject{

    var id: String = ""
    var name = ""
    var phone = ""
    var user = ""
    var group = ""
    var group_name = ""
    var email = ""
    var isSelected = false
    
    override init() {
        
    }
    
    init(dict: NSDictionary) {
        id = dict.parseString(param: "id")
        name = dict.parseString(param: "name")
        phone = dict.parseString(param: "phone")
        user = dict.parseString(param: "user")
        group = dict.parseString(param: "group")
        group_name = dict.parseString(param: "group_name")
        email = dict.parseString(param: "email")
        isSelected = dict.parseBool(param: "isSelected")
    }
}
