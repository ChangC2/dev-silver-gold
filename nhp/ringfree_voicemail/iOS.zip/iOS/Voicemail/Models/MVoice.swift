import Foundation

class MVoice: NSObject{

    var id = ""
    var name = ""
    var url = ""
    var active = 0
    var created_at = ""
    
    override init() {
       
    }
    
    init(dict: NSDictionary) {
        id = dict.parseString(param: "id")
        name = dict.parseString(param: "name")
        url = dict.parseString(param: "url")
        active = dict.parseInt(param: "active")
        created_at = dict.parseString(param: "created_at")
    }
}
