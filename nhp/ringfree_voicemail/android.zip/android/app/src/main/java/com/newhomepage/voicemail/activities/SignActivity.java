package com.newhomepage.voicemail.activities;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Html;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.core.widget.NestedScrollView;

import com.github.gcacace.signaturepad.views.SignaturePad;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.GV;
import com.newhomepage.voicemail.R;

import java.io.ByteArrayOutputStream;

public class SignActivity extends BaseActivity {

    int step = -1;
    TextView txtStepTitle, txtStepContent;
    CheckBox chkAgree;
    NestedScrollView scrollView;
    Button btnNext, btnDecline;
    SignaturePad mSignaturePad;
    String[] titles = {"Part I", "Part II", "Part III"};
    String[] contents = {"<div>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >1. DEFINITIONS</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Account\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means your registered account with us, through which you obtain\n" +
            "          access to and use of our Services, and includes all information and\n" +
            "          data which you input into your account, including without limitation,\n" +
            "          the designation of authorized users, passwords, and financial and\n" +
            "          billing information.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Affiliate\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means: (<span class=\"SpellE\">i</span>) any person or entity\n" +
            "          that directly, or indirectly through one or more intermediaries,\n" +
            "          controls, or is controlled by, or is under common control with, the\n" +
            "          Company; and (ii) each officer, director, shareholder, agent,\n" +
            "          employee, supplier, or reseller of the Company. As used in this\n" +
            "          definition, \"control\" (including, with correlative meanings,\n" +
            "          \"controlled by\" and \"under common control with\") shall mean\n" +
            "          possession, directly or indirectly, of power to direct or cause the\n" +
            "          direction of management or policies.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Aggregated Statistics\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means data and information related to Your use of the Services\n" +
            "          that is used by Company in an aggregate and anonymized manner,\n" +
            "          including to compile statistical and performance information related\n" +
            "          to the provision and operation of the Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Agreement\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;and&nbsp;<b>\"Terms and Conditions\"</b>&nbsp;mean the terms and\n" +
            "          conditions recited herein, as amended from time to time by the\n" +
            "          Company, and all documents, rules and policies referenced herein.<o:p\n" +
            "          ></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Authorized User\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means Your employees, consultants, contractors, and agents\n" +
            "          (<span class=\"SpellE\">i</span>) who are authorized by You to access\n" +
            "          and use the Services under the rights granted to You pursuant to this\n" +
            "          Agreement and (ii) for whom access to the Services has been purchased\n" +
            "          hereunder.&nbsp;<b>\"Company\"</b>&nbsp;means Drop Inc and NewHomePage\n" +
            "          LLC. which is also sometimes referred to as, \"I\", \"we\", \"us\" or\n" +
            "          \"our\".<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Customer Data\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means, other than Aggregated Statistics, information, data, and\n" +
            "          other content, in any form or medium, that is submitted, posted, or\n" +
            "          otherwise transmitted by or on behalf of You or an Authorized User\n" +
            "          through the Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Provider IP\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means the Services, the Documentation, and any and all\n" +
            "          intellectual property provided to <span class=\"GramE\">You</span> or\n" +
            "          any Authorized User in connection with the foregoing. For the\n" +
            "          avoidance of doubt, Provider IP includes Aggregated Statistics and any\n" +
            "          information, data, or other content derived from Companys monitoring\n" +
            "          of <span class=\"GramE\">Your</span> access to or use of the Services,\n" +
            "          but does not include Customer Data.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Services\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means any of the services offered or provided, from time to\n" +
            "          time, by the Company through this website, including by way of example\n" +
            "          only, Voice Broadcasts,\n" +
            "          <span class=\"SpellE\"\n" +
            "            >DropVM<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages (<span class=\"SpellE\">Ringless</span> Voicemail Drop\n" +
            "          Services),\n" +
            "          <span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          ></span\n" +
            "        ><sup\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 6pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >&nbsp;</span\n" +
            "          ></sup\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >messages (Short &amp; Long Code Message Services), or other\n" +
            "          telemarketing services, including any such services that utilize an\n" +
            "          Automatic Telephone Dialing System (ATDS), Automatic\n" +
            "          Dialing-Announcing Device (ADAD), or live transfers.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Third-Party Service Provider\"&nbsp;</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >means any entity other than Company that may be involved in the\n" +
            "          performance of the Services, including by way of example cellular\n" +
            "          service providers and any other entities involved in the transmission,\n" +
            "          processing, and receipt of cellular telephone calls, voice mail\n" +
            "          messages, and text messages.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Transmission\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means (<span class=\"SpellE\">i</span>) the act or process of\n" +
            "          sending or transmitting audio, visual, text, or other forms of content\n" +
            "          and materials by means of electronic communication by means of our\n" +
            "          Services, or (ii) such content and material itself, as the context\n" +
            "          requires.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"You\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;and&nbsp;<b>\"your\"</b>&nbsp;means a user, client, subscriber,\n" +
            "          customer, end user, or reseller, who is granted access and use of the\n" +
            "          Service by the Company.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <br />\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >2. LEGAL CAPACITY.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b></b> <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >You represent and warrant that: (a) you have the legal right, capacity\n" +
            "      and authority to agree to these Terms and Conditions as an individual or\n" +
            "      on behalf of a corporation or other entity; (b) you have attained the age\n" +
            "      of majority in the jurisdiction in which you reside and that you are in\n" +
            "      any event at least 18 years of age; and (c) if you are utilizing the\n" +
            "      Services on behalf of a corporation or other entity, all references to you\n" +
            "      and your in these Terms and Conditions shall include such corporation or\n" +
            "      organization, jointly and severally with you personally.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >3. ACCESS ANDUSE OF YOURACCOUNT.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "    >\n" +
            "      <o:p></o:p>\n" +
            "    </span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Provision of Access. Subject to and conditioned on Your payment of\n" +
            "          Fees and compliance with this Agreement, Company hereby grants you a\n" +
            "          non-exclusive, non-transferable right to access and use the Services\n" +
            "          during the Term, solely for use by Authorized Users in accordance with\n" +
            "          this Agreement. Such use is limited to Your internal use.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Documentation License. Subject to this Agreement, Company hereby\n" +
            "          grants to You a non-exclusive, non-sublicensable, non-transferable\n" +
            "          license to use the Documentation during the Term solely for Your\n" +
            "          internal business purposes in connection with Your use of the\n" +
            "          Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Use Restrictions. You shall not use the Services for any purposes\n" +
            "          beyond the scope of the access granted in this Agreement. You shall\n" +
            "          not at any time, directly or indirectly, and shall not permit any\n" +
            "          Authorized Users to: (<span class=\"SpellE\">i</span>) copy, modify, or\n" +
            "          create derivative works of the Services or Documentation, in whole or\n" +
            "          in part; (ii) rent, lease, lend, sell, license, sublicense, assign,\n" +
            "          distribute, publish, transfer, or otherwise make available the\n" +
            "          Services or Documentation; (iii) reverse engineer, disassemble,\n" +
            "          decompile, decode, adapt, or otherwise attempt to derive or gain\n" +
            "          access to any software component of the Services, in whole or in part;\n" +
            "          (iv) remove any proprietary notices from the Services or\n" +
            "          Documentation; or (v) use the Services or Documentation in any manner\n" +
            "          or for any purpose that infringes, misappropriates, or otherwise\n" +
            "          violates any intellectual property right or other right of any person,\n" +
            "          or that violates any applicable law. For example, and without\n" +
            "          limitation, You will not and will not otherwise permit any Authorized\n" +
            "          User to engage in any of the following activity using your\n" +
            "          Account:<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <ol start=\"1\" type=\"I\">\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any criminal or illegal activity;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the spoofing or impersonation of another person, corporation,\n" +
            "            organization or entity and/or the misrepresentation of the true\n" +
            "            originator of any message, call, or transmission;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >engaging in spamming and/or nuisance activities that violate\n" +
            "            anti-spamming laws and regulations;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the international promotion of goods and services;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the promotion and/or transmission of any message or content related\n" +
            "            to an illegal or improper financial scheme, such as Ponzi or Pyramid\n" +
            "            scheme, or gambling;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the Transmission of any form of communication that is defamatory,\n" +
            "            hateful, discriminatory, unlawful, or an infringement of any persons\n" +
            "            or groups rights, or the Transmission of any incident, obscene,\n" +
            "            offensive, violent, threatening, pornographic, or sexually explicit\n" +
            "            content, images or materials;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >offering the sale or distribution of illegal and/or controlled\n" +
            "            substances, drugs, alcohol, animals or animal products, and/or other\n" +
            "            contraband materials;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >offering any emergency services or other public safety service\n" +
            "            through 911 or any other system;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >sending any messages to recipients who will incur charges;<o:p\n" +
            "            ></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the transmitting or sending of any malware, viruses, bots, spyware,\n" +
            "            Trojan horses, worms, or any other form of harmful, disruptive or\n" +
            "            surreptitious program<br />\n" +
            "            or code;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any activity that adversely effects the operation, stability or\n" +
            "            reliability, of our Services or any activity that may subject us to\n" +
            "            third party liability or a third party claim;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >transmitting and/or misappropriating any content or intellectual\n" +
            "            property for which you do not have the right or authorization to\n" +
            "            use, including but not limited to trademark and copyright\n" +
            "            infringement, including any of our intellectual property;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any activity that attempts to copy, reverse engineer or duplicate\n" +
            "            our website and/or Services or to bypass, circumvent, breach,\n" +
            "            disable, or impair any security feature of our Services;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any use of our Services which in any manner interferes with or\n" +
            "            infringes upon any copyright, patent, trademark, know-how or other\n" +
            "            intellectual right or intellectual property of any other person or\n" +
            "            entity; or<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >using our Services for any purpose not specifically authorized by\n" +
            "            us.<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "      </ol>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Reservation of Rights. Company reserves all rights not expressly\n" +
            "          granted to You in this Agreement. Except for the limited rights and\n" +
            "          licenses expressly granted under this Agreement, nothing in this\n" +
            "          document grants, by implication, waiver, estoppel, or otherwise, to\n" +
            "          You or any third party any intellectual property rights or other\n" +
            "          right, title, or interest in or to the Provider IP.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Suspension. Notwithstanding anything to the contrary in this\n" +
            "          Agreement, Provider may temporarily suspend Customer's and any\n" +
            "          Authorized User's access to any portion or all of the Services if:\n" +
            "          (<span class=\"SpellE\">i</span>) Provider reasonably determines that\n" +
            "          (A) there is a threat or attack on any of the Provider IP; (B)\n" +
            "          Customer's or any Authorized User's use of the Provider IP disrupts or\n" +
            "          poses a security risk to the Provider IP or to any other customer or\n" +
            "          vendor of Provider; (C) Customer, or any Authorized User, is using the\n" +
            "          Provider IP for fraudulent or illegal activities; (D) subject to\n" +
            "          applicable law, Customer has ceased to continue its business in the\n" +
            "          ordinary course, made an assignment for the benefit of creditors or\n" +
            "          similar disposition of its assets, or become the subject of any\n" +
            "          bankruptcy, reorganization, liquidation, dissolution, or similar\n" +
            "          proceeding; or (E) Provider's provision of the Services to Customer or\n" +
            "          any Authorized User is prohibited by applicable law; (ii) any vendor\n" +
            "          of Provider has suspended or terminated Provider's access to or use of\n" +
            "          any third-party services or products required to enable Customer to\n" +
            "          access the Services; or (iii) in accordance with Section 7(a)(iii)\n" +
            "          (any such suspension described in\n" +
            "          <span class=\"SpellE\">subclause</span> (<span class=\"SpellE\">i</span>),\n" +
            "          (ii), or (iii), a \"Service Suspension\"). Provider shall use\n" +
            "          commercially reasonable efforts to provide written notice of any\n" +
            "          Service Suspension to Customer and to provide updates regarding\n" +
            "          resumption of access to the Services following any Service Suspension.\n" +
            "          Provider shall use commercially reasonable efforts to resume providing\n" +
            "          access to the Services as soon as reasonably possible after the event\n" +
            "          giving rise to the Service Suspension is cured. Provider will have no\n" +
            "          liability for any damage, liabilities, losses (including any loss of\n" +
            "          data or profits), or any other consequences that Customer or any\n" +
            "          Authorized User may incur as a result of a Service Suspension.<o:p\n" +
            "          ></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Account Information Maintenance. You will immediately update your\n" +
            "          Account to reflect any changes to your contact information. You are\n" +
            "          solely responsible for your Account, its content, maintenance,\n" +
            "          confidentiality and security, including all passwords related to your\n" +
            "          Account and for any and all activities onyourAccount, with or without\n" +
            "          your permission. You will immediately notify us of anyunauthorized\n" +
            "          use, unlawful use, violation of this Agreement, and/or breach of\n" +
            "          security on your Account and, if we request, you will assist us with\n" +
            "          stopping and remedying anysuch breaches or violations.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Aggregated Statistics. Notwithstanding anything to the contrary in\n" +
            "          this Agreement, Company may monitor Your use of the Services and\n" +
            "          collect and compile Aggregated Statistics. As between Provider and\n" +
            "          Customer, all right, title, and interest in Aggregated Statistics, and\n" +
            "          all intellectual property rights therein, belong to and are retained\n" +
            "          solely by Company. You acknowledge that Company may compile Aggregated\n" +
            "          Statistics based on Customer Data input into the Services. Customer\n" +
            "          agrees that Provider may (<span class=\"SpellE\">i</span>) make\n" +
            "          Aggregated Statistics publicly available in compliance with applicable\n" +
            "          law, and (ii) use Aggregated Statistics to the extent and in the\n" +
            "          manner permitted under applicable law; provided that such Aggregated\n" +
            "          Statistics do not identify Customer or Customer's Confidential\n" +
            "          Information.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >4. Responsibilities Customer</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "      </span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;You are responsible and liable for all uses of the Services and\n" +
            "      Documentation resulting from access provided by You, directly or\n" +
            "      indirectly, whether such access or use is permitted by or in violation of\n" +
            "      this Agreement. Without limiting the generality of the foregoing,\n" +
            "      <span class=\"GramE\">You</span> are responsible for all acts and omissions\n" +
            "      of Authorized Users, and any act or omission by an Authorized User that\n" +
            "      would constitute a breach of this Agreement if taken by Customer will be\n" +
            "      deemed a breach of this Agreement by Customer. Customer shall use\n" +
            "      reasonable efforts to make all Authorized Users aware of this Agreement's\n" +
            "      provisions as applicable to such Authorized User's use of the Services and\n" +
            "      shall cause Authorized Users to comply with such provisions.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >5. Audit Rights and Remedies</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;We reserve the right to audit your Account, your policies,\n" +
            "      practices, and procedures in using our Services, and your use of our\n" +
            "      Services at any time and from time to time. Without prior notice and\n" +
            "      without limiting any of our other rights and remedies, we may suspend,\n" +
            "      freeze, seize, restrict, and/or terminate your Account at any time, in our\n" +
            "      sole discretion, if we determine or believe that you have violated any of\n" +
            "      these Terms and Conditions and/or any Federal, State, local or\n" +
            "      international law, code, regulation, or rule. You shall fully cooperate\n" +
            "      with our personnel conducting such audits and provide all access requested\n" +
            "      by us to all records, systems, equipment, information, and personnel,\n" +
            "      including machine IDs, serial numbers, and related information. Any\n" +
            "      failure on our part to take action in the event of a violation of any law,\n" +
            "      regulation, code, or rule shall not be construed as a waiver of any right\n" +
            "      that we have to enforce these Terms and Conditions.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >6. Disclosure Rights</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;We may disclose any and all information and data pertaining to your\n" +
            "      Account or your use of the Services to the extent such disclosure relates\n" +
            "      to our complying with any applicable law, regulation, subpoena, or court\n" +
            "      order.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >7. ACCESS ANDUSE OF YOURACCOUNT.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "    >\n" +
            "      <o:p></o:p>\n" +
            "    </span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Fees.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;You shall pay Customer the fees (<b>\"Fees\"</b>) as set forth on\n" +
            "          our website when <span class=\"GramE\">You</span> access the Services\n" +
            "          without offset or deduction. You shall make all payments hereunder in\n" +
            "          US dollars on or before the due date set forth on the website. If You\n" +
            "          fail to make any payment when due, without limiting Companys other\n" +
            "          rights and remedies: (<span class=\"SpellE\">i</span>) Company may\n" +
            "          charge interest on the past due amount at the rate of 1.5% per month\n" +
            "          calculated daily and compounded monthly or, if lower, the highest rate\n" +
            "          permitted under applicable law; (ii) You shall reimburse Company for\n" +
            "          all costs incurred by Company in collecting any late payments or\n" +
            "          interest, including attorneys' fees, court costs, and collection\n" +
            "          agency fees; and (iii) if such failure continues for 90 days or more,\n" +
            "          Company may suspend Your and Your Authorized Users' access to any\n" +
            "          portion or all of the Services until such amounts are paid in\n" +
            "          full.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Taxes.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;All Fees and other amounts payable by You under this Agreement\n" +
            "          are exclusive of taxes and similar assessments. You are responsible\n" +
            "          for all sales, use, and excise taxes, and any other similar taxes,\n" +
            "          duties, and charges of any kind imposed by any federal, state, or\n" +
            "          local governmental or regulatory authority on any amounts payable by\n" +
            "          Customer hereunder, other than any taxes imposed on Provider's\n" +
            "          income.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Financial Auditing Rights and Required Records.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;You agree to maintain complete and accurate records in\n" +
            "          accordance with generally accepted accounting principles during the\n" +
            "          Term and for a period of two years after the termination or expiration\n" +
            "          of this Agreement with respect to matters necessary for accurately\n" +
            "          determining amounts due hereunder. Company may, at its own expense, on\n" +
            "          reasonable prior notice, periodically inspect and audit Your records\n" +
            "          with respect to matters covered by this Agreement, provided that if\n" +
            "          such inspection and audit reveals that You have underpaid Company with\n" +
            "          respect to any amounts due and payable during the Term, You shall\n" +
            "          promptly pay the amounts necessary to rectify such underpayment,\n" +
            "          together with interest in accordance with&nbsp;<b>Section 7(a)</b>.\n" +
            "          You shall pay for the costs of the audit if the audit determines that\n" +
            "          Your underpayment equals or exceeds 10% for any quarter. Such\n" +
            "          inspection and auditing rights will extend throughout the Term of this\n" +
            "          Agreement and for a period of two years after the termination or\n" +
            "          expiration of this Agreement.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >8. Scrub and Other Obligations</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;At all times during the course of this Agreement, you shall\n" +
            "      implement all necessary policies and procedures to comply with the\n" +
            "      Telephone Consumer Protection Act (TCPA) safe harbor set forth at 47\n" +
            "      C.F.R. 64.1200(c)(2)(<span class=\"SpellE\">i</span>) and the safe harbor\n" +
            "      for reassigned numbers promulgated by the Federal Communications\n" +
            "      Commission that was adopted on December 12, 2018 in that certain Second\n" +
            "      Report and Order release on December 13, 2018, as either may be amended\n" +
            "      from time-to-time. You will timely scrub any numbers uploaded to our\n" +
            "      Services against all applicable federal and state do-not-call lists in\n" +
            "      furtherance of your full compliance at all times with all federal and\n" +
            "      state do-not-call laws and regulations. You are solely responsible and\n" +
            "      liable for any violations of federal and state do-not-call laws and\n" +
            "      regulations. Where required by applicable law or regulation, you will\n" +
            "      obtain the prior written consent from each recipient to contact such\n" +
            "      recipient.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >9. Special Considerations for Selected Services</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;As to the services identified below, and in addition to any and all\n" +
            "      other Terms and Conditions in this Agreement, you also agree to the\n" +
            "      following when using the following Services:<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span class=\"SpellE\"\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >VMDrop</span\n" +
            "          ><sup\n" +
            "            ><span\n" +
            "              style=\"\n" +
            "                font-size: 6pt;\n" +
            "                font-family: 'Open Sans', 'sans-serif';\n" +
            "                mso-fareast-font-family: 'Times New Roman';\n" +
            "                mso-font-kerning: 0pt;\n" +
            "              \"\n" +
            "              >TM</span\n" +
            "            ></sup\n" +
            "          ></span\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;<span class=\"SpellE\"\n" +
            "            >Messages.VMDrop<sup\n" +
            "              ><span style=\"font-size: 6pt\">TM</span></sup\n" +
            "            ></span\n" +
            "          >&nbsp;messages may in some circumstances make a partial ring or line\n" +
            "          \"tap\"or \"ping\" on a recipients phone.RVM maybe subject to regulatory\n" +
            "          content restrictions and state and/or federal laws. Before initiating\n" +
            "          any RVM campaign, it is your responsibility to obtain independent\n" +
            "          legal advice with respect to your specific use of RVM and to assure\n" +
            "          you compliance with all applicable local, state and federal laws and\n" +
            "          regulations, which may include, by way of example only: (a) having\n" +
            "          prior express written consent to contact all recipients; (b) scrubbing\n" +
            "          all contact lists against national and state do-not-call lists and\n" +
            "          your internal do-not-call lists; and (c) ensuring that all message\n" +
            "          content is compliant with applicable laws, including but not limited\n" +
            "          to clearly providing the true identity of the originator of the\n" +
            "          message at the beginning of all\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages, the return telephone number and address, and\n" +
            "          providing opt-out options in messages.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Missed Call Terms. As an option for the Services, we may provide to\n" +
            "          you and you may elect to utilize a service option through which a\n" +
            "          missed call can be triggered for recipients phones and an accompanying\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;message (peer-to-peer or otherwise) may be transmitted to the\n" +
            "          recipients (the \"Missed Call Service\"). To facilitate the Missed Call\n" +
            "          Service, we will provide You access to our Digital Identifiers to\n" +
            "          transmit the triggered missed call and accompanying\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup\n" +
            "            >message</span\n" +
            "          >. Utilization of the Missed Call Service generally results in a\n" +
            "          higher number of callbacks from recipients. As such, in utilizing the\n" +
            "          Missed Call Service, in addition to the obligations outlined in\n" +
            "          Paragraph 7.0, You agree to indemnify, hold harmless, and defend us\n" +
            "          and our officers, directors, employees, agents, affiliates,\n" +
            "          successors, and permitted assigns against any and all losses, damages,\n" +
            "          liabilities, deficiencies, claims, actions, judgments, settlements,\n" +
            "          interest, awards, penalties, fines, costs, or expenses of whatever\n" +
            "          kind, including attorneys fees, that are incurred by us (collectively,\n" +
            "          \"Losses\"), arising out of or related to any third-party claim alleging\n" +
            "          any failure by you to comply with any applicable federal, state or\n" +
            "          local laws, regulations, or codes relating to Your use of the Missed\n" +
            "          Call Service.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >SMS Terms (<span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages). As an option for the Services, we may provide to you\n" +
            "          and you may elect to utilize a service option through which we can\n" +
            "          trigger an SMS message with an accompanying voice message that may be\n" +
            "          transmitted to the recipients. To facilitate the\n" +
            "          <span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;message, we will provide You access to our Digital Identifiers\n" +
            "          to transmit the message (the \"SMS Drop Service\"). As such, in\n" +
            "          utilizing the SMS Drop Service, in addition to the obligations\n" +
            "          outlined in Paragraph 7.0, You agree to indemnify, hold harmless, and\n" +
            "          defend us and our officers, directors, employees, agents, affiliates,\n" +
            "          successors, and permitted assigns against any and all losses, damages,\n" +
            "          liabilities, deficiencies, claims, actions, judgments, settlements,\n" +
            "          interest, awards, penalties, fines, costs, or expenses of whatever\n" +
            "          kind, including attorneys fees, that are incurred by us (collectively,\n" +
            "          \"Losses\"), arising out of or related to any third-party claim alleging\n" +
            "          any failure by you to comply with any applicable federal, state or\n" +
            "          local laws, regulations, or codes relating to Your use of the SMS VM\n" +
            "          Service.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "  </ul>\n" +
            "</div>",
    "<div>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >1. DEFINITIONS</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Account\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means your registered account with us, through which you obtain\n" +
            "          access to and use of our Services, and includes all information and\n" +
            "          data which you input into your account, including without limitation,\n" +
            "          the designation of authorized users, passwords, and financial and\n" +
            "          billing information.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Affiliate\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means: (<span class=\"SpellE\">i</span>) any person or entity\n" +
            "          that directly, or indirectly through one or more intermediaries,\n" +
            "          controls, or is controlled by, or is under common control with, the\n" +
            "          Company; and (ii) each officer, director, shareholder, agent,\n" +
            "          employee, supplier, or reseller of the Company. As used in this\n" +
            "          definition, \"control\" (including, with correlative meanings,\n" +
            "          \"controlled by\" and \"under common control with\") shall mean\n" +
            "          possession, directly or indirectly, of power to direct or cause the\n" +
            "          direction of management or policies.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Aggregated Statistics\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means data and information related to Your use of the Services\n" +
            "          that is used by Company in an aggregate and anonymized manner,\n" +
            "          including to compile statistical and performance information related\n" +
            "          to the provision and operation of the Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Agreement\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;and&nbsp;<b>\"Terms and Conditions\"</b>&nbsp;mean the terms and\n" +
            "          conditions recited herein, as amended from time to time by the\n" +
            "          Company, and all documents, rules and policies referenced herein.<o:p\n" +
            "          ></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Authorized User\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means Your employees, consultants, contractors, and agents\n" +
            "          (<span class=\"SpellE\">i</span>) who are authorized by You to access\n" +
            "          and use the Services under the rights granted to You pursuant to this\n" +
            "          Agreement and (ii) for whom access to the Services has been purchased\n" +
            "          hereunder.&nbsp;<b>\"Company\"</b>&nbsp;means Drop Inc and NewHomePage\n" +
            "          LLC. which is also sometimes referred to as, \"I\", \"we\", \"us\" or\n" +
            "          \"our\".<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Customer Data\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means, other than Aggregated Statistics, information, data, and\n" +
            "          other content, in any form or medium, that is submitted, posted, or\n" +
            "          otherwise transmitted by or on behalf of You or an Authorized User\n" +
            "          through the Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Provider IP\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means the Services, the Documentation, and any and all\n" +
            "          intellectual property provided to <span class=\"GramE\">You</span> or\n" +
            "          any Authorized User in connection with the foregoing. For the\n" +
            "          avoidance of doubt, Provider IP includes Aggregated Statistics and any\n" +
            "          information, data, or other content derived from Companys monitoring\n" +
            "          of <span class=\"GramE\">Your</span> access to or use of the Services,\n" +
            "          but does not include Customer Data.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Services\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means any of the services offered or provided, from time to\n" +
            "          time, by the Company through this website, including by way of example\n" +
            "          only, Voice Broadcasts,\n" +
            "          <span class=\"SpellE\"\n" +
            "            >DropVM<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages (<span class=\"SpellE\">Ringless</span> Voicemail Drop\n" +
            "          Services),\n" +
            "          <span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          ></span\n" +
            "        ><sup\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 6pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >&nbsp;</span\n" +
            "          ></sup\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >messages (Short &amp; Long Code Message Services), or other\n" +
            "          telemarketing services, including any such services that utilize an\n" +
            "          Automatic Telephone Dialing System (ATDS), Automatic\n" +
            "          Dialing-Announcing Device (ADAD), or live transfers.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Third-Party Service Provider\"&nbsp;</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >means any entity other than Company that may be involved in the\n" +
            "          performance of the Services, including by way of example cellular\n" +
            "          service providers and any other entities involved in the transmission,\n" +
            "          processing, and receipt of cellular telephone calls, voice mail\n" +
            "          messages, and text messages.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Transmission\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means (<span class=\"SpellE\">i</span>) the act or process of\n" +
            "          sending or transmitting audio, visual, text, or other forms of content\n" +
            "          and materials by means of electronic communication by means of our\n" +
            "          Services, or (ii) such content and material itself, as the context\n" +
            "          requires.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"You\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;and&nbsp;<b>\"your\"</b>&nbsp;means a user, client, subscriber,\n" +
            "          customer, end user, or reseller, who is granted access and use of the\n" +
            "          Service by the Company.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <br />\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >2. LEGAL CAPACITY.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b></b> <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >You represent and warrant that: (a) you have the legal right, capacity\n" +
            "      and authority to agree to these Terms and Conditions as an individual or\n" +
            "      on behalf of a corporation or other entity; (b) you have attained the age\n" +
            "      of majority in the jurisdiction in which you reside and that you are in\n" +
            "      any event at least 18 years of age; and (c) if you are utilizing the\n" +
            "      Services on behalf of a corporation or other entity, all references to you\n" +
            "      and your in these Terms and Conditions shall include such corporation or\n" +
            "      organization, jointly and severally with you personally.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >3. ACCESS ANDUSE OF YOURACCOUNT.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "    >\n" +
            "      <o:p></o:p>\n" +
            "    </span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Provision of Access. Subject to and conditioned on Your payment of\n" +
            "          Fees and compliance with this Agreement, Company hereby grants you a\n" +
            "          non-exclusive, non-transferable right to access and use the Services\n" +
            "          during the Term, solely for use by Authorized Users in accordance with\n" +
            "          this Agreement. Such use is limited to Your internal use.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Documentation License. Subject to this Agreement, Company hereby\n" +
            "          grants to You a non-exclusive, non-sublicensable, non-transferable\n" +
            "          license to use the Documentation during the Term solely for Your\n" +
            "          internal business purposes in connection with Your use of the\n" +
            "          Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Use Restrictions. You shall not use the Services for any purposes\n" +
            "          beyond the scope of the access granted in this Agreement. You shall\n" +
            "          not at any time, directly or indirectly, and shall not permit any\n" +
            "          Authorized Users to: (<span class=\"SpellE\">i</span>) copy, modify, or\n" +
            "          create derivative works of the Services or Documentation, in whole or\n" +
            "          in part; (ii) rent, lease, lend, sell, license, sublicense, assign,\n" +
            "          distribute, publish, transfer, or otherwise make available the\n" +
            "          Services or Documentation; (iii) reverse engineer, disassemble,\n" +
            "          decompile, decode, adapt, or otherwise attempt to derive or gain\n" +
            "          access to any software component of the Services, in whole or in part;\n" +
            "          (iv) remove any proprietary notices from the Services or\n" +
            "          Documentation; or (v) use the Services or Documentation in any manner\n" +
            "          or for any purpose that infringes, misappropriates, or otherwise\n" +
            "          violates any intellectual property right or other right of any person,\n" +
            "          or that violates any applicable law. For example, and without\n" +
            "          limitation, You will not and will not otherwise permit any Authorized\n" +
            "          User to engage in any of the following activity using your\n" +
            "          Account:<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <ol start=\"1\" type=\"I\">\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any criminal or illegal activity;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the spoofing or impersonation of another person, corporation,\n" +
            "            organization or entity and/or the misrepresentation of the true\n" +
            "            originator of any message, call, or transmission;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >engaging in spamming and/or nuisance activities that violate\n" +
            "            anti-spamming laws and regulations;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the international promotion of goods and services;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the promotion and/or transmission of any message or content related\n" +
            "            to an illegal or improper financial scheme, such as Ponzi or Pyramid\n" +
            "            scheme, or gambling;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the Transmission of any form of communication that is defamatory,\n" +
            "            hateful, discriminatory, unlawful, or an infringement of any persons\n" +
            "            or groups rights, or the Transmission of any incident, obscene,\n" +
            "            offensive, violent, threatening, pornographic, or sexually explicit\n" +
            "            content, images or materials;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >offering the sale or distribution of illegal and/or controlled\n" +
            "            substances, drugs, alcohol, animals or animal products, and/or other\n" +
            "            contraband materials;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >offering any emergency services or other public safety service\n" +
            "            through 911 or any other system;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >sending any messages to recipients who will incur charges;<o:p\n" +
            "            ></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the transmitting or sending of any malware, viruses, bots, spyware,\n" +
            "            Trojan horses, worms, or any other form of harmful, disruptive or\n" +
            "            surreptitious program<br />\n" +
            "            or code;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any activity that adversely effects the operation, stability or\n" +
            "            reliability, of our Services or any activity that may subject us to\n" +
            "            third party liability or a third party claim;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >transmitting and/or misappropriating any content or intellectual\n" +
            "            property for which you do not have the right or authorization to\n" +
            "            use, including but not limited to trademark and copyright\n" +
            "            infringement, including any of our intellectual property;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any activity that attempts to copy, reverse engineer or duplicate\n" +
            "            our website and/or Services or to bypass, circumvent, breach,\n" +
            "            disable, or impair any security feature of our Services;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any use of our Services which in any manner interferes with or\n" +
            "            infringes upon any copyright, patent, trademark, know-how or other\n" +
            "            intellectual right or intellectual property of any other person or\n" +
            "            entity; or<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >using our Services for any purpose not specifically authorized by\n" +
            "            us.<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "      </ol>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Reservation of Rights. Company reserves all rights not expressly\n" +
            "          granted to You in this Agreement. Except for the limited rights and\n" +
            "          licenses expressly granted under this Agreement, nothing in this\n" +
            "          document grants, by implication, waiver, estoppel, or otherwise, to\n" +
            "          You or any third party any intellectual property rights or other\n" +
            "          right, title, or interest in or to the Provider IP.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Suspension. Notwithstanding anything to the contrary in this\n" +
            "          Agreement, Provider may temporarily suspend Customer's and any\n" +
            "          Authorized User's access to any portion or all of the Services if:\n" +
            "          (<span class=\"SpellE\">i</span>) Provider reasonably determines that\n" +
            "          (A) there is a threat or attack on any of the Provider IP; (B)\n" +
            "          Customer's or any Authorized User's use of the Provider IP disrupts or\n" +
            "          poses a security risk to the Provider IP or to any other customer or\n" +
            "          vendor of Provider; (C) Customer, or any Authorized User, is using the\n" +
            "          Provider IP for fraudulent or illegal activities; (D) subject to\n" +
            "          applicable law, Customer has ceased to continue its business in the\n" +
            "          ordinary course, made an assignment for the benefit of creditors or\n" +
            "          similar disposition of its assets, or become the subject of any\n" +
            "          bankruptcy, reorganization, liquidation, dissolution, or similar\n" +
            "          proceeding; or (E) Provider's provision of the Services to Customer or\n" +
            "          any Authorized User is prohibited by applicable law; (ii) any vendor\n" +
            "          of Provider has suspended or terminated Provider's access to or use of\n" +
            "          any third-party services or products required to enable Customer to\n" +
            "          access the Services; or (iii) in accordance with Section 7(a)(iii)\n" +
            "          (any such suspension described in\n" +
            "          <span class=\"SpellE\">subclause</span> (<span class=\"SpellE\">i</span>),\n" +
            "          (ii), or (iii), a \"Service Suspension\"). Provider shall use\n" +
            "          commercially reasonable efforts to provide written notice of any\n" +
            "          Service Suspension to Customer and to provide updates regarding\n" +
            "          resumption of access to the Services following any Service Suspension.\n" +
            "          Provider shall use commercially reasonable efforts to resume providing\n" +
            "          access to the Services as soon as reasonably possible after the event\n" +
            "          giving rise to the Service Suspension is cured. Provider will have no\n" +
            "          liability for any damage, liabilities, losses (including any loss of\n" +
            "          data or profits), or any other consequences that Customer or any\n" +
            "          Authorized User may incur as a result of a Service Suspension.<o:p\n" +
            "          ></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Account Information Maintenance. You will immediately update your\n" +
            "          Account to reflect any changes to your contact information. You are\n" +
            "          solely responsible for your Account, its content, maintenance,\n" +
            "          confidentiality and security, including all passwords related to your\n" +
            "          Account and for any and all activities onyourAccount, with or without\n" +
            "          your permission. You will immediately notify us of anyunauthorized\n" +
            "          use, unlawful use, violation of this Agreement, and/or breach of\n" +
            "          security on your Account and, if we request, you will assist us with\n" +
            "          stopping and remedying anysuch breaches or violations.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Aggregated Statistics. Notwithstanding anything to the contrary in\n" +
            "          this Agreement, Company may monitor Your use of the Services and\n" +
            "          collect and compile Aggregated Statistics. As between Provider and\n" +
            "          Customer, all right, title, and interest in Aggregated Statistics, and\n" +
            "          all intellectual property rights therein, belong to and are retained\n" +
            "          solely by Company. You acknowledge that Company may compile Aggregated\n" +
            "          Statistics based on Customer Data input into the Services. Customer\n" +
            "          agrees that Provider may (<span class=\"SpellE\">i</span>) make\n" +
            "          Aggregated Statistics publicly available in compliance with applicable\n" +
            "          law, and (ii) use Aggregated Statistics to the extent and in the\n" +
            "          manner permitted under applicable law; provided that such Aggregated\n" +
            "          Statistics do not identify Customer or Customer's Confidential\n" +
            "          Information.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >4. Responsibilities Customer</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "      </span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;You are responsible and liable for all uses of the Services and\n" +
            "      Documentation resulting from access provided by You, directly or\n" +
            "      indirectly, whether such access or use is permitted by or in violation of\n" +
            "      this Agreement. Without limiting the generality of the foregoing,\n" +
            "      <span class=\"GramE\">You</span> are responsible for all acts and omissions\n" +
            "      of Authorized Users, and any act or omission by an Authorized User that\n" +
            "      would constitute a breach of this Agreement if taken by Customer will be\n" +
            "      deemed a breach of this Agreement by Customer. Customer shall use\n" +
            "      reasonable efforts to make all Authorized Users aware of this Agreement's\n" +
            "      provisions as applicable to such Authorized User's use of the Services and\n" +
            "      shall cause Authorized Users to comply with such provisions.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >5. Audit Rights and Remedies</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;We reserve the right to audit your Account, your policies,\n" +
            "      practices, and procedures in using our Services, and your use of our\n" +
            "      Services at any time and from time to time. Without prior notice and\n" +
            "      without limiting any of our other rights and remedies, we may suspend,\n" +
            "      freeze, seize, restrict, and/or terminate your Account at any time, in our\n" +
            "      sole discretion, if we determine or believe that you have violated any of\n" +
            "      these Terms and Conditions and/or any Federal, State, local or\n" +
            "      international law, code, regulation, or rule. You shall fully cooperate\n" +
            "      with our personnel conducting such audits and provide all access requested\n" +
            "      by us to all records, systems, equipment, information, and personnel,\n" +
            "      including machine IDs, serial numbers, and related information. Any\n" +
            "      failure on our part to take action in the event of a violation of any law,\n" +
            "      regulation, code, or rule shall not be construed as a waiver of any right\n" +
            "      that we have to enforce these Terms and Conditions.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >6. Disclosure Rights</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;We may disclose any and all information and data pertaining to your\n" +
            "      Account or your use of the Services to the extent such disclosure relates\n" +
            "      to our complying with any applicable law, regulation, subpoena, or court\n" +
            "      order.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >7. ACCESS ANDUSE OF YOURACCOUNT.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "    >\n" +
            "      <o:p></o:p>\n" +
            "    </span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Fees.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;You shall pay Customer the fees (<b>\"Fees\"</b>) as set forth on\n" +
            "          our website when <span class=\"GramE\">You</span> access the Services\n" +
            "          without offset or deduction. You shall make all payments hereunder in\n" +
            "          US dollars on or before the due date set forth on the website. If You\n" +
            "          fail to make any payment when due, without limiting Companys other\n" +
            "          rights and remedies: (<span class=\"SpellE\">i</span>) Company may\n" +
            "          charge interest on the past due amount at the rate of 1.5% per month\n" +
            "          calculated daily and compounded monthly or, if lower, the highest rate\n" +
            "          permitted under applicable law; (ii) You shall reimburse Company for\n" +
            "          all costs incurred by Company in collecting any late payments or\n" +
            "          interest, including attorneys' fees, court costs, and collection\n" +
            "          agency fees; and (iii) if such failure continues for 90 days or more,\n" +
            "          Company may suspend Your and Your Authorized Users' access to any\n" +
            "          portion or all of the Services until such amounts are paid in\n" +
            "          full.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Taxes.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;All Fees and other amounts payable by You under this Agreement\n" +
            "          are exclusive of taxes and similar assessments. You are responsible\n" +
            "          for all sales, use, and excise taxes, and any other similar taxes,\n" +
            "          duties, and charges of any kind imposed by any federal, state, or\n" +
            "          local governmental or regulatory authority on any amounts payable by\n" +
            "          Customer hereunder, other than any taxes imposed on Provider's\n" +
            "          income.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Financial Auditing Rights and Required Records.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;You agree to maintain complete and accurate records in\n" +
            "          accordance with generally accepted accounting principles during the\n" +
            "          Term and for a period of two years after the termination or expiration\n" +
            "          of this Agreement with respect to matters necessary for accurately\n" +
            "          determining amounts due hereunder. Company may, at its own expense, on\n" +
            "          reasonable prior notice, periodically inspect and audit Your records\n" +
            "          with respect to matters covered by this Agreement, provided that if\n" +
            "          such inspection and audit reveals that You have underpaid Company with\n" +
            "          respect to any amounts due and payable during the Term, You shall\n" +
            "          promptly pay the amounts necessary to rectify such underpayment,\n" +
            "          together with interest in accordance with&nbsp;<b>Section 7(a)</b>.\n" +
            "          You shall pay for the costs of the audit if the audit determines that\n" +
            "          Your underpayment equals or exceeds 10% for any quarter. Such\n" +
            "          inspection and auditing rights will extend throughout the Term of this\n" +
            "          Agreement and for a period of two years after the termination or\n" +
            "          expiration of this Agreement.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >8. Scrub and Other Obligations</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;At all times during the course of this Agreement, you shall\n" +
            "      implement all necessary policies and procedures to comply with the\n" +
            "      Telephone Consumer Protection Act (TCPA) safe harbor set forth at 47\n" +
            "      C.F.R. 64.1200(c)(2)(<span class=\"SpellE\">i</span>) and the safe harbor\n" +
            "      for reassigned numbers promulgated by the Federal Communications\n" +
            "      Commission that was adopted on December 12, 2018 in that certain Second\n" +
            "      Report and Order release on December 13, 2018, as either may be amended\n" +
            "      from time-to-time. You will timely scrub any numbers uploaded to our\n" +
            "      Services against all applicable federal and state do-not-call lists in\n" +
            "      furtherance of your full compliance at all times with all federal and\n" +
            "      state do-not-call laws and regulations. You are solely responsible and\n" +
            "      liable for any violations of federal and state do-not-call laws and\n" +
            "      regulations. Where required by applicable law or regulation, you will\n" +
            "      obtain the prior written consent from each recipient to contact such\n" +
            "      recipient.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >9. Special Considerations for Selected Services</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;As to the services identified below, and in addition to any and all\n" +
            "      other Terms and Conditions in this Agreement, you also agree to the\n" +
            "      following when using the following Services:<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span class=\"SpellE\"\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >VMDrop</span\n" +
            "          ><sup\n" +
            "            ><span\n" +
            "              style=\"\n" +
            "                font-size: 6pt;\n" +
            "                font-family: 'Open Sans', 'sans-serif';\n" +
            "                mso-fareast-font-family: 'Times New Roman';\n" +
            "                mso-font-kerning: 0pt;\n" +
            "              \"\n" +
            "              >TM</span\n" +
            "            ></sup\n" +
            "          ></span\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;<span class=\"SpellE\"\n" +
            "            >Messages.VMDrop<sup\n" +
            "              ><span style=\"font-size: 6pt\">TM</span></sup\n" +
            "            ></span\n" +
            "          >&nbsp;messages may in some circumstances make a partial ring or line\n" +
            "          \"tap\"or \"ping\" on a recipients phone.RVM maybe subject to regulatory\n" +
            "          content restrictions and state and/or federal laws. Before initiating\n" +
            "          any RVM campaign, it is your responsibility to obtain independent\n" +
            "          legal advice with respect to your specific use of RVM and to assure\n" +
            "          you compliance with all applicable local, state and federal laws and\n" +
            "          regulations, which may include, by way of example only: (a) having\n" +
            "          prior express written consent to contact all recipients; (b) scrubbing\n" +
            "          all contact lists against national and state do-not-call lists and\n" +
            "          your internal do-not-call lists; and (c) ensuring that all message\n" +
            "          content is compliant with applicable laws, including but not limited\n" +
            "          to clearly providing the true identity of the originator of the\n" +
            "          message at the beginning of all\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages, the return telephone number and address, and\n" +
            "          providing opt-out options in messages.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Missed Call Terms. As an option for the Services, we may provide to\n" +
            "          you and you may elect to utilize a service option through which a\n" +
            "          missed call can be triggered for recipients phones and an accompanying\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;message (peer-to-peer or otherwise) may be transmitted to the\n" +
            "          recipients (the \"Missed Call Service\"). To facilitate the Missed Call\n" +
            "          Service, we will provide You access to our Digital Identifiers to\n" +
            "          transmit the triggered missed call and accompanying\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup\n" +
            "            >message</span\n" +
            "          >. Utilization of the Missed Call Service generally results in a\n" +
            "          higher number of callbacks from recipients. As such, in utilizing the\n" +
            "          Missed Call Service, in addition to the obligations outlined in\n" +
            "          Paragraph 7.0, You agree to indemnify, hold harmless, and defend us\n" +
            "          and our officers, directors, employees, agents, affiliates,\n" +
            "          successors, and permitted assigns against any and all losses, damages,\n" +
            "          liabilities, deficiencies, claims, actions, judgments, settlements,\n" +
            "          interest, awards, penalties, fines, costs, or expenses of whatever\n" +
            "          kind, including attorneys fees, that are incurred by us (collectively,\n" +
            "          \"Losses\"), arising out of or related to any third-party claim alleging\n" +
            "          any failure by you to comply with any applicable federal, state or\n" +
            "          local laws, regulations, or codes relating to Your use of the Missed\n" +
            "          Call Service.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >SMS Terms (<span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages). As an option for the Services, we may provide to you\n" +
            "          and you may elect to utilize a service option through which we can\n" +
            "          trigger an SMS message with an accompanying voice message that may be\n" +
            "          transmitted to the recipients. To facilitate the\n" +
            "          <span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;message, we will provide You access to our Digital Identifiers\n" +
            "          to transmit the message (the \"SMS Drop Service\"). As such, in\n" +
            "          utilizing the SMS Drop Service, in addition to the obligations\n" +
            "          outlined in Paragraph 7.0, You agree to indemnify, hold harmless, and\n" +
            "          defend us and our officers, directors, employees, agents, affiliates,\n" +
            "          successors, and permitted assigns against any and all losses, damages,\n" +
            "          liabilities, deficiencies, claims, actions, judgments, settlements,\n" +
            "          interest, awards, penalties, fines, costs, or expenses of whatever\n" +
            "          kind, including attorneys fees, that are incurred by us (collectively,\n" +
            "          \"Losses\"), arising out of or related to any third-party claim alleging\n" +
            "          any failure by you to comply with any applicable federal, state or\n" +
            "          local laws, regulations, or codes relating to Your use of the SMS VM\n" +
            "          Service.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "  </ul>\n" +
            "</div>",
    "<div>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >1. DEFINITIONS</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Account\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means your registered account with us, through which you obtain\n" +
            "          access to and use of our Services, and includes all information and\n" +
            "          data which you input into your account, including without limitation,\n" +
            "          the designation of authorized users, passwords, and financial and\n" +
            "          billing information.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Affiliate\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means: (<span class=\"SpellE\">i</span>) any person or entity\n" +
            "          that directly, or indirectly through one or more intermediaries,\n" +
            "          controls, or is controlled by, or is under common control with, the\n" +
            "          Company; and (ii) each officer, director, shareholder, agent,\n" +
            "          employee, supplier, or reseller of the Company. As used in this\n" +
            "          definition, \"control\" (including, with correlative meanings,\n" +
            "          \"controlled by\" and \"under common control with\") shall mean\n" +
            "          possession, directly or indirectly, of power to direct or cause the\n" +
            "          direction of management or policies.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Aggregated Statistics\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means data and information related to Your use of the Services\n" +
            "          that is used by Company in an aggregate and anonymized manner,\n" +
            "          including to compile statistical and performance information related\n" +
            "          to the provision and operation of the Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Agreement\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;and&nbsp;<b>\"Terms and Conditions\"</b>&nbsp;mean the terms and\n" +
            "          conditions recited herein, as amended from time to time by the\n" +
            "          Company, and all documents, rules and policies referenced herein.<o:p\n" +
            "          ></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Authorized User\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means Your employees, consultants, contractors, and agents\n" +
            "          (<span class=\"SpellE\">i</span>) who are authorized by You to access\n" +
            "          and use the Services under the rights granted to You pursuant to this\n" +
            "          Agreement and (ii) for whom access to the Services has been purchased\n" +
            "          hereunder.&nbsp;<b>\"Company\"</b>&nbsp;means Drop Inc and NewHomePage\n" +
            "          LLC. which is also sometimes referred to as, \"I\", \"we\", \"us\" or\n" +
            "          \"our\".<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Customer Data\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means, other than Aggregated Statistics, information, data, and\n" +
            "          other content, in any form or medium, that is submitted, posted, or\n" +
            "          otherwise transmitted by or on behalf of You or an Authorized User\n" +
            "          through the Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Provider IP\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means the Services, the Documentation, and any and all\n" +
            "          intellectual property provided to <span class=\"GramE\">You</span> or\n" +
            "          any Authorized User in connection with the foregoing. For the\n" +
            "          avoidance of doubt, Provider IP includes Aggregated Statistics and any\n" +
            "          information, data, or other content derived from Companys monitoring\n" +
            "          of <span class=\"GramE\">Your</span> access to or use of the Services,\n" +
            "          but does not include Customer Data.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Services\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means any of the services offered or provided, from time to\n" +
            "          time, by the Company through this website, including by way of example\n" +
            "          only, Voice Broadcasts,\n" +
            "          <span class=\"SpellE\"\n" +
            "            >DropVM<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages (<span class=\"SpellE\">Ringless</span> Voicemail Drop\n" +
            "          Services),\n" +
            "          <span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          ></span\n" +
            "        ><sup\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 6pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >&nbsp;</span\n" +
            "          ></sup\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >messages (Short &amp; Long Code Message Services), or other\n" +
            "          telemarketing services, including any such services that utilize an\n" +
            "          Automatic Telephone Dialing System (ATDS), Automatic\n" +
            "          Dialing-Announcing Device (ADAD), or live transfers.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Third-Party Service Provider\"&nbsp;</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >means any entity other than Company that may be involved in the\n" +
            "          performance of the Services, including by way of example cellular\n" +
            "          service providers and any other entities involved in the transmission,\n" +
            "          processing, and receipt of cellular telephone calls, voice mail\n" +
            "          messages, and text messages.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"Transmission\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;means (<span class=\"SpellE\">i</span>) the act or process of\n" +
            "          sending or transmitting audio, visual, text, or other forms of content\n" +
            "          and materials by means of electronic communication by means of our\n" +
            "          Services, or (ii) such content and material itself, as the context\n" +
            "          requires.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >\"You\"</span\n" +
            "          ></b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;and&nbsp;<b>\"your\"</b>&nbsp;means a user, client, subscriber,\n" +
            "          customer, end user, or reseller, who is granted access and use of the\n" +
            "          Service by the Company.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <br />\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >2. LEGAL CAPACITY.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <b></b> <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >You represent and warrant that: (a) you have the legal right, capacity\n" +
            "      and authority to agree to these Terms and Conditions as an individual or\n" +
            "      on behalf of a corporation or other entity; (b) you have attained the age\n" +
            "      of majority in the jurisdiction in which you reside and that you are in\n" +
            "      any event at least 18 years of age; and (c) if you are utilizing the\n" +
            "      Services on behalf of a corporation or other entity, all references to you\n" +
            "      and your in these Terms and Conditions shall include such corporation or\n" +
            "      organization, jointly and severally with you personally.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >3. ACCESS ANDUSE OF YOURACCOUNT.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "    >\n" +
            "      <o:p></o:p>\n" +
            "    </span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Provision of Access. Subject to and conditioned on Your payment of\n" +
            "          Fees and compliance with this Agreement, Company hereby grants you a\n" +
            "          non-exclusive, non-transferable right to access and use the Services\n" +
            "          during the Term, solely for use by Authorized Users in accordance with\n" +
            "          this Agreement. Such use is limited to Your internal use.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Documentation License. Subject to this Agreement, Company hereby\n" +
            "          grants to You a non-exclusive, non-sublicensable, non-transferable\n" +
            "          license to use the Documentation during the Term solely for Your\n" +
            "          internal business purposes in connection with Your use of the\n" +
            "          Services.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Use Restrictions. You shall not use the Services for any purposes\n" +
            "          beyond the scope of the access granted in this Agreement. You shall\n" +
            "          not at any time, directly or indirectly, and shall not permit any\n" +
            "          Authorized Users to: (<span class=\"SpellE\">i</span>) copy, modify, or\n" +
            "          create derivative works of the Services or Documentation, in whole or\n" +
            "          in part; (ii) rent, lease, lend, sell, license, sublicense, assign,\n" +
            "          distribute, publish, transfer, or otherwise make available the\n" +
            "          Services or Documentation; (iii) reverse engineer, disassemble,\n" +
            "          decompile, decode, adapt, or otherwise attempt to derive or gain\n" +
            "          access to any software component of the Services, in whole or in part;\n" +
            "          (iv) remove any proprietary notices from the Services or\n" +
            "          Documentation; or (v) use the Services or Documentation in any manner\n" +
            "          or for any purpose that infringes, misappropriates, or otherwise\n" +
            "          violates any intellectual property right or other right of any person,\n" +
            "          or that violates any applicable law. For example, and without\n" +
            "          limitation, You will not and will not otherwise permit any Authorized\n" +
            "          User to engage in any of the following activity using your\n" +
            "          Account:<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <ol start=\"1\" type=\"I\">\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any criminal or illegal activity;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the spoofing or impersonation of another person, corporation,\n" +
            "            organization or entity and/or the misrepresentation of the true\n" +
            "            originator of any message, call, or transmission;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >engaging in spamming and/or nuisance activities that violate\n" +
            "            anti-spamming laws and regulations;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the international promotion of goods and services;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the promotion and/or transmission of any message or content related\n" +
            "            to an illegal or improper financial scheme, such as Ponzi or Pyramid\n" +
            "            scheme, or gambling;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the Transmission of any form of communication that is defamatory,\n" +
            "            hateful, discriminatory, unlawful, or an infringement of any persons\n" +
            "            or groups rights, or the Transmission of any incident, obscene,\n" +
            "            offensive, violent, threatening, pornographic, or sexually explicit\n" +
            "            content, images or materials;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >offering the sale or distribution of illegal and/or controlled\n" +
            "            substances, drugs, alcohol, animals or animal products, and/or other\n" +
            "            contraband materials;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >offering any emergency services or other public safety service\n" +
            "            through 911 or any other system;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >sending any messages to recipients who will incur charges;<o:p\n" +
            "            ></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >the transmitting or sending of any malware, viruses, bots, spyware,\n" +
            "            Trojan horses, worms, or any other form of harmful, disruptive or\n" +
            "            surreptitious program<br />\n" +
            "            or code;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any activity that adversely effects the operation, stability or\n" +
            "            reliability, of our Services or any activity that may subject us to\n" +
            "            third party liability or a third party claim;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >transmitting and/or misappropriating any content or intellectual\n" +
            "            property for which you do not have the right or authorization to\n" +
            "            use, including but not limited to trademark and copyright\n" +
            "            infringement, including any of our intellectual property;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any activity that attempts to copy, reverse engineer or duplicate\n" +
            "            our website and/or Services or to bypass, circumvent, breach,\n" +
            "            disable, or impair any security feature of our Services;<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >any use of our Services which in any manner interferes with or\n" +
            "            infringes upon any copyright, patent, trademark, know-how or other\n" +
            "            intellectual right or intellectual property of any other person or\n" +
            "            entity; or<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "        <li\n" +
            "          class=\"MsoNormal\"\n" +
            "          style=\"\n" +
            "            color: #6a6c6f;\n" +
            "            mso-margin-top-alt: auto;\n" +
            "            mso-margin-bottom-alt: auto;\n" +
            "            line-height: 18pt;\n" +
            "            mso-list: l1 level3 lfo1;\n" +
            "            tab-stops: list 1.5in;\n" +
            "            background: white;\n" +
            "          \"\n" +
            "        >\n" +
            "          <span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >using our Services for any purpose not specifically authorized by\n" +
            "            us.<o:p></o:p\n" +
            "          ></span>\n" +
            "        </li>\n" +
            "      </ol>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Reservation of Rights. Company reserves all rights not expressly\n" +
            "          granted to You in this Agreement. Except for the limited rights and\n" +
            "          licenses expressly granted under this Agreement, nothing in this\n" +
            "          document grants, by implication, waiver, estoppel, or otherwise, to\n" +
            "          You or any third party any intellectual property rights or other\n" +
            "          right, title, or interest in or to the Provider IP.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Suspension. Notwithstanding anything to the contrary in this\n" +
            "          Agreement, Provider may temporarily suspend Customer's and any\n" +
            "          Authorized User's access to any portion or all of the Services if:\n" +
            "          (<span class=\"SpellE\">i</span>) Provider reasonably determines that\n" +
            "          (A) there is a threat or attack on any of the Provider IP; (B)\n" +
            "          Customer's or any Authorized User's use of the Provider IP disrupts or\n" +
            "          poses a security risk to the Provider IP or to any other customer or\n" +
            "          vendor of Provider; (C) Customer, or any Authorized User, is using the\n" +
            "          Provider IP for fraudulent or illegal activities; (D) subject to\n" +
            "          applicable law, Customer has ceased to continue its business in the\n" +
            "          ordinary course, made an assignment for the benefit of creditors or\n" +
            "          similar disposition of its assets, or become the subject of any\n" +
            "          bankruptcy, reorganization, liquidation, dissolution, or similar\n" +
            "          proceeding; or (E) Provider's provision of the Services to Customer or\n" +
            "          any Authorized User is prohibited by applicable law; (ii) any vendor\n" +
            "          of Provider has suspended or terminated Provider's access to or use of\n" +
            "          any third-party services or products required to enable Customer to\n" +
            "          access the Services; or (iii) in accordance with Section 7(a)(iii)\n" +
            "          (any such suspension described in\n" +
            "          <span class=\"SpellE\">subclause</span> (<span class=\"SpellE\">i</span>),\n" +
            "          (ii), or (iii), a \"Service Suspension\"). Provider shall use\n" +
            "          commercially reasonable efforts to provide written notice of any\n" +
            "          Service Suspension to Customer and to provide updates regarding\n" +
            "          resumption of access to the Services following any Service Suspension.\n" +
            "          Provider shall use commercially reasonable efforts to resume providing\n" +
            "          access to the Services as soon as reasonably possible after the event\n" +
            "          giving rise to the Service Suspension is cured. Provider will have no\n" +
            "          liability for any damage, liabilities, losses (including any loss of\n" +
            "          data or profits), or any other consequences that Customer or any\n" +
            "          Authorized User may incur as a result of a Service Suspension.<o:p\n" +
            "          ></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Account Information Maintenance. You will immediately update your\n" +
            "          Account to reflect any changes to your contact information. You are\n" +
            "          solely responsible for your Account, its content, maintenance,\n" +
            "          confidentiality and security, including all passwords related to your\n" +
            "          Account and for any and all activities onyourAccount, with or without\n" +
            "          your permission. You will immediately notify us of anyunauthorized\n" +
            "          use, unlawful use, violation of this Agreement, and/or breach of\n" +
            "          security on your Account and, if we request, you will assist us with\n" +
            "          stopping and remedying anysuch breaches or violations.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          margin-bottom: 7.5pt;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Aggregated Statistics. Notwithstanding anything to the contrary in\n" +
            "          this Agreement, Company may monitor Your use of the Services and\n" +
            "          collect and compile Aggregated Statistics. As between Provider and\n" +
            "          Customer, all right, title, and interest in Aggregated Statistics, and\n" +
            "          all intellectual property rights therein, belong to and are retained\n" +
            "          solely by Company. You acknowledge that Company may compile Aggregated\n" +
            "          Statistics based on Customer Data input into the Services. Customer\n" +
            "          agrees that Provider may (<span class=\"SpellE\">i</span>) make\n" +
            "          Aggregated Statistics publicly available in compliance with applicable\n" +
            "          law, and (ii) use Aggregated Statistics to the extent and in the\n" +
            "          manner permitted under applicable law; provided that such Aggregated\n" +
            "          Statistics do not identify Customer or Customer's Confidential\n" +
            "          Information.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >4. Responsibilities Customer</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "      </span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;You are responsible and liable for all uses of the Services and\n" +
            "      Documentation resulting from access provided by You, directly or\n" +
            "      indirectly, whether such access or use is permitted by or in violation of\n" +
            "      this Agreement. Without limiting the generality of the foregoing,\n" +
            "      <span class=\"GramE\">You</span> are responsible for all acts and omissions\n" +
            "      of Authorized Users, and any act or omission by an Authorized User that\n" +
            "      would constitute a breach of this Agreement if taken by Customer will be\n" +
            "      deemed a breach of this Agreement by Customer. Customer shall use\n" +
            "      reasonable efforts to make all Authorized Users aware of this Agreement's\n" +
            "      provisions as applicable to such Authorized User's use of the Services and\n" +
            "      shall cause Authorized Users to comply with such provisions.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >5. Audit Rights and Remedies</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;We reserve the right to audit your Account, your policies,\n" +
            "      practices, and procedures in using our Services, and your use of our\n" +
            "      Services at any time and from time to time. Without prior notice and\n" +
            "      without limiting any of our other rights and remedies, we may suspend,\n" +
            "      freeze, seize, restrict, and/or terminate your Account at any time, in our\n" +
            "      sole discretion, if we determine or believe that you have violated any of\n" +
            "      these Terms and Conditions and/or any Federal, State, local or\n" +
            "      international law, code, regulation, or rule. You shall fully cooperate\n" +
            "      with our personnel conducting such audits and provide all access requested\n" +
            "      by us to all records, systems, equipment, information, and personnel,\n" +
            "      including machine IDs, serial numbers, and related information. Any\n" +
            "      failure on our part to take action in the event of a violation of any law,\n" +
            "      regulation, code, or rule shall not be construed as a waiver of any right\n" +
            "      that we have to enforce these Terms and Conditions.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >6. Disclosure Rights</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;We may disclose any and all information and data pertaining to your\n" +
            "      Account or your use of the Services to the extent such disclosure relates\n" +
            "      to our complying with any applicable law, regulation, subpoena, or court\n" +
            "      order.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >7. ACCESS ANDUSE OF YOURACCOUNT.</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "    >\n" +
            "      <o:p></o:p>\n" +
            "    </span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Fees.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;You shall pay Customer the fees (<b>\"Fees\"</b>) as set forth on\n" +
            "          our website when <span class=\"GramE\">You</span> access the Services\n" +
            "          without offset or deduction. You shall make all payments hereunder in\n" +
            "          US dollars on or before the due date set forth on the website. If You\n" +
            "          fail to make any payment when due, without limiting Companys other\n" +
            "          rights and remedies: (<span class=\"SpellE\">i</span>) Company may\n" +
            "          charge interest on the past due amount at the rate of 1.5% per month\n" +
            "          calculated daily and compounded monthly or, if lower, the highest rate\n" +
            "          permitted under applicable law; (ii) You shall reimburse Company for\n" +
            "          all costs incurred by Company in collecting any late payments or\n" +
            "          interest, including attorneys' fees, court costs, and collection\n" +
            "          agency fees; and (iii) if such failure continues for 90 days or more,\n" +
            "          Company may suspend Your and Your Authorized Users' access to any\n" +
            "          portion or all of the Services until such amounts are paid in\n" +
            "          full.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Taxes.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;All Fees and other amounts payable by You under this Agreement\n" +
            "          are exclusive of taxes and similar assessments. You are responsible\n" +
            "          for all sales, use, and excise taxes, and any other similar taxes,\n" +
            "          duties, and charges of any kind imposed by any federal, state, or\n" +
            "          local governmental or regulatory authority on any amounts payable by\n" +
            "          Customer hereunder, other than any taxes imposed on Provider's\n" +
            "          income.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <u\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >Financial Auditing Rights and Required Records.</span\n" +
            "          ></u\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;You agree to maintain complete and accurate records in\n" +
            "          accordance with generally accepted accounting principles during the\n" +
            "          Term and for a period of two years after the termination or expiration\n" +
            "          of this Agreement with respect to matters necessary for accurately\n" +
            "          determining amounts due hereunder. Company may, at its own expense, on\n" +
            "          reasonable prior notice, periodically inspect and audit Your records\n" +
            "          with respect to matters covered by this Agreement, provided that if\n" +
            "          such inspection and audit reveals that You have underpaid Company with\n" +
            "          respect to any amounts due and payable during the Term, You shall\n" +
            "          promptly pay the amounts necessary to rectify such underpayment,\n" +
            "          together with interest in accordance with&nbsp;<b>Section 7(a)</b>.\n" +
            "          You shall pay for the costs of the audit if the audit determines that\n" +
            "          Your underpayment equals or exceeds 10% for any quarter. Such\n" +
            "          inspection and auditing rights will extend throughout the Term of this\n" +
            "          Agreement and for a period of two years after the termination or\n" +
            "          expiration of this Agreement.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >8. Scrub and Other Obligations</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;At all times during the course of this Agreement, you shall\n" +
            "      implement all necessary policies and procedures to comply with the\n" +
            "      Telephone Consumer Protection Act (TCPA) safe harbor set forth at 47\n" +
            "      C.F.R. 64.1200(c)(2)(<span class=\"SpellE\">i</span>) and the safe harbor\n" +
            "      for reassigned numbers promulgated by the Federal Communications\n" +
            "      Commission that was adopted on December 12, 2018 in that certain Second\n" +
            "      Report and Order release on December 13, 2018, as either may be amended\n" +
            "      from time-to-time. You will timely scrub any numbers uploaded to our\n" +
            "      Services against all applicable federal and state do-not-call lists in\n" +
            "      furtherance of your full compliance at all times with all federal and\n" +
            "      state do-not-call laws and regulations. You are solely responsible and\n" +
            "      liable for any violations of federal and state do-not-call laws and\n" +
            "      regulations. Where required by applicable law or regulation, you will\n" +
            "      obtain the prior written consent from each recipient to contact such\n" +
            "      recipient.<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <li\n" +
            "      class=\"MsoNormal\"\n" +
            "      style=\"\n" +
            "        color: #6a6c6f;\n" +
            "        mso-margin-top-alt: auto;\n" +
            "        mso-margin-bottom-alt: auto;\n" +
            "        line-height: 18pt;\n" +
            "        mso-list: l1 level1 lfo1;\n" +
            "        tab-stops: list 0.5in;\n" +
            "        background: white;\n" +
            "      \"\n" +
            "    >\n" +
            "      <b\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >9. Special Considerations for Selected Services</span\n" +
            "        ></b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      >\n" +
            "        <o:p></o:p>\n" +
            "      </span>\n" +
            "    </li>\n" +
            "  </ul>\n" +
            "  <p\n" +
            "    class=\"MsoNormal\"\n" +
            "    style=\"\n" +
            "      mso-margin-top-alt: auto;\n" +
            "      mso-margin-bottom-alt: auto;\n" +
            "      margin-left: 0.5in;\n" +
            "      line-height: 18pt;\n" +
            "      background: white;\n" +
            "    \"\n" +
            "  >\n" +
            "    <b\n" +
            "      ><span\n" +
            "        style=\"\n" +
            "          font-size: 10pt;\n" +
            "          font-family: 'Open Sans', 'sans-serif';\n" +
            "          mso-fareast-font-family: 'Times New Roman';\n" +
            "          color: #6a6c6f;\n" +
            "          mso-font-kerning: 0pt;\n" +
            "        \"\n" +
            "      ></span></b\n" +
            "    ><span\n" +
            "      style=\"\n" +
            "        font-size: 10pt;\n" +
            "        font-family: 'Open Sans', 'sans-serif';\n" +
            "        mso-fareast-font-family: 'Times New Roman';\n" +
            "        color: #6a6c6f;\n" +
            "        mso-font-kerning: 0pt;\n" +
            "      \"\n" +
            "      >&nbsp;As to the services identified below, and in addition to any and all\n" +
            "      other Terms and Conditions in this Agreement, you also agree to the\n" +
            "      following when using the following Services:<o:p></o:p\n" +
            "    ></span>\n" +
            "  </p>\n" +
            "  <ul type=\"disc\">\n" +
            "    <ol start=\"1\" type=\"a\">\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span class=\"SpellE\"\n" +
            "          ><span\n" +
            "            style=\"\n" +
            "              font-size: 10pt;\n" +
            "              font-family: 'Open Sans', 'sans-serif';\n" +
            "              mso-fareast-font-family: 'Times New Roman';\n" +
            "              mso-font-kerning: 0pt;\n" +
            "            \"\n" +
            "            >VMDrop</span\n" +
            "          ><sup\n" +
            "            ><span\n" +
            "              style=\"\n" +
            "                font-size: 6pt;\n" +
            "                font-family: 'Open Sans', 'sans-serif';\n" +
            "                mso-fareast-font-family: 'Times New Roman';\n" +
            "                mso-font-kerning: 0pt;\n" +
            "              \"\n" +
            "              >TM</span\n" +
            "            ></sup\n" +
            "          ></span\n" +
            "        ><span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >&nbsp;<span class=\"SpellE\"\n" +
            "            >Messages.VMDrop<sup\n" +
            "              ><span style=\"font-size: 6pt\">TM</span></sup\n" +
            "            ></span\n" +
            "          >&nbsp;messages may in some circumstances make a partial ring or line\n" +
            "          \"tap\"or \"ping\" on a recipients phone.RVM maybe subject to regulatory\n" +
            "          content restrictions and state and/or federal laws. Before initiating\n" +
            "          any RVM campaign, it is your responsibility to obtain independent\n" +
            "          legal advice with respect to your specific use of RVM and to assure\n" +
            "          you compliance with all applicable local, state and federal laws and\n" +
            "          regulations, which may include, by way of example only: (a) having\n" +
            "          prior express written consent to contact all recipients; (b) scrubbing\n" +
            "          all contact lists against national and state do-not-call lists and\n" +
            "          your internal do-not-call lists; and (c) ensuring that all message\n" +
            "          content is compliant with applicable laws, including but not limited\n" +
            "          to clearly providing the true identity of the originator of the\n" +
            "          message at the beginning of all\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages, the return telephone number and address, and\n" +
            "          providing opt-out options in messages.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >Missed Call Terms. As an option for the Services, we may provide to\n" +
            "          you and you may elect to utilize a service option through which a\n" +
            "          missed call can be triggered for recipients phones and an accompanying\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;message (peer-to-peer or otherwise) may be transmitted to the\n" +
            "          recipients (the \"Missed Call Service\"). To facilitate the Missed Call\n" +
            "          Service, we will provide You access to our Digital Identifiers to\n" +
            "          transmit the triggered missed call and accompanying\n" +
            "          <span class=\"SpellE\"\n" +
            "            >VMDrop<sup><span style=\"font-size: 6pt\">TM</span></sup\n" +
            "            >message</span\n" +
            "          >. Utilization of the Missed Call Service generally results in a\n" +
            "          higher number of callbacks from recipients. As such, in utilizing the\n" +
            "          Missed Call Service, in addition to the obligations outlined in\n" +
            "          Paragraph 7.0, You agree to indemnify, hold harmless, and defend us\n" +
            "          and our officers, directors, employees, agents, affiliates,\n" +
            "          successors, and permitted assigns against any and all losses, damages,\n" +
            "          liabilities, deficiencies, claims, actions, judgments, settlements,\n" +
            "          interest, awards, penalties, fines, costs, or expenses of whatever\n" +
            "          kind, including attorneys fees, that are incurred by us (collectively,\n" +
            "          \"Losses\"), arising out of or related to any third-party claim alleging\n" +
            "          any failure by you to comply with any applicable federal, state or\n" +
            "          local laws, regulations, or codes relating to Your use of the Missed\n" +
            "          Call Service.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "      <li\n" +
            "        class=\"MsoNormal\"\n" +
            "        style=\"\n" +
            "          color: #6a6c6f;\n" +
            "          mso-margin-top-alt: auto;\n" +
            "          mso-margin-bottom-alt: auto;\n" +
            "          line-height: 18pt;\n" +
            "          mso-list: l1 level2 lfo1;\n" +
            "          tab-stops: list 1in;\n" +
            "          background: white;\n" +
            "        \"\n" +
            "      >\n" +
            "        <span\n" +
            "          style=\"\n" +
            "            font-size: 10pt;\n" +
            "            font-family: 'Open Sans', 'sans-serif';\n" +
            "            mso-fareast-font-family: 'Times New Roman';\n" +
            "            mso-font-kerning: 0pt;\n" +
            "          \"\n" +
            "          >SMS Terms (<span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;messages). As an option for the Services, we may provide to you\n" +
            "          and you may elect to utilize a service option through which we can\n" +
            "          trigger an SMS message with an accompanying voice message that may be\n" +
            "          transmitted to the recipients. To facilitate the\n" +
            "          <span class=\"SpellE\"\n" +
            "            >TextDrop<sup><span style=\"font-size: 6pt\">TM</span></sup></span\n" +
            "          >&nbsp;message, we will provide You access to our Digital Identifiers\n" +
            "          to transmit the message (the \"SMS Drop Service\"). As such, in\n" +
            "          utilizing the SMS Drop Service, in addition to the obligations\n" +
            "          outlined in Paragraph 7.0, You agree to indemnify, hold harmless, and\n" +
            "          defend us and our officers, directors, employees, agents, affiliates,\n" +
            "          successors, and permitted assigns against any and all losses, damages,\n" +
            "          liabilities, deficiencies, claims, actions, judgments, settlements,\n" +
            "          interest, awards, penalties, fines, costs, or expenses of whatever\n" +
            "          kind, including attorneys fees, that are incurred by us (collectively,\n" +
            "          \"Losses\"), arising out of or related to any third-party claim alleging\n" +
            "          any failure by you to comply with any applicable federal, state or\n" +
            "          local laws, regulations, or codes relating to Your use of the SMS VM\n" +
            "          Service.<o:p></o:p\n" +
            "        ></span>\n" +
            "      </li>\n" +
            "    </ol>\n" +
            "  </ul>\n" +
            "</div>\n"};

    private boolean isSigned = false;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_sign);
        initUI();
        initButtonActions();
    }

    private void initUI() {
        txtStepTitle = findViewById(R.id.txtStepTitle);
        txtStepContent = findViewById(R.id.txtStepContent);
        chkAgree = findViewById(R.id.chkAgree);
        scrollView = findViewById(R.id.scrollView);
        mSignaturePad = (SignaturePad) findViewById(R.id.signature_pad);
        btnNext = findViewById(R.id.btnNext);
        btnDecline = findViewById(R.id.btnDecline);
        scrollView.setVisibility(View.VISIBLE);
        findViewById(R.id.lytStart).setVisibility(View.VISIBLE);
        findViewById(R.id.lytStep).setVisibility(View.GONE);
        findViewById(R.id.btnBack).setVisibility(View.GONE);
        findViewById(R.id.lytSign).setVisibility(View.GONE);
        btnNext.setText("Next");
        btnDecline.setVisibility(View.GONE);
    }



    private void initButtonActions(){
        findViewById(R.id.imgBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnNext).setOnClickListener(v -> nextStep());
        findViewById(R.id.btnBack).setOnClickListener(v -> prevStep());
        btnDecline.setOnClickListener(v->{
            GV.isDeclined = true;
            finish();
        });
        findViewById(R.id.txtClear).setOnClickListener(v->{mSignaturePad.clear();});
        mSignaturePad.setOnSignedListener(new SignaturePad.OnSignedListener() {

            @Override
            public void onStartSigning() {
                //Event triggered when the pad is touched
                isSigned = false;
            }

            @Override
            public void onSigned() {
                //Event triggered when the pad is signed
                isSigned = true;
            }

            @Override
            public void onClear() {
                //Event triggered when the pad is cleared
                isSigned = false;
            }
        });
    }

    private void nextStep(){
        if (step > -1 && step < 3 && !chkAgree.isChecked()){
            showToastMessage("Please click 'I Agree'");
            return;
        }
        if (step<2){
            step++;
            chkAgree.setChecked(false);
            scrollView.scrollTo(0,0);
            scrollView.setVisibility(View.VISIBLE);
            findViewById(R.id.lytStart).setVisibility(View.GONE);
            findViewById(R.id.lytStep).setVisibility(View.VISIBLE);
            findViewById(R.id.btnBack).setVisibility(step > 0 ? View.VISIBLE : View.GONE);
            findViewById(R.id.lytSign).setVisibility(View.GONE);
            btnNext.setText("Next");
            btnDecline.setVisibility(View.GONE);
            txtStepTitle.setText(Html.fromHtml(titles[step]));
            txtStepContent.setText(Html.fromHtml(contents[step]));
        }else if (step == 2){
            step++;
            scrollView.setVisibility(View.GONE);
            findViewById(R.id.lytStart).setVisibility(View.GONE);
            findViewById(R.id.lytStep).setVisibility(View.GONE);
            findViewById(R.id.lytSign).setVisibility(View.VISIBLE);
            btnNext.setText("Accept the Terms and Conditions");
            btnDecline.setVisibility(View.VISIBLE);
        }else{
            String acceptString = ((TextView)findViewById(R.id.txtAgree)).getText().toString();
            if (!isSigned || !acceptString.equalsIgnoreCase("I Accept")) {
                showToastMessage("Please type 'I Accept' and sign.");
                return;
            }
            Bitmap signatureBitmap = mSignaturePad.getSignatureBitmap();
            apiCallForSignature(signatureBitmap);

        }
    }

    private void prevStep(){
        if (step>0)
            step--;
        scrollView.scrollTo(0,0);
        scrollView.setVisibility(View.VISIBLE);
        findViewById(R.id.lytStart).setVisibility(View.GONE);
        findViewById(R.id.lytStep).setVisibility(View.VISIBLE);
        findViewById(R.id.btnBack).setVisibility(step > 0 ? View.VISIBLE : View.GONE);
        findViewById(R.id.lytSign).setVisibility(View.GONE);
        btnNext.setText("Next");
        btnDecline.setVisibility(View.GONE);
        txtStepTitle.setText(Html.fromHtml(titles[step]));
        txtStepContent.setText(Html.fromHtml(contents[step]));
    }

    void apiCallForSignature(Bitmap signatureBitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        signatureBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream .toByteArray();
        String imgString = Base64.encodeToString(byteArray, Base64.DEFAULT);
        showLoading();
        Ion.with(this)
                .load(C.signature)
                .setMultipartParameter("token", App.getToken())
                .setMultipartParameter("data", imgString)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        finish();
                    }
                });
    }

}