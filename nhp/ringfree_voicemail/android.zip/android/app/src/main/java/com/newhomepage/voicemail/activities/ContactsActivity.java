package com.newhomepage.voicemail.activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.BroadCastReceiverListener;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.GF;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.adapters.RContactAdapter;
import com.newhomepage.voicemail.fragment.ContactGroupFragment;
import com.newhomepage.voicemail.models.MContact;
import com.newhomepage.voicemail.models.MContactGroup;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ContactsActivity extends BaseActivity {

    RecyclerView recyclerView;
    RContactAdapter adapter;
    TextView txtGroup;
    ArrayList<MContactGroup> groups = new ArrayList<>();
    ArrayList<MContact> contacts = new ArrayList<>();
    ArrayList<MContact> filteredContacts = new ArrayList<>();
    String groupId = "";
    private ContactGroupFragment contactGroupFragment;
    private static final int REQUEST_CONTACTS_PERMISSION = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_contacts);
        initUI();
        initButtonActions();
        GF.registerBroadCast(this, new String[]{C.B_UPDATE_CONTACTS}, new BroadCastReceiverListener() {
            @Override
            public void onReceive(Context context, Intent intent) {
                apiCallForGetContacts(false);
            }
        });
        groupId = getIntent().getStringExtra("group");
        apiCallForGetContacts(true);
    }


    private void initUI() {
        txtGroup = findViewById(R.id.txtGroup);
        txtGroup.setText("All Contacts");
        recyclerView = findViewById(R.id.recyclerView);
    }

    private void initButtonActions() {
        findViewById(R.id.imgBack).setOnClickListener(v->finish());
        findViewById(R.id.imgAdd).setOnClickListener(v -> onContactDetails(-1));
        findViewById(R.id.lytGroup).setOnClickListener(v -> onGroup());
    }

    private void onGroup() {
        contactGroupFragment = new ContactGroupFragment(this, new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                if (index == 0) {
                    groupId = "";
                } else {
                    groupId = groups.get(index - 1).getId();
                }
                setRecycler();
            }
        });
        contactGroupFragment.setCancelable(true);
        MContactGroup g = new MContactGroup();
        g.setName("All Contacts");
        contactGroupFragment.groups.add(g);
        contactGroupFragment.groups.addAll(groups);
        contactGroupFragment.show(getSupportFragmentManager(), contactGroupFragment.getTag());
        contactGroupFragment.needAddButton = false;
        contactGroupFragment.itemTitle = "Group";
    }


    private void setRecycler() {
        filteredContacts.clear();
        if (TextUtils.isEmpty(groupId)) {
            txtGroup.setText("All Contacts");
            filteredContacts.addAll((contacts));
        } else {
            for (MContactGroup cg : groups) {
                if (cg.getId().equalsIgnoreCase(groupId)) {
                    txtGroup.setText(cg.getName());
                    break;
                }
            }
            for (MContact c : contacts) {
                if (c.getGroup().equalsIgnoreCase(groupId)) {
                    filteredContacts.add(c);
                }
            }
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        ClickListener listener = new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                if (type == 0){
                    onContactDetails(index);
                }else{
                    apiCallForDeleteContact(index);
                }
            }
        };
        adapter = new RContactAdapter(this, filteredContacts, listener);
        recyclerView.setAdapter(adapter);
    }

    private void onContactDetails(int index) {
        if (ContextCompat.checkSelfPermission(ContactsActivity.this,
                Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(ContactsActivity.this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    REQUEST_CONTACTS_PERMISSION);
        }else{
            Intent intent = new Intent(this, ContactDetailsActivity.class);
            if (index > -1 && index < filteredContacts.size()) {
                Gson gson = new Gson();
                String json = gson.toJson(filteredContacts.get(index));
                intent.putExtra("contact", json);
            }
            startActivity(intent);
        }
    }

    public void apiCallForGetContacts(boolean shouldShowLoading) {
        if (shouldShowLoading) showLoading();
        Ion.with(this)
                .load(C.getContacts)
                .setBodyParameter("token", App.getToken())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    contacts = gson.fromJson(jsonObject.getString("contacts"), new TypeToken<ArrayList<MContact>>() {
                                    }.getType());
                                    groups = gson.fromJson(jsonObject.getString("groups"), new TypeToken<ArrayList<MContactGroup>>() {
                                    }.getType());
                                    setRecycler();
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForDeleteContact(int index) {
        showLoading();
        Ion.with(this)
                .load(C.deleteContact)
                .setBodyParameter("id", filteredContacts.get(index).getId())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    for (int i=0;i<contacts.size();i++){
                                        if (contacts.get(i).getId().equalsIgnoreCase(filteredContacts.get(index).getId())){
                                            contacts.remove(i);
                                            break;
                                        }
                                    }
                                    filteredContacts.remove(index);
                                    adapter.setData(filteredContacts);
                                    GF.sendBroadCast(ContactsActivity.this, C.B_UPDATE_APPDATA);
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_CONTACTS_PERMISSION: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    try {
                    }catch (Exception e){
                        showAlert(e.getMessage());
                    }
                } else {
                    Toast.makeText(ContactsActivity.this, "Permission denied to read your Contacts", Toast.LENGTH_SHORT).show();
                }
            }
            default:
                break;
        }
    }
}