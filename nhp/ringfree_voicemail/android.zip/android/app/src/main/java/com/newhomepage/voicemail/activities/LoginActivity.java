package com.newhomepage.voicemail.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;

import com.google.gson.Gson;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.R;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends BaseActivity {

    EditText editEmail;
    EditText editPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_login);

        initUI();
        initButtonActions();

//        editEmail.setText("mzhou9954@gmail.com");
//        editPass.setText("123456");
    }

    private void initUI() {
        editEmail = findViewById(R.id.editEmail);
        editPass = findViewById(R.id.editPassword);
    }

    private void initButtonActions() {
        findViewById(R.id.btnLogin).setOnClickListener(view -> onLogin());
        findViewById(R.id.lytRegister).setOnClickListener(view -> moveRegister());
        findViewById(R.id.lytForgot).setOnClickListener(view -> moveForgotPass());
    }

    private void onLogin() {
        apiCallForLoginWithEmail();
    }

    private void moveMain() {
        showToastMessage(R.string.login_success);
        startActivity(new Intent(this, SendVoicemailsActivity.class));
        finish();
    }

    private void moveRegister() {
        startActivity(new Intent(this, RegisterActivity.class));
        finish();
    }

    private void moveForgotPass() {
        startActivity(new Intent(this, ForgotPassActivity.class));
        finish();
    }

    //***************************************//
    //             API Call Method           //
    //***************************************//

    void apiCallForLoginWithEmail() {
        if (TextUtils.isEmpty(editEmail.getText()) || TextUtils.isEmpty(editPass.getText())) {
            showToastMessage(R.string.missing_param);
            return;
        }
        showLoading();
        Ion.with(this)
                .load(C.login_account)
                .setBodyParameter("email", editEmail.getText().toString().trim())
                .setBodyParameter("password", editPass.getText().toString())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.login_fail, null, true);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    App.login(jsonObject.getString("token"));
                                    moveMain();
                                } else {
                                    showDlg(R.string.login_fail, null, true);
                                }
                            } catch (JSONException jsonException) {
                                showDlg(R.string.login_fail, null, true);
                            }
                        }
                    }
                });
    }

}