package com.newhomepage.voicemail.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;

import com.google.gson.Gson;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MAccount;

import org.json.JSONException;
import org.json.JSONObject;

public class AccountsActivity extends BaseActivity {

    EditText editAccountname, editEmail, editPhone, editPassword, editRePassword;
    MAccount account = new MAccount();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_accounts);
        initUI();
        apiCallForGetAccount();
    }

    private void initUI() {
        editAccountname = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        editPhone = findViewById(R.id.editPhone);
        editPassword = findViewById(R.id.editPassword);
        editRePassword = findViewById(R.id.editRePassword);
        findViewById(R.id.imgBack).setOnClickListener(v->finish());
        findViewById(R.id.btnSave).setOnClickListener(v->{
            apiCallForUpdateAccount();
        });
        findViewById(R.id.btnDelete).setOnClickListener(v->{
            ClickListener listener = new ClickListener() {
                @Override
                public void onClick(int index, int type) {
                    showDlg("Your deletion request is in process and you will get a confirmation email", null, false);
                }
            };
            showDlg("Are you sure you want to delete your account?",listener, true);
        });
    }

    private void setUI() {
        editAccountname.setText(account.getAccountname());
        editEmail.setText(account.getEmail());
        editPhone.setText(account.getMobile_number());
    }

    //***************************************//
    //             API Call Method           //
    //***************************************//

    void apiCallForGetAccount() {
        showLoading();
        Ion.with(this)
                .load(C.get_account)
                .setBodyParameter("token", App.getToken())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showDlg(R.string.connection_fail, null, false);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    account = gson.fromJson(jsonObject.getString("account"), MAccount.class);
                                    setUI();
                                }else{
                                    showDlg(R.string.connection_fail, null, false);
                                }
                            } catch (JSONException jsonException) {
                                showDlg(R.string.connection_fail, null, false);
                            }
                        }
                    }
                });
    }

    void apiCallForUpdateAccount() {
        if (TextUtils.isEmpty(editEmail.getText()) || TextUtils.isEmpty(editAccountname.getText()) || TextUtils.isEmpty(editPhone.getText())){
            showToastMessage(R.string.missing_param);
            return;
        }
        if (!TextUtils.isEmpty(editEmail.getText()) && !editPassword.getText().toString().equalsIgnoreCase(editRePassword.getText().toString())){
            showToastMessage(R.string.mismatch_pass);
            return;
        }
        showLoading();
        Ion.with(this)
                .load(C.update_account)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("email", editEmail.getText().toString().trim())
                .setBodyParameter("mobile_number", editPhone.getText().toString().trim())
                .setBodyParameter("password", editPassword.getText().toString().trim())
                .setBodyParameter("accountname", editAccountname.getText().toString().trim())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showToastMessage(R.string.update_fail);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    showToastMessage(R.string.update_success);
                                }else{
                                    showToastMessage(R.string.update_fail);
                                }
                            } catch (JSONException jsonException) {
                                showToastMessage(R.string.update_fail);
                            }
                        }
                    }
                });
    }
}