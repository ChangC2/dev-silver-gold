package com.newhomepage.voicemail.activities;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.koushikdutta.ion.ProgressCallback;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.GV;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MContact;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialog;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialogBuilder;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialogClickListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class ConfirmVoicemailActivity extends BaseActivity {

    private ImageButton pausebtn, playbtn;
    private MediaPlayer mPlayer;
    private TextView startTime, voiceTime, txtForwardingNumber, txtContacts, txtCosts, txtContent;
    private SeekBar voicePrgs;
    private Handler hdlr = new Handler();

    private int type = 0;
    private String audioName = "";
    private String audioUrl = "";
    private String previewUrl = "";
    private String voiceId = "";
    private String content = "";
    private boolean isScheduled = false;
    private String send_time = "";
    private String groupId = "";
    private boolean isBreakup = false;
    private String broadcasts_number = "";
    private String between_days = "";
    ArrayList<MContact> contacts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_confirm_voicemail);
        initUI();
        initButtonActions();
        type = getIntent().getIntExtra("type", 0);
        audioName = getIntent().getStringExtra("audio_name");
        audioUrl = getIntent().getStringExtra("audio_url");
        previewUrl = getIntent().getStringExtra("preview_url");
        voiceId = getIntent().getStringExtra("voice_id");
        content = getIntent().getStringExtra("content");
        groupId = getIntent().getStringExtra("group");
        Gson gson = new Gson();
        contacts = gson.fromJson(getIntent().getStringExtra("contacts"), new TypeToken<ArrayList<MContact>>() {
        }.getType());
        isScheduled = getIntent().getBooleanExtra("is_scheduled", false);
        send_time = getIntent().getStringExtra("send_time");
        isBreakup = getIntent().getBooleanExtra("break_up", false);
        broadcasts_number = getIntent().getStringExtra("broadcasts_number");
        between_days = getIntent().getStringExtra("between_days");
        loadAudio();

        findViewById(R.id.txtMessage).setVisibility(View.GONE);
        txtContent.setVisibility(View.GONE);

//        if (type == 0) {
//            findViewById(R.id.txtMessage).setVisibility(View.GONE);
//            txtContent.setVisibility(View.GONE);
//        }else{
//            findViewById(R.id.txtMessage).setVisibility(View.VISIBLE);
//            txtContent.setVisibility(View.VISIBLE);
//        }
        loadData();
    }

    @Override
    protected void onDestroy() {
        if (mPlayer != null){
            mPlayer.release();
            mPlayer = null;
        }
        hdlr.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void initUI() {
        txtContacts = findViewById(R.id.txtContacts);
        txtForwardingNumber = findViewById(R.id.txtForwardingNumber);
        txtCosts = findViewById(R.id.txtCosts);
        playbtn = (ImageButton) findViewById(R.id.btnPlay);
        pausebtn = (ImageButton) findViewById(R.id.btnPause);
        pausebtn.setEnabled(false);
        pausebtn.setVisibility(View.GONE);
        startTime = (TextView) findViewById(R.id.txtStartTime);
        voiceTime = (TextView) findViewById(R.id.txtSongTime);
        voicePrgs = (SeekBar) findViewById(R.id.sBar);
        voicePrgs.setClickable(false);
        pausebtn.setEnabled(false);
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        txtContent = findViewById(R.id.txtContent);
    }

    private void loadAudio() {
        showLoading();
        File audioFile = new File(getCacheDir(), "audio.wav");
        Ion.with(this)
                .load(previewUrl)
                .progress(new ProgressCallback() {
                    @Override
                    public void onProgress(long downloaded, long total) {
                        System.out.println("" + downloaded + " / " + total);
                    }
                })
                .write(audioFile)
                .setCallback(new FutureCallback<File>() {
                    @Override
                    public void onCompleted(Exception e, File file) {
                        hideLoading();
                        if (mPlayer == null)
                            return; // When user finish this activity before download complete.
                        if (file != null && file.exists()) {
                            try {
                                mPlayer.setDataSource(file.getPath());
                                mPlayer.prepare(); // might take long! (for buffering, etc)
                            } catch (IllegalArgumentException exception) {
                                Toast.makeText(ConfirmVoicemailActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            } catch (IllegalStateException exception) {
                                Toast.makeText(ConfirmVoicemailActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            } catch (IOException exception) {
                                Toast.makeText(ConfirmVoicemailActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(ConfirmVoicemailActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void loadData() {
        txtContacts.setText(String.format("# of Records : %d", contacts.size()));
        txtForwardingNumber.setText(String.format("Forwarding Number : %s", GV.forwarding_number));
        txtCosts.setText(String.format("*%.1f Credits Availalbe.You need %.1f credits to send this message.", GV.credits, contacts.size() * GV.credits_to_send));
        txtContent.setText(content);
    }

    private void initButtonActions() {
        findViewById(R.id.imgBack).setOnClickListener(v -> finish());
        mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mPlayer.seekTo(0);
                onPauseAudio();
            }
        });
        mPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                //onPlayAudio();
                voiceTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()),
                        TimeUnit.MILLISECONDS.toSeconds(mPlayer.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()))));
            }
        });
        playbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPlayAudio();
            }
        });
        pausebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPauseAudio();
            }
        });

        findViewById(R.id.btnSendNow).setEnabled(false);
        findViewById(R.id.btnSendNow).setAlpha(0.5f);
        CheckBox chkAccept = findViewById(R.id.chkAccept);
        chkAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chkAccept.isChecked()) {
                    findViewById(R.id.btnSendNow).setEnabled(true);
                    findViewById(R.id.btnSendNow).setAlpha(1.0f);
                } else {
                    findViewById(R.id.btnSendNow).setEnabled(false);
                    findViewById(R.id.btnSendNow).setAlpha(0.5f);
                }
            }
        });

        findViewById(R.id.txtViewContacts).setOnClickListener(v->{
            Intent intent = new Intent(ConfirmVoicemailActivity.this, ContactsActivity.class);
            intent.putExtra("group", groupId);
            startActivity(intent);
        });

        findViewById(R.id.btnSendNow).setOnClickListener(v -> {
            apiCallForCheckExistInOrder();
        });
    }

    private void onPlayAudio() {
        mPlayer.start();
        voiceTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()),
                TimeUnit.MILLISECONDS.toSeconds(mPlayer.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()))));
        startTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()),
                TimeUnit.MILLISECONDS.toSeconds(mPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()))));
        voicePrgs.setMax(mPlayer.getDuration());
        voicePrgs.setProgress(mPlayer.getCurrentPosition());
        hdlr.postDelayed(UpdateSongTime, 100);
        pausebtn.setEnabled(true);
        pausebtn.setVisibility(View.VISIBLE);
        playbtn.setEnabled(false);
        playbtn.setVisibility(View.GONE);
    }

    private void onPauseAudio() {
        mPlayer.pause();
        pausebtn.setEnabled(false);
        pausebtn.setVisibility(View.GONE);
        playbtn.setEnabled(true);
        playbtn.setVisibility(View.VISIBLE);
    }

    private Runnable UpdateSongTime = new Runnable() {
        @Override
        public void run() {
            if (mPlayer == null) return;
            startTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()),
                    TimeUnit.MILLISECONDS.toSeconds(mPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()))));
            int currentPosition = mPlayer.getCurrentPosition();
            voicePrgs.setProgress(currentPosition);
            hdlr.postDelayed(this, 200);
        }
    };

    public void apiCallForCheckExistInOrder() {
        showLoading();
        Ion.with(this)
                .load(C.checkExistInOrder)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("type", String.valueOf(type))
                .setBodyParameter("audioUrl", audioUrl)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    showDlg("You recently sent a message to this same group within last 24 hours. Please confirm you want to do this by clicking Yes or clicking Cancel.",
                                            new ClickListener() {
                                                @Override
                                                public void onClick(int index, int type) {
                                                    if (index == 0) {
                                                        apiCallForSaveMailLog();
                                                    } else {
                                                        finish();
                                                    }
                                                }
                                            }, true);
                                } else {
                                    apiCallForSaveMailLog();
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForSaveMailLog() {
        showLoading();
        Ion.with(this)
                .load(C.saveMailLog)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("type", String.valueOf(type))
                .setBodyParameter("forwarding_number", GV.forwarding_number)
                .setBodyParameter("selected_group", groupId)
                .setBodyParameter("record_name", audioName)
                .setBodyParameter("audioUrl", audioUrl)
                .setBodyParameter("content", type == 1 ? content : "")
                .setBodyParameter("voice_id", type == 1 ? voiceId : "")
                .setBodyParameter("send_time", isScheduled ? send_time : "")
                .setBodyParameter("break_up", isBreakup ? "true" : "false")
                .setBodyParameter("broadcasts_number", broadcasts_number)
                .setBodyParameter("between_days", between_days)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    iOSDialogBuilder builder = new iOSDialogBuilder(ConfirmVoicemailActivity.this)
                                            .setTitle(getString(R.string.app_name))
                                            .setSubtitle("Your Voice messages are now in Queue.  You can go to Past Sessions on Left menu to check Status.   You will get an email when they are all sent.")
                                            .setBoldPositiveLabel(true)
                                            .setCancelable(false)
                                            .setPositiveListener("Back to menu", new iOSDialogClickListener() {
                                                @Override
                                                public void onClick(iOSDialog dialog) {
                                                    dialog.dismiss();
                                                    Intent intent = new Intent(ConfirmVoicemailActivity.this, PastVoicemailsActivity.class);
                                                    intent.putExtra("type", isScheduled ? 1 : 0);
                                                    startActivity(intent);
                                                    finish();
                                                }
                                            });
                                    builder.setNegativeListener(getString(R.string.no), new iOSDialogClickListener() {
                                        @Override
                                        public void onClick(iOSDialog dialog) {
                                            dialog.dismiss();
                                        }
                                    });
                                    builder.build().show();
                                } else {
                                    showDlg(jsonObject.optString("message"), new ClickListener() {
                                        @Override
                                        public void onClick(int index, int type) {
                                            finish();
                                        }
                                    }, false);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }
}