package com.newhomepage.voicemail.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.DateUtil;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MContactGroup;

import java.util.ArrayList;


public class RContactGroupAdapter extends RecyclerView.Adapter<RContactGroupAdapter.ViewHolder> {

    Context mContext;
    private ArrayList<MContactGroup> groups;
    private ClickListener listener;
    private String itemTitle;
    private boolean needEdit = false;
    private boolean needDelete = false;

    public RContactGroupAdapter(Context context, ArrayList<MContactGroup> groups, ClickListener pListener, boolean needEdit, boolean needDelete) {
        this.groups = groups;
        this.needEdit = needEdit;
        this.needDelete = needDelete;
        listener = pListener;
        mContext = context;
    }

    // ******************************class ViewHoler redefinition ***************************//
    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtName, txtTime;
        ImageView imgEdit, imgDel;
        public ViewHolder(View itemView) {
            super(itemView);
        }

        public void setData(int position) {
            txtName = itemView.findViewById(R.id.txtName);
            txtName.setText(groups.get(position).getName());
            txtTime = itemView.findViewById(R.id.txtTime);
            txtTime.setText(DateUtil.toStringFormat_2(DateUtil.parseDataFromFormat12(groups.get(position).getCreated_at())));
            imgEdit = itemView.findViewById(R.id.imgEdit);
            imgEdit.setVisibility(needEdit ? View.VISIBLE : View.GONE);
            imgEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onClick(position, 1);
                }
            });
            imgDel = itemView.findViewById(R.id.imgDel);
            imgDel.setVisibility(needDelete ? View.VISIBLE : View.GONE);
            imgDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onClick(position, 2);
                }
            });
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 0);
                }
            });
        }
    }

    // ******************************class ViewHoler redefinition ***************************//
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.recycler_contact_group, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, final int position) {
        Vholder.setData(position);
    }

    @Override
    public int getItemCount() {
        return groups.size();
    }
}
