package com.newhomepage.voicemail.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.GF;
import com.newhomepage.voicemail.InputListener;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.adapters.RContactSelectorAdapter;
import com.newhomepage.voicemail.fragment.ContactGroupFragment;
import com.newhomepage.voicemail.models.MContactGroup;
import com.newhomepage.voicemail.models.MContact;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialog;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialogBuilder;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialogClickListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ContactDetailsActivity extends BaseActivity {

    Button btnManual, btnImport;
    TextView txtGroup;
    EditText editName, editPhone, editEmail, editSearch;
    RecyclerView recyclerView;
    RContactSelectorAdapter adapter;

    int groupIndex = -1;
    ArrayList<MContactGroup> groups = new ArrayList<>();
    private ContactGroupFragment contactGroupFragment;
    MContact contact = new MContact();
    ArrayList<MContact> contacts = new ArrayList<>();
    ArrayList<MContact> filteredContacts = new ArrayList<>();
    int type = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_contact_details);
        initUI();
        initButtonActions();
        apiCallForGetContactGroups();
    }

    private void initUI() {
        txtGroup = findViewById(R.id.txtGroup);
        editPhone = findViewById(R.id.editPhone);
        editEmail = findViewById(R.id.editEmail);
        editName = findViewById(R.id.editName);
        btnManual = findViewById(R.id.btnManual);
        btnImport = findViewById(R.id.btnImport);
        editSearch = findViewById(R.id.editSearch);
        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                onFilter(s.toString());
            }
        });
        recyclerView = findViewById(R.id.recyclerContacts);
        findViewById(R.id.lytTopButtons).setVisibility(getIntent().getStringExtra("contact") == null ? View.VISIBLE : View.GONE);
        onManual();
    }

    private void setUI() {
        if (getIntent().getStringExtra("contact") != null) {
            Gson gson = new Gson();
            contact = gson.fromJson(getIntent().getStringExtra("contact"), MContact.class);
            txtGroup.setText(contact.getGroup_name());
            for (int i = 0; i < groups.size(); i++) {
                if (groups.get(i).getId().equalsIgnoreCase(contact.getGroup())) {
                    groupIndex = i;
                    break;
                }
            }
            editName.setText(contact.getName());
            editEmail.setText(contact.getEmail());
            editPhone.setText(contact.getPhone());
        }
    }

    private void initButtonActions() {
        findViewById(R.id.imgBack).setOnClickListener(v -> finish());
        btnManual.setOnClickListener(v -> onManual());
        btnImport.setOnClickListener(v -> onImport());
        findViewById(R.id.lytGroup).setOnClickListener(v -> onGroup());
        findViewById(R.id.btnSave).setOnClickListener(v -> {
            if (type == 0) {
                if (TextUtils.isEmpty(contact.getId())) {
                    apiCallForAddContact();
                } else {
                    apiCallForUpdateContact();
                }
            } else {
                apiCallForAddContacts();
            }
        });
    }

    private void onManual() {
        type = 0;
        btnManual.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_blue));
        btnManual.setTextColor(ContextCompat.getColor(this, R.color.md_white_1000));
        btnImport.setBackground(ContextCompat.getDrawable(this, R.color.transparent));
        btnImport.setTextColor(ContextCompat.getColor(this, R.color.colorAccent));
        findViewById(R.id.lytManual).setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
        findViewById(R.id.lytSearch).setVisibility(View.GONE);
    }

    private void onImport() {
        if (contacts.size() == 0) {
            new LoadContactsTask(this).execute();
        }else{
            for (MContact c : contacts) {
                c.setSelected(false);
            }
            editSearch.setText("");
        }
        type = 1;
        btnImport.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_blue));
        btnImport.setTextColor(ContextCompat.getColor(this, R.color.md_white_1000));
        btnManual.setBackground(ContextCompat.getDrawable(this, R.color.transparent));
        btnManual.setTextColor(ContextCompat.getColor(this, R.color.colorAccent));
        findViewById(R.id.lytManual).setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
        findViewById(R.id.lytSearch).setVisibility(View.VISIBLE);
    }

    private void onGroup() {
        contactGroupFragment = new ContactGroupFragment(this, new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                if (index > -1 && index < groups.size()) {
                    if (type == 0) {
                        groupIndex = index;
                        txtGroup.setText(groups.get(index).getName());
                    } else if (type == 1) {
                        showAddGroupDlg("Edit Group", groups.get(index).getName(), new InputListener() {
                            @Override
                            public void onInput(String value) {
                                groups.get(index).setName(value);
                                apiCallForUpdateContactGroup(groups.get(index).getId(), value);
                            }
                        });
                    } else if (type == 2) {
                        apiCallForDeleteContactGroup(groups.get(index).getId());
                    }
                } else if (index == groups.size()) {
                    showAddGroupDlg("Add Group", "", new InputListener() {
                        @Override
                        public void onInput(String value) {
                            apiCallForAddContactGroup(value);
                        }
                    });
                }
            }
        });
        contactGroupFragment.setCancelable(true);
        contactGroupFragment.groups.clear();
        contactGroupFragment.groups.addAll(groups);
        contactGroupFragment.show(getSupportFragmentManager(), contactGroupFragment.getTag());
        contactGroupFragment.needAddButton = true;
        contactGroupFragment.itemTitle = "Group";
    }

    private void setRecycler() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        ClickListener listener = new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                filteredContacts.get(index).setSelected(!filteredContacts.get(index).isSelected());
                adapter.notifyDataSetChanged();
                for (int i=0;i<contacts.size();i++){
                    if (contacts.get(i).getId().equalsIgnoreCase(filteredContacts.get(index).getId())){
                        contacts.get(i).setSelected(filteredContacts.get(index).isSelected());
                    }
                }
            }
        };
        filteredContacts.clear();
        filteredContacts.addAll(contacts);
        adapter = new RContactSelectorAdapter(this, filteredContacts, listener);
        recyclerView.setAdapter(adapter);
    }

    private void onFilter(String query){
        if (contacts.size() == 0 || adapter == null) return;
        filteredContacts.clear();
        for (int i=0;i<contacts.size();i++){
            if (contacts.get(i).getName().contains(query) || contacts.get(i).getPhone().contains(query)){
                filteredContacts.add(contacts.get(i));
            }
        }
        adapter.setData(filteredContacts);
        adapter.notifyDataSetChanged();
    }

    public void apiCallForGetContactGroups() {
        showLoading();
        Ion.with(this)
                .load(C.getContactGroups)
                .setBodyParameter("token", App.getToken())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    groups.clear();
                                    groups = gson.fromJson(jsonObject.getString("groups"), new TypeToken<ArrayList<MContactGroup>>() {
                                    }.getType());
                                    setUI();
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForAddContactGroup(String name) {
        showLoading();
        Ion.with(this)
                .load(C.addContactGroup)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("name", name)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    groups = gson.fromJson(jsonObject.getString("groups"), new TypeToken<ArrayList<MContactGroup>>() {
                                    }.getType());
                                    showToastMessage("Added Successfully");
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForDeleteContactGroup(String id) {
        showLoading();
        Ion.with(this)
                .load(C.deleteContactGroup)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("id", id)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    groups = gson.fromJson(jsonObject.getString("groups"), new TypeToken<ArrayList<MContactGroup>>() {
                                    }.getType());
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForUpdateContactGroup(String id, String name) {
        showLoading();
        Ion.with(this)
                .load(C.updateContactGroup)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("id", id)
                .setBodyParameter("name", name)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    groups = gson.fromJson(jsonObject.getString("groups"), new TypeToken<ArrayList<MContactGroup>>() {
                                    }.getType());
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForAddContact() {
        if (groupIndex == -1) {
            showToastMessage("Please select group");
            return;
        }
        if (TextUtils.isEmpty(editPhone.getText().toString()) || TextUtils.isEmpty(editName.getText().toString())) {
            showToastMessage(R.string.missing_param);
            return;
        }
        showLoading();
        Ion.with(this)
                .load(C.addContact)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("name", editName.getText().toString())
                .setBodyParameter("group", groups.get(groupIndex).getId())
                .setBodyParameter("email", editEmail.getText().toString())
                .setBodyParameter("phone", editPhone.getText().toString())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(ContactDetailsActivity.this);
                                    builder.setTitle("Ringfree Voicemail");
                                    builder.setMessage("Added Successfully");
                                    // add the buttons
                                    builder.setPositiveButton("Add Another", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_CONTACTS);
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_APPDATA);
                                            contact = new MContact();
                                            editName.setText("");
                                            editPhone.setText("");
                                            editEmail.setText("");
                                        }
                                    });
                                    builder.setNeutralButton("Back to contacts", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_CONTACTS);
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_APPDATA);
                                            finish();
                                        }
                                    });
                                    builder.setNegativeButton("Go to Send a Message", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            Intent intent = new Intent(ContactDetailsActivity.this, SendVoicemailsActivity.class);
                                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            startActivity(intent);
                                        }
                                    });
                                    AlertDialog dialog = builder.create();
                                    dialog.show();
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForAddContacts() {
        if (groupIndex == -1) {
            showToastMessage("Please select group");
            return;
        }
        String names = "";
        String phones = "";
        String emails = "";
        for (int i = 0; i < contacts.size(); i++) {
            if (contacts.get(i).isSelected()) {
                String email = TextUtils.isEmpty(contacts.get(i).getEmail()) ? "-" : contacts.get(i).getEmail();
                phones += !TextUtils.isEmpty(phones) ? "," + contacts.get(i).getPhone() : contacts.get(i).getPhone();
                names += !TextUtils.isEmpty(names) ? "," + contacts.get(i).getName() : contacts.get(i).getName();
                emails += !TextUtils.isEmpty(emails) ? "," + email : email;
            }
        }

        if (TextUtils.isEmpty(phones)) {
            showToastMessage("Please select contacts");
            return;
        }

        showLoading();
        Ion.with(this)
                .load(C.addContacts)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("names", names)
                .setBodyParameter("group", groups.get(groupIndex).getId())
                .setBodyParameter("emails", emails)
                .setBodyParameter("phones", phones)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(ContactDetailsActivity.this);
                                    builder.setTitle("Ringfree Voicemail");
                                    builder.setMessage("Added Successfully");
                                    // add the buttons
                                    builder.setPositiveButton("Add Another", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            for (MContact c : contacts) {
                                                c.setSelected(false);
                                            }
                                            editSearch.setText("");
                                            setRecycler();
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_CONTACTS);
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_APPDATA);
                                        }
                                    });
                                    builder.setNeutralButton("Back to contacts", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_CONTACTS);
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_APPDATA);
                                            finish();
                                        }
                                    });
                                    builder.setNegativeButton("Go to Send a Message", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            Intent intent = new Intent(ContactDetailsActivity.this, SendVoicemailsActivity.class);
                                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            startActivity(intent);
                                        }
                                    });
                                    AlertDialog dialog = builder.create();
                                    dialog.show();
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForUpdateContact() {
        if (TextUtils.isEmpty(editPhone.getText().toString()) || TextUtils.isEmpty(editName.getText().toString())) {
            showToastMessage(R.string.missing_param);
            return;
        }
        showLoading();
        Ion.with(this)
                .load(C.updateContact)
                .setBodyParameter("id", contact.getId())
                .setBodyParameter("name", editName.getText().toString())
                .setBodyParameter("group", groups.get(groupIndex).getId())
                .setBodyParameter("email", editEmail.getText().toString())
                .setBodyParameter("phone", editPhone.getText().toString())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(ContactDetailsActivity.this);
                                    builder.setTitle("Ringfree Voicemail");
                                    builder.setMessage("Updated Successfully");
                                    // add the buttons
                                    builder.setPositiveButton("Add Another", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_CONTACTS);
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_APPDATA);
                                            contact = new MContact();
                                            editName.setText("");
                                            editPhone.setText("");
                                            editEmail.setText("");
                                        }
                                    });
                                    builder.setNeutralButton("Back to contacts", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_CONTACTS);
                                            GF.sendBroadCast(ContactDetailsActivity.this, C.B_UPDATE_APPDATA);
                                            finish();
                                        }
                                    });
                                    builder.setNegativeButton("Go to Send a Message", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            Intent intent = new Intent(ContactDetailsActivity.this, SendVoicemailsActivity.class);
                                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            startActivity(intent);
                                        }
                                    });
                                    AlertDialog dialog = builder.create();
                                    dialog.show();
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    @SuppressLint("Range")
    private void getContacts(String query) {
        contacts.clear();
        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);
        if ((cur != null ? cur.getCount() : 0) > 0) {
            while (cur.moveToNext()) {
                try {
                    String id = cur.getString(
                            cur.getColumnIndex(ContactsContract.Contacts._ID));
                    String name = cur.getString(cur.getColumnIndex(
                            ContactsContract.Contacts.DISPLAY_NAME));
                    String phoneNo = "";
                    String email = "";
                    if (cur.getInt(cur.getColumnIndex(
                            ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                        Cursor pCur = cr.query(
                                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                null,
                                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                                new String[]{id}, null);
                        if (pCur != null) {
                            pCur.moveToFirst();
                            phoneNo = pCur.getString(pCur.getColumnIndex(
                                    ContactsContract.CommonDataKinds.Phone.NUMBER));
                            pCur.close();
                        }
                    }

                    Cursor mEmailCursor = getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, null, ContactsContract.CommonDataKinds.Email.CONTACT_ID + "=?", new String[]{id}, null);
                    if (mEmailCursor != null && mEmailCursor.getCount() > 0) {
                        mEmailCursor.moveToFirst();
                        email = mEmailCursor.getString(mEmailCursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA)).trim();
                        mEmailCursor.close();
                    }

                    MContact c = new MContact();
                    c.setName(name);
                    c.setEmail(email);
                    phoneNo = phoneNo.replaceAll("[+ -()]", "");
                    if (phoneNo.length() > 10) {
                        phoneNo = phoneNo.substring(phoneNo.length() - 10);
                    }
                    c.setPhone(phoneNo);
                    if (!TextUtils.isEmpty(phoneNo)) {
                        if (phoneNo.contains(query.trim()) || name.toLowerCase().contains(query.trim().toLowerCase())) {
                            contacts.add(c);
                        }
                    }
                } catch (Exception e) {
                    Log.d("Import Contacts", e.toString());
                }
            }
        }
        if (cur != null) {
            cur.close();
        }
    }

    public class LoadContactsTask extends AsyncTask<Void, Void, String> {

        private Context context;
        private ProgressDialog progressDialog;

        public LoadContactsTask(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading contacts...");
            progressDialog.setIndeterminate(true);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            // Your logic to load contacts here
            getContacts("");
            return "";
        }

        @Override
        protected void onPostExecute(String type) {
            super.onPostExecute(type);
            progressDialog.dismiss();
            // Update your UI with the loaded contacts
            setRecycler();
        }
    }
}