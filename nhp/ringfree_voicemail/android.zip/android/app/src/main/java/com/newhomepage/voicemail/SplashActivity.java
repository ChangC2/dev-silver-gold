package com.newhomepage.voicemail;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewTreeObserver;
import android.widget.ImageView;

import com.newhomepage.voicemail.activities.LoginActivity;
import com.newhomepage.voicemail.activities.SendVoicemailsActivity;


public class SplashActivity extends Activity {

    private long showStartTime;
    private final static long DELAY_TIME = 1500;
    private boolean isRunning;

    ImageView ivLogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        ivLogo = (ImageView) findViewById(R.id.ivLogo);
        startAnimation();
        startSplash();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void startAnimation() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            ivLogo.getViewTreeObserver()
                    .addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override
                        public void onGlobalLayout() {
                            ivLogo.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                            AnimatorSet mAnimatorSet = new AnimatorSet();
                            mAnimatorSet.playTogether(ObjectAnimator.ofFloat(ivLogo, "alpha", 0, 1, 1, 1),
                                    ObjectAnimator.ofFloat(ivLogo, "scaleX", 0.3f, 1.05f, 0.9f, 1),
                                    ObjectAnimator.ofFloat(ivLogo, "scaleY", 0.3f, 1.05f, 0.9f, 1));
                            mAnimatorSet.setDuration(1500);
                            mAnimatorSet.start();
                        }
                    });
        }
    }

    private void startSplash() {

        showStartTime = System.currentTimeMillis();
        isRunning = true;

        Thread background = new Thread() {
            public void run() {
                try {
                    // Delay Time
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - showStartTime < DELAY_TIME) {
                        try {
                            // Delay for DELAY_TIME
                            Thread.sleep(showStartTime + DELAY_TIME
                                    - currentTime);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    return;
                } catch (Exception e) {
                    return;
                } finally {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            doFinish();
                        }
                    });
                }
            }
        };
        background.start();
    }

    private void doFinish() {
        if (this.isRunning) {
            if (App.isLoggedIn())
                gotoMainScreen();
            else
                gotoLoginScreen();
        }
    }

    // Go to Login Screen
    private void gotoLoginScreen() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override
    public void onBackPressed() {
        if (this.isRunning) {
            this.isRunning = false;
        }
        finish();
    }

    private void gotoMainScreen() {
        Intent intent = new Intent(this, SendVoicemailsActivity.class);
        startActivity(intent);
        finish();
    }
}