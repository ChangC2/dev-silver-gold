package com.newhomepage.voicemail.activities;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.koushikdutta.async.util.Charsets;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class FaqActivity extends BaseActivity {

    WebView webView;
    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_faq);
        initUI();
        initButtonActions();
    }

    private void initUI() {
        webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.setWebViewClient(new WebViewClient(){
            public void onPageFinished(WebView view, String url) {
                hideLoading();
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                showDlg(description, null, false);
            }
        });
        showLoading();
        url = "https://leadmarketer.com/el/webeditfiles/31997/Retail_Ringless_Voicemail_FAQ.html";
        webView.loadUrl(url);
    }

    private void initButtonActions() {
        findViewById(R.id.imgBack).setOnClickListener(v->finish());
    }
}