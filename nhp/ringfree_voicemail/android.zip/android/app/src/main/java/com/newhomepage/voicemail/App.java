package com.newhomepage.voicemail;


import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

import com.koushikdutta.ion.Ion;

public class App extends MultiDexApplication {
    public static Context context;
    public static SharedPreferences pref;
    public static SharedPreferences.Editor editor;

    @Override
    public void onCreate() {
        super.onCreate();
        MultiDex.install(this);
        context = getApplicationContext();
        pref = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public static boolean isLoggedIn(){
        return pref.getBoolean(C.IS_LOGINED, false);
    }

    public static void login(String token){
        editor.putString("token", token);
        editor.putBoolean(C.IS_LOGINED, true);
        editor.apply();
    }

    public static boolean readFaq(){
        return pref.getBoolean(C.READ_FAQ, false);
    }

    public static void setRaadFaq(){
        editor.putBoolean(C.READ_FAQ, true);
        editor.apply();
    }

    public static void setToken(String token){
        editor.putString("token", token);
        editor.apply();
    }

    public static String getToken(){
        return pref.getString("token", "");
    }

    public static void logout(){
        editor.putBoolean(C.IS_LOGINED, false);
        editor.apply();
    }

}
