package com.newhomepage.voicemail.adapters;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.DateUtil;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MRecording;

import java.util.ArrayList;


public class RRecordingAdapter extends RecyclerView.Adapter<RRecordingAdapter.ViewHolder> {

    Context mContext;
    private ArrayList<MRecording> recordings = new ArrayList<>();
    private ClickListener listener;


    public RRecordingAdapter(Context context, ArrayList<MRecording> recordings, ClickListener pListener) {
        listener = pListener;
        mContext = context;
        this.recordings.addAll(recordings);
        notifyDataSetChanged();
    }

    public void setData(ArrayList<MRecording> recordings) {
        this.recordings.clear();
        this.recordings.addAll(recordings);
        notifyDataSetChanged();
    }

    // ******************************class ViewHoler redefinition ***************************//
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtName, txtTime;
        ImageView imgPlay, imgEdit, imgDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            txtTime = itemView.findViewById(R.id.txtTime);
            imgPlay = itemView.findViewById(R.id.imgPlay);
            imgEdit = itemView.findViewById(R.id.imgEdit);
            imgDelete = itemView.findViewById(R.id.imgDelete);
        }

        public void setData(int position) {
            txtName.setText(recordings.get(position).getName());
            txtTime.setText(DateUtil.toStringFormat_2(DateUtil.parseDataFromFormat12(recordings.get(position).getCreated_at())));
            imgPlay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 0);
                }
            });
            imgEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 1);
                }
            });
            imgDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 2);
                }
            });
        }
    }


    // ******************************class ViewHoler redefinition ***************************//
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return  new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.recycler_recording, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, final int position) {
        Vholder.setData(position);
    }

    @Override
    public int getItemCount() {
        return recordings.size();
    }
}
