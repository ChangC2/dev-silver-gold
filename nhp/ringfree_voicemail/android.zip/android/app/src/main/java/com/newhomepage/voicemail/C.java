package com.newhomepage.voicemail;

public class C {

    //Google Login

    public static final String SERVER_URL = "https://ringlessvoicemail.leadmarketer.com/";
//    public static final String SERVER_URL = "http://192.168.0.53/ringfree_voicemail/";
    public static final String BASE_URL = SERVER_URL + "api/";

    public static String login_account = BASE_URL + "login_account";
    public static String register_account = BASE_URL + "register_account";
    public static String reset_password = BASE_URL + "reset_password";
    public static String get_account = BASE_URL + "get_account";
    public static String update_account = BASE_URL + "update_account";
    public static String verification_account = BASE_URL + "verification_account";
    public static String resend = BASE_URL + "resend";

    public static String getMainData = BASE_URL + "getMainData";
    public static String signature = BASE_URL + "signature";

    public static String getRecordings = BASE_URL + "getRecordings";
    public static String addRecording = BASE_URL + "addRecording";
    public static String updateRecording = BASE_URL + "updateRecording";
    public static String deleteRecording = BASE_URL + "deleteRecording";

    public static String getVoices = BASE_URL + "getVoices";
    public static String addVoice = BASE_URL + "addVoice";
    public static String updateVoice = BASE_URL + "updateVoice";
    public static String deleteVoice = BASE_URL + "deleteVoice";

    public static String getScripts = BASE_URL + "getScripts";
    public static String addScript = BASE_URL + "addScript";
    public static String updateScript = BASE_URL + "updateScript";
    public static String deleteScript = BASE_URL + "deleteScript";

    public static String getPendingOrders = BASE_URL + "getPendingOrders";
    public static String getScheduledOrders = BASE_URL + "getScheduledOrders";
    public static String getDeliveredOrders = BASE_URL + "getDeliveredOrders";
    public static String cancelOrder = BASE_URL + "cancelOrder";
    public static String getMailLogs = BASE_URL + "getMailLogs";

    public static String getContactGroups = BASE_URL + "getContactGroups";
    public static String addContactGroup = BASE_URL + "addContactGroup";
    public static String updateContactGroup = BASE_URL + "updateContactGroup";
    public static String deleteContactGroup = BASE_URL + "deleteContactGroup";
    public static String addContact = BASE_URL + "addContact";
    public static String addContacts = BASE_URL + "addContacts";
    public static String updateContact = BASE_URL + "updateContact";
    public static String deleteContact = BASE_URL + "deleteContact";
    public static String getContacts = BASE_URL + "getContacts";

    public static String saveMailLog = BASE_URL + "saveMailLog";
    public static String saveTestMailLog = BASE_URL + "saveTestMailLog";
    public static String checkExistInOrder = BASE_URL + "checkExistInOrder";

    public static String credits = SERVER_URL + "credits/manage";
    public static String tts_from_url = "https://aivalet.leadmarketer.com/tts_from_url.php";

    //share preference
    public static final String IS_LOGINED = "IS_LOGINED";
    public static final String READ_FAQ = "READ_FAQ";
    public static final String USER_TOEKN = "user_token";
    public static final String USER_ID = "user_id";
    public static final String NAME = "name";
    public static String ID = "ID";


    public static final int PERMISSION_REQUEST_CODE = 102;

    public static String B_UPDATE_CONTACTS = "B_UPDATE_CONTACTS";
    public static String B_UPDATE_APPDATA = "B_UPDATE_APPDATA";
    public static String B_UPDATE_CREDITS = "B_UPDATE_CREDITS";

    //Intent Extra

}
