package com.newhomepage.voicemail;

import android.content.Context;
import android.content.Intent;

public interface BroadCastReceiverListener {
    void onReceive(Context context, Intent intent);
}