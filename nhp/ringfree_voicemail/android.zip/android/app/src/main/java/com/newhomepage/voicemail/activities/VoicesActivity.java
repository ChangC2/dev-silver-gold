package com.newhomepage.voicemail.activities;

import android.Manifest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.koushikdutta.ion.ProgressCallback;
import com.koushikdutta.ion.builder.Builders;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.GF;
import com.newhomepage.voicemail.GV;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.adapters.RVoiceAdapter;
import com.newhomepage.voicemail.models.MRecording;
import com.newhomepage.voicemail.models.MVoice;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class VoicesActivity extends BaseActivity {

    RecyclerView recyclerView;
    RVoiceAdapter adapter;
    private ArrayList<MVoice> voices = new ArrayList<>();

    private ImageButton pauseBtn, playBtn;
    private Button btnRecord;
    private MediaPlayer mPlayer;
    private TextView startTime, voiceTime;
    private SeekBar voicePrgs;
    ProgressBar pBarLoading;
    private Handler hdlr = new Handler();

    EditText editName;
    private MediaRecorder recorder;
    File recordFile;
    boolean isRecording = false, isRecorded = false;
    int type = 0;

    private void startRecording(String fileName) {
        // initialize and configure MediaRecorder
        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFile(fileName);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        try {
            recorder.prepare();
        }
        catch (IOException e) {}
        catch (IllegalStateException e) {}
        recorder.start();
    }

    private void stopRecording() {
        // stop recording and free up resources
        recorder.stop();
        recorder.release();

        recorder = null;
        isRecorded = true;
        if (mPlayer != null){
            try {
                mPlayer.reset();
                mPlayer.setDataSource(recordFile.getAbsolutePath());
                mPlayer.prepare(); // might take long! (for buffering, etc)
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_voices);
        recordFile = new File(getCacheDir(), "record.wav");
        type = getIntent().getIntExtra("type", 0);
        initUI();
        initButtonActions();
        apiCallForGetVoice();
    }



    private void initUI() {
        TextView txtTitle = findViewById(R.id.txt_title);
        txtTitle.setText(type == 0 ? "Your Cloned Voices" : "Pro Voices");
        findViewById(R.id.imgAdd).setVisibility(type == 0 ? View.VISIBLE : View.GONE);
        recyclerView = findViewById(R.id.recyclerView);
    }

    private void setUI() {
        setRecycler();
        findViewById(R.id.txtEmpty).setVisibility(voices.size() > 0 ? View.GONE : View.VISIBLE);
        if (voices.size() == 0) onRecord(-1);
    }

    private void initButtonActions() {
        findViewById(R.id.imgBack).setOnClickListener(v -> finish());
        findViewById(R.id.imgAdd).setOnClickListener(v->onRecord(-1));
    }

    private void setRecycler() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        ClickListener listener = new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                switch (type) {
                    case 0:
                        onPlay(index);
                        break;
                    case 1:
                        onRecord(index);
                        break;
                    case 2:
                        apiCallForDeleteVoice(index);
                        break;
                    default:
                        break;
                }
            }
        };
        adapter = new RVoiceAdapter(this, voices, listener, type);
        recyclerView.setAdapter(adapter);
    }

    private void onPlay(int index) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_player, null);
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        dlg.setCanceledOnTouchOutside(false);
        TextView txtName = dialogView.findViewById(R.id.txtName);
        txtName.setText(voices.get(index).getName());
        dialogView.findViewById(R.id.btnClose).setOnClickListener(v -> {
            if (mPlayer != null){
                mPlayer.release();
                mPlayer = null;
            }
            hdlr.removeCallbacksAndMessages(null);
            dlg.dismiss();
        });

        playBtn = (ImageButton) dialogView.findViewById(R.id.btnPlay);
        pauseBtn = (ImageButton) dialogView.findViewById(R.id.btnPause);
        pauseBtn.setEnabled(false);
        pauseBtn.setVisibility(View.GONE);
        startTime = (TextView) dialogView.findViewById(R.id.txtStartTime);
        voiceTime = (TextView) dialogView.findViewById(R.id.txtSongTime);
        voicePrgs = (SeekBar) dialogView.findViewById(R.id.sBar);
        voicePrgs.setClickable(false);
        pauseBtn.setEnabled(false);
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

        pBarLoading = dialogView.findViewById(R.id.pBarLoading);
        pBarLoading.setVisibility(View.VISIBLE);

        File audioFile = new File(getCacheDir(), "audio.wav");
        Ion.with(this)
                .load(voices.get(index).getUrl())
                .progress(new ProgressCallback() {@Override
                public void onProgress(long downloaded, long total) {
                    System.out.println("" + downloaded + " / " + total);
                }
                })
                .write(audioFile)
                .setCallback(new FutureCallback<File>() {
                    @Override
                    public void onCompleted(Exception e, File file) {
                        pBarLoading.setVisibility(View.GONE);
                        if (mPlayer == null) return; // When user finish this activity before download complete.
                        if (file != null && file.exists()){
                            try {
                                mPlayer.setDataSource(file.getPath());
                                mPlayer.prepare(); // might take long! (for buffering, etc)
                            } catch (IllegalArgumentException exception) {
                                Toast.makeText(VoicesActivity.this, "Fail to load." , Toast.LENGTH_LONG).show();
                            } catch (IllegalStateException exception) {
                                Toast.makeText(VoicesActivity.this, "Fail to load." , Toast.LENGTH_LONG).show();
                            } catch (IOException exception) {
                                Toast.makeText(VoicesActivity.this, "Fail to load." , Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(VoicesActivity.this, "Fail to load." , Toast.LENGTH_LONG).show();
                        }
                    }
                });

        mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mPlayer.seekTo(0);
                onPauseAudio();
            }
        });
        mPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                onPlayAudio();
            }
        });
        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPlayAudio();
            }
        });
        pauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPauseAudio();
            }
        });
        dlg.setCanceledOnTouchOutside(false);
        dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dlg.show();
    }

    private void onRecord(int index) {
        isRecorded = false;
        isRecording = false;

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_voice_recorder, null);
        dialogView.findViewById(R.id.lytPlayer).setVisibility(View.GONE);

        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        dlg.setCanceledOnTouchOutside(false);
        editName = dialogView.findViewById(R.id.editName);
        btnRecord = dialogView.findViewById(R.id.btnRecord);

        pBarLoading = dialogView.findViewById(R.id.pBarLoading);
        pBarLoading.setVisibility(View.GONE);
        TextView txtName = dialogView.findViewById(R.id.txtName);
        if (index > -1){
            txtName.setText("Edit Voice");
            editName.setText(voices.get(index).getName());
            btnRecord.setVisibility(View.GONE);
        }else{
            txtName.setText("Add New Voice");
            btnRecord.setVisibility(View.VISIBLE);
        }
        playBtn = (ImageButton) dialogView.findViewById(R.id.btnPlay);
        playBtn.setEnabled(false);
        playBtn.setAlpha(0.5f);
        pauseBtn = (ImageButton) dialogView.findViewById(R.id.btnPause);
        pauseBtn.setEnabled(false);
        pauseBtn.setVisibility(View.GONE);
        btnRecord.setText("Tap to Record");
        btnRecord.setBackground(ContextCompat.getDrawable(VoicesActivity.this, R.drawable.round5_rect_blue));
        startTime = (TextView) dialogView.findViewById(R.id.txtStartTime);
        voiceTime = (TextView) dialogView.findViewById(R.id.txtSongTime);
        voicePrgs = (SeekBar) dialogView.findViewById(R.id.sBar);
        voicePrgs.setClickable(false);
        pauseBtn.setEnabled(false);
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mPlayer.seekTo(0);
                onPauseAudio();
            }
        });

        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPlayAudio();
            }
        });

        pauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPauseAudio();
            }
        });

        dialogView.findViewById(R.id.btnClose).setOnClickListener(v -> {
            if (mPlayer != null){
                mPlayer.release();
                mPlayer = null;
            }
            hdlr.removeCallbacksAndMessages(null);
            if (recorder != null){
                recorder.stop();
                recorder.release();
                recorder = null;
            }
            dlg.dismiss();
        });
        btnRecord.setOnClickListener(v -> {
            if (!checkPermissions(new String[]{Manifest.permission.RECORD_AUDIO},true, C.PERMISSION_REQUEST_CODE))
                return;
            if (isRecording){
                dialogView.findViewById(R.id.lytPlayer).setVisibility(View.VISIBLE);
                btnRecord.setBackground(ContextCompat.getDrawable(VoicesActivity.this, R.drawable.round5_rect_blue));
                btnRecord.setText("Tap to Record");
                stopRecording();
                playBtn.setAlpha(1.0f);
                playBtn.setEnabled(true);
                isRecording = false;
                onPlayAudio();
            }else{
                onPauseAudio();
                dialogView.findViewById(R.id.lytPlayer).setVisibility(View.GONE);
                btnRecord.setBackground(ContextCompat.getDrawable(VoicesActivity.this, R.drawable.round5_rect_red));
                btnRecord.setText("Tap to Stop");
                startRecording(recordFile.getAbsolutePath());
                isRecording = true;
            }
        });
        dialogView.findViewById(R.id.btnSave).setOnClickListener(v -> {
            String name = editName.getText().toString();
            if (TextUtils.isEmpty(name)){
                showToastMessage("Please input name.");
                return;
            }
            if (index == -1 && !isRecorded){
                showToastMessage("Please record voice.");
                return;
            }
            if (index == -1){
                apiCallForUploadVoice(name);
            }else{
                apiCallForUpdateVoice(index, name);
            }
            dlg.dismiss();
        });
        dlg.setCanceledOnTouchOutside(false);
        dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dlg.show();
    }

    private void onPlayAudio() {
        mPlayer.start();
        voiceTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()),
                TimeUnit.MILLISECONDS.toSeconds(mPlayer.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()))));
        startTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()),
                TimeUnit.MILLISECONDS.toSeconds(mPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()))));
        voicePrgs.setMax(mPlayer.getDuration());
        voicePrgs.setProgress(mPlayer.getCurrentPosition());
        hdlr.postDelayed(UpdateSongTime, 100);
        pauseBtn.setEnabled(true);
        pauseBtn.setVisibility(View.VISIBLE);
        playBtn.setEnabled(false);
        playBtn.setVisibility(View.GONE);
    }

    private void onPauseAudio() {
        mPlayer.pause();
        pauseBtn.setEnabled(false);
        pauseBtn.setVisibility(View.GONE);
        playBtn.setEnabled(true);
        playBtn.setVisibility(View.VISIBLE);
    }

    private Runnable UpdateSongTime = new Runnable() {
        @Override
        public void run() {
            if (mPlayer == null) return;
            startTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()),
                    TimeUnit.MILLISECONDS.toSeconds(mPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()))));
            int currentPosition = mPlayer.getCurrentPosition();
            voicePrgs.setProgress(currentPosition);
            hdlr.postDelayed(this, 200);
        }
    };

    public void apiCallForGetVoice() {
        showLoading();
        Ion.with(this)
                .load(C.getVoices)
                .setBodyParameter("token", App.getToken())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    voices = gson.fromJson(jsonObject.getString(type == 0 ? "user_voices" : "pro_voices"), new TypeToken<ArrayList<MVoice>>() {
                                    }.getType());
                                    setUI();
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    void apiCallForUploadVoice(String name) {
        showLoading();
        Ion.with(this)
                .load(C.addVoice)
                .setMultipartFile("file", "audio/wav", recordFile)
                .setMultipartParameter("token", App.getToken())
                .setMultipartParameter("name", name)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showToastMessage(R.string.connection_fail);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")){
                                    Gson gson = new Gson();
                                    MVoice newRecord = gson.fromJson(jsonObject.getString("voice"), MVoice.class);
                                    voices.add(0, newRecord);
                                    adapter.setData(voices);
                                    findViewById(R.id.txtEmpty).setVisibility(View.GONE);
                                    showToastMessage("Congrats ! You saved your voice");
                                    GF.sendBroadCast(VoicesActivity.this, C.B_UPDATE_APPDATA);
                                }
                            } catch (JSONException jsonException) {
                                showToastMessage(R.string.connection_fail);
                            }
                        }
                    }
                });
    }

    void apiCallForUpdateVoice(int index, String name) {
        showLoading();
        Builders.Any.B builder =  Ion.with(this)
                .load(C.updateVoice);
        builder.setMultipartParameter("id", voices.get(index).getId())
                .setMultipartParameter("name", name)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showToastMessage(R.string.connection_fail);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")){
                                    Gson gson = new Gson();
                                    MRecording newRecord = gson.fromJson(jsonObject.getString("voice"), MRecording.class);
                                    voices.get(index).setName(newRecord.getName());
                                    voices.get(index).setUrl(newRecord.getUrl());
                                    adapter.setData(voices);
                                    findViewById(R.id.txtEmpty).setVisibility(View.GONE);
                                    showToastMessage("Congrats ! You saved your voice");
                                    GF.sendBroadCast(VoicesActivity.this, C.B_UPDATE_APPDATA);
                                }
                            } catch (JSONException jsonException) {
                                hideLoading();
                                showToastMessage(R.string.connection_fail);
                            }
                        }
                    }
                });
    }

    public void apiCallForDeleteVoice(int index) {
        showLoading();
        Ion.with(this)
                .load(C.deleteVoice)
                .setBodyParameter("id", voices.get(index).getId())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    voices.remove(index);
                                    adapter.setData(voices);
                                    findViewById(R.id.txtEmpty).setVisibility(voices.size() > 0 ? View.GONE : View.VISIBLE);
                                    GF.sendBroadCast(VoicesActivity.this, C.B_UPDATE_APPDATA);
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }
}