/*
 * Copyright 2015 Rudson Lima
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.newhomepage.voicemail;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialog;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialogBuilder;
import com.newhomepage.voicemail.views.iOSDialog.iOSDialogClickListener;

public class BaseActivity extends AppCompatActivity{

    public Context mContext;
    protected ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setDarkFullScreen();
        mContext = this;
        progress = new ProgressDialog(mContext, R.style.DialogTheme);
        progress.setMessage(getString(R.string.loading));
        progress.setCancelable(false);
        progress.setCanceledOnTouchOutside(false);
        progress.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
            }
        });
    }

    public void setDarkFullScreen() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
//        getSupportActionBar().hide();
    }

    public void setLightFullScreen() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
//        getSupportActionBar().hide();
    }

    public void showLoading() {
        if (progress.isShowing())
            return;
        progress.show();
        progress.setContentView(R.layout.dialog_loading);
    }

    public void hideLoading() {
        if (progress.isShowing())
            progress.dismiss();
    }

    public void showAlert(int resId) {
        String alertMsg = getString(resId);
        showAlert(alertMsg, null);
    }

    public void showAlert(int resId, View.OnClickListener clickListener) {
        String alertMsg = getString(resId);
        showAlert(alertMsg, clickListener);
    }

    public void showDlg(String msg, ClickListener listener, boolean cancelable) {
        iOSDialogBuilder builder = new iOSDialogBuilder(this)
                .setTitle(getString(R.string.app_name))
                .setSubtitle(msg)
                .setBoldPositiveLabel(true)
                .setCancelable(false)
                .setPositiveListener(getString(R.string.yes), new iOSDialogClickListener() {
                    @Override
                    public void onClick(iOSDialog dialog) {
                        if (listener != null)
                            listener.onClick(0,0);
                        dialog.dismiss();
                    }
                });
        if (cancelable)
            builder.setNegativeListener(getString(R.string.no), new iOSDialogClickListener() {
                @Override
                public void onClick(iOSDialog dialog) {
                    dialog.dismiss();
                }
            });

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            builder.setFont(context.getResources().getFont(R.font.normal));
//        }
        builder.build().show();
    }

    public void showDlg(int resId, ClickListener listener, boolean cancelable) {
        iOSDialogBuilder builder = new iOSDialogBuilder(this)
                .setTitle(getString(R.string.app_name))
                .setSubtitle(getString(resId))
                .setBoldPositiveLabel(true)
                .setCancelable(false)
                .setPositiveListener(getString(R.string.yes), new iOSDialogClickListener() {
                    @Override
                    public void onClick(iOSDialog dialog) {
                        if (listener != null)
                            listener.onClick(0, 0);
                        dialog.dismiss();
                    }
                });
        if (cancelable)
            builder.setNegativeListener(getString(R.string.no), new iOSDialogClickListener() {
                @Override
                public void onClick(iOSDialog dialog) {
                    dialog.dismiss();
                }
            });

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            builder.setFont(context.getResources().getFont(R.font.normal));
//        }
        builder.build().show();
    }

    public void showAlert(String message) {
        showAlert(message, null);
    }

    public void showAlert(String message, final View.OnClickListener clickListener) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_error, null);

        final AlertDialog errorDlg = new AlertDialog.Builder(mContext)
                .setView(dialogView)
                .setCancelable(false)
                .create();

        TextView tvAlert = (TextView) dialogView.findViewById(R.id.tvAlert);
        tvAlert.setText(message);
        dialogView.findViewById(R.id.btnCloseAlert).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                errorDlg.dismiss();
                if (clickListener != null) {
                    clickListener.onClick(v);
                }
            }
        });
        errorDlg.show();
        errorDlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
    }

    // Remove EditText Keyboard
    public void hideKeyboard(EditText et) {
        if (et != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(et.getWindowToken(), 0);
        }
    }

    public void msg(int resId) {
        String msg = getString(resId);
        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
        alert.setMessage(msg);
        alert.setPositiveButton(getString(R.string.ok),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alert.show();
    }

    public void msg(String msg) {
        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
        alert.setMessage(msg);
        alert.setPositiveButton(getString(R.string.ok),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        AlertDialog alertDialog = alert.show();
    }


    public void showSnackMessage(String msg) {
        if (TextUtils.isEmpty(msg))
            return;
        ViewGroup viewGroup = (ViewGroup) ((ViewGroup) this
                .findViewById(android.R.id.content)).getChildAt(0);

        Snackbar.make(viewGroup, msg, Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    public void showSnackMessage(int resId) {
        ViewGroup viewGroup = (ViewGroup) ((ViewGroup) this
                .findViewById(android.R.id.content)).getChildAt(0);
        Snackbar.make(viewGroup, resId, Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    public void showToastMessage(String msg) {
        if (TextUtils.isEmpty(msg))
            return;
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    public void showToastMessage(int resId) {
        Toast.makeText(this, resId, Toast.LENGTH_SHORT).show();
    }

    public boolean checkPermissions(String[] permissions, boolean showHintMessage, int requestCode) {
        if (permissions == null || permissions.length == 0)
            return true;

        boolean allPermissionSetted = true;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(mContext, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionSetted = false;
                break;
            }
        }

        if (allPermissionSetted)
            return true;

        // Should we show an explanation?
        boolean shouldShowRequestPermissionRationale = false;
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale((AppCompatActivity) mContext, permission)) {
                shouldShowRequestPermissionRationale = true;
                break;
            }
        }

        if (showHintMessage && shouldShowRequestPermissionRationale) {
            showToastMessage(R.string.request_permission_hint);
        }
        ActivityCompat.requestPermissions((AppCompatActivity) mContext, permissions, requestCode);
        return false;
    }

    public void showAddGroupDlg(String title, String value, InputListener listener){
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_input, null);
        TextView txtTitle = dialogView.findViewById(R.id.txtTitle);
        txtTitle.setText(title);
        EditText editValue = dialogView.findViewById(R.id.editValue);
        editValue.setText(value);

        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();
        dialogView.findViewById(R.id.btnOk).setOnClickListener(v->{
            if (TextUtils.isEmpty(editValue.getText().toString())){
                return;
            }
            listener.onInput(editValue.getText().toString());
            dlg.dismiss();
        });
        dialogView.findViewById(R.id.btnCancel).setOnClickListener(v->{
            dlg.dismiss();
        });
        dlg.setCanceledOnTouchOutside(false);
        dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dlg.show();
    }
}
