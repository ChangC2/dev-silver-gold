package com.newhomepage.voicemail;

public interface InputListener {
    void onInput(String value);
}