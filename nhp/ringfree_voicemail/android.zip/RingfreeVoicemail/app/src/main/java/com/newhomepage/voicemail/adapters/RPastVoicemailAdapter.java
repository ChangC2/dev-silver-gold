package com.newhomepage.voicemail.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.DateUtil;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MOrder;

import java.util.ArrayList;


public class RPastVoicemailAdapter extends RecyclerView.Adapter<RPastVoicemailAdapter.ViewHolder> {

    Context mContext;
    private ArrayList<MOrder> orders = new ArrayList<>();
    private ClickListener listener;


    public RPastVoicemailAdapter(Context context, ArrayList<MOrder> orders, ClickListener pListener) {
        listener = pListener;
        mContext = context;
        this.orders.addAll(orders);
        notifyDataSetChanged();
    }

    public void setData(ArrayList<MOrder> orders) {
        this.orders.clear();
        this.orders.addAll(orders);
        notifyDataSetChanged();
    }

    // ******************************class ViewHoler redefinition ***************************//
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtOrderNo, txtDetails, txtTime, txtView10, txtViewContent, txtCancel, txtType;
        ImageView imgPlay;

        public ViewHolder(View itemView) {
            super(itemView);
            txtOrderNo = itemView.findViewById(R.id.txtOrderNo);
            txtDetails = itemView.findViewById(R.id.txtDetails);
            txtTime = itemView.findViewById(R.id.txtTime);
            txtView10 = itemView.findViewById(R.id.txtView10);
            txtViewContent = itemView.findViewById(R.id.txtViewContent);
            txtCancel = itemView.findViewById(R.id.txtCancel);
            txtType = itemView.findViewById(R.id.txtType);
        }

        public void setData(int position) {
            txtOrderNo.setText(String.format("Order Number : %s", orders.get(position).getOrder_no()));
            if (orders.get(position).getStatus() == 0){
                txtDetails.setText(String.format("Records:%d   Credits Hold : %.1f"
                        , orders.get(position).getRecord_count()
                        , ((float) orders.get(position).getRecord_count()) * 0.1f));
                txtCancel.setVisibility(View.VISIBLE);
            }else{
                txtDetails.setText(String.format("Records:%d  Queue:%d  Success:%d  Failed:%d  \nCredits Used : %.1f"
                        , orders.get(position).getRecord_count()
                        , orders.get(position).getQueue()
                        , orders.get(position).getSuccess()
                        , orders.get(position).getFail()
                        , ((float) orders.get(position).getSuccess()) * 0.1f));
                txtCancel.setVisibility(View.GONE);
            }
            txtTime.setText(DateUtil.toStringFormat_2(DateUtil.parseDataFromFormat12(TextUtils.isEmpty(orders.get(position).getSend_time()) ? orders.get(position).getCreated_at() : orders.get(position).getSend_time())));
            txtType.setText(orders.get(position).getType() == 0 ? "Pre-Recorded Audio" : "AIValet Voice");
            txtViewContent.setText(orders.get(position).getType() == 0 ? "Play Recording" : "View Message");
            txtView10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 1);
                }
            });
            txtViewContent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 0);
                }
            });
            txtCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 2);
                }
            });
        }
    }


    // ******************************class ViewHoler redefinition ***************************//
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.recycler_past_voicemail, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, final int position) {
        Vholder.setData(position);
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }
}
