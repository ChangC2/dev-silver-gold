package com.newhomepage.voicemail.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.R;

import org.json.JSONException;
import org.json.JSONObject;


public class RegisterOTPActivity extends BaseActivity{

    ImageView btnBack;
    EditText editCode1;
    EditText editCode2;
    EditText editCode3;
    EditText editCode4;
    Button btnActive;
    TextView tvCounter;
    TextView tvEmail;

    private String strOTP = "";
    private String mobile = "";
    private String userId = "";
    private String activityName = "register";

    private int TIMEINTERVAL = 30000;
    private int remainTime = TIMEINTERVAL; // 60 sec
    private final int interval = 1000; // 1 Second
    private Handler handler = new Handler();
    private Runnable runnable = new Runnable(){
        public void run() {
            if (remainTime >= 1000) {
                remainTime = remainTime - 1000;
                handler.postDelayed(runnable, interval);
                tvCounter.setText(String.format(getResources().getString(R.string.time_remain), 0, remainTime/1000));
            } else {
                handler.removeCallbacks(runnable);
                remainTime = TIMEINTERVAL;
                HideCounter(true);
                editCode1.setText("");editCode2.setText("");editCode3.setText("");editCode4.setText("");
                apiCallForResend();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_register_otp);
        initUI();
    }

    private void hiddenResendUI(){
        tvCounter.setVisibility(View.INVISIBLE);
    }

    private void initUI() {
        btnBack = findViewById(R.id.btn_back);
        editCode1 = findViewById(R.id.otp_edit_code1);
        editCode2 = findViewById(R.id.otp_edit_code2);
        editCode3 = findViewById(R.id.otp_edit_code3);
        editCode4 = findViewById(R.id.otp_edit_code4);
        btnActive = findViewById(R.id.btn_active);
        tvCounter = findViewById(R.id.tv_counter);
        tvEmail = findViewById(R.id.txtEmail);

        hiddenResendUI();
        tvEmail.setText(getIntent().getStringExtra("email"));

        editCode1.addTextChangedListener(textwatcher1);
        editCode2.addTextChangedListener(textwatcher2);
        editCode3.addTextChangedListener(textwatcher3);
        editCode4.addTextChangedListener(textwatcher4);

        // Register Button Actions
        btnBack.setOnClickListener(v->onBack());
        btnActive.setOnClickListener(v->onActive());
        enableActive(false);
    }

    private void enableActive(boolean isEnabled) {
        if (isEnabled) {
            btnActive.setEnabled(true);
            btnActive.setAlpha(1.0f);
        } else {
            btnActive.setEnabled(false);
            btnActive.setAlpha(0.5f);
        }
    }

    private void HideCounter(boolean flag) {
        if (flag) {
            tvCounter.setVisibility(View.INVISIBLE);
        } else {
            tvCounter.setVisibility(View.VISIBLE);
            tvCounter.setText("");
        }
    }

    private boolean validActive(String verifyCode) {
        boolean noErrorFound = true;
        if (verifyCode.isEmpty()) {
            Toast.makeText(RegisterOTPActivity.this, R.string.enter_verification_code, Toast.LENGTH_SHORT).show();
            noErrorFound = false;
        }
        return noErrorFound;
    }

    private void onBack() {
        handler.removeCallbacks(runnable);
        startActivity(new Intent(RegisterOTPActivity.this, LoginActivity.class));
        finish();
    }

    private void onActive() {
        if (validActive(strOTP)) {
            HideCounter(false);
            handler.postDelayed(runnable, interval);
            enableActive(false);
            apiCallForVerifyCode();
        }
    }


    private void moveMain(){
        handler.removeCallbacks(runnable);
        showToastMessage(R.string.verify_success);
        startActivity(new Intent(this, SendVoicemailsActivity.class));
        finish();
    }

    TextWatcher textwatcher1 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

        @Override
        public void afterTextChanged(Editable s) {
            if (s.toString().length() == 1) {
                editCode2.requestFocus();
            }
        }
    };
    TextWatcher textwatcher2 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (charSequence.toString().length() == 0) {
                editCode1.requestFocus();
                enableActive(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (s.toString().length() == 1) {
                editCode3.requestFocus();
            }
        }
    };
    TextWatcher textwatcher3 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (charSequence.toString().length() == 0) {
                editCode2.requestFocus();
                enableActive(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (s.toString().length() == 1) {
                editCode4.requestFocus();

            }
        }
    };
    TextWatcher textwatcher4 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (charSequence.toString().length() == 0) {
                editCode3.requestFocus();
                enableActive(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (s.toString().length() == 1) {
                strOTP = editCode1.getText().toString().trim() + editCode2.getText().toString().trim() + editCode3.getText().toString().trim() + editCode4.getText().toString().trim();
                if (strOTP.length() < 4) {
                    enableActive(false);
                } else {
                    enableActive(true);
                }
            }
        }
    };
    //***************************************//
    //             API Call Method           //
    //***************************************//

    void apiCallForVerifyCode() {
        showLoading();
        Ion.with(this)
                .load(C.verification_account)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("verification_code", strOTP)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showDlg(R.string.verify_fail, null, true);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    App.login(jsonObject.getString("token"));
                                    moveMain();
                                }else{
                                    showDlg(R.string.verify_fail, null, true);
                                }
                            } catch (JSONException jsonException) {
                                showDlg(R.string.verify_fail, null, true);
                            }
                        }
                    }
                });
    }

    void apiCallForResend() {
        showLoading();
        Ion.with(this)
                .load(C.resend)
                .setBodyParameter("token", App.getToken())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        showDlg("Verification code have been sent to you again.", null, false);
                    }
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}