package com.newhomepage.voicemail.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MContact;

import java.util.ArrayList;


public class RContactSelectorAdapter extends RecyclerView.Adapter<RContactSelectorAdapter.ViewHolder> {

    Context mContext;
    private ArrayList<MContact> contacts = new ArrayList<>();
    private ClickListener listener;

    public RContactSelectorAdapter(Context context, ArrayList<MContact> contacts, ClickListener pListener) {
        listener = pListener;
        mContext = context;
        this.contacts.addAll(contacts);
        notifyDataSetChanged();
    }

    public void setData(ArrayList<MContact> contacts) {
        this.contacts.clear();
        this.contacts.addAll(contacts);
        notifyDataSetChanged();
    }

    // ******************************class ViewHoler redefinition ***************************//
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtName, txtPhoneNumber, txtEmail;
        ImageView imgSelect;

        public ViewHolder(View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            txtPhoneNumber = itemView.findViewById(R.id.txtPhoneNumber);
            txtEmail = itemView.findViewById(R.id.txtEmail);
            imgSelect = itemView.findViewById(R.id.imgSelect);
        }

        public void setData(int position) {
            txtName.setText(String.format("Name : %s", contacts.get(position).getName()));
            txtPhoneNumber.setText(String.format("Mobile Number : %s", contacts.get(position).getPhone()));
            txtEmail.setText(String.format("Email : %s", contacts.get(position).getEmail()));
            imgSelect.setImageDrawable(ContextCompat.getDrawable(mContext, contacts.get(position).isSelected() ?  R.drawable.ic_radio_sel : R.drawable.ic_radio));
            imgSelect.setOnClickListener(v->{
                contacts.get(position).setSelected(!contacts.get(position).isSelected());
                notifyDataSetChanged();
            });
        }
    }


    // ******************************class ViewHoler redefinition ***************************//
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return  new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.recycler_contact_selector, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, final int position) {
        Vholder.setData(position);
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }
}
