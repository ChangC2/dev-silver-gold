package com.newhomepage.voicemail.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.adapters.RContactGroupAdapter;
import com.newhomepage.voicemail.models.MContactGroup;

import java.util.ArrayList;

public class ContactGroupFragment extends BottomSheetDialogFragment {

    RecyclerView recycler;
    RelativeLayout lytContent;
    TextView txtTitle;
    Button btnAdd;

    private View mFragView;

    private ClickListener mListener;
    public ArrayList<MContactGroup> groups = new ArrayList<>();
    RContactGroupAdapter adapter;
    public boolean needAddButton = false;
    public String itemTitle = "";

    public ContactGroupFragment(Activity context, ClickListener listener) {
        this.mListener = listener;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new BottomSheetDialog(getContext(), R.style.BottomSheetStyle);
        dialog.setCanceledOnTouchOutside(true);
        return dialog;
    }

    @Override
    public void onCancel(@NonNull DialogInterface dialog) {
        super.onCancel(dialog);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mFragView = inflater.inflate(R.layout.fragment_contact_group, container, false);
        initView();
        return mFragView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        lytContent.getLayoutParams().height = 650;
    }

    private void initView() {
        txtTitle = mFragView.findViewById(R.id.txtTitle);
        txtTitle.setText(String.format("Select %s", itemTitle));
        recycler = mFragView.findViewById(R.id.recycler);
        lytContent = mFragView.findViewById(R.id.lytContent);
        btnAdd = mFragView.findViewById(R.id.btnAdd);
        btnAdd.setText(String.format("Add %s", itemTitle));
        btnAdd.setVisibility(needAddButton ? View.VISIBLE : View.GONE);
        btnAdd.setOnClickListener(v->{
            mListener.onClick(groups.size(), 0);
            dismiss();
        });
        mFragView.findViewById(R.id.btnCancel).setOnClickListener(view->dismiss());
        setRecycler();
    }

    private void setRecycler() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recycler.setLayoutManager(linearLayoutManager);
        ClickListener listener = new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                mListener.onClick(index, type);
                dismiss();
            }
        };
        adapter = new RContactGroupAdapter(getActivity(), groups, listener, needAddButton, needAddButton);
        recycler.setAdapter(adapter);
    }

}
