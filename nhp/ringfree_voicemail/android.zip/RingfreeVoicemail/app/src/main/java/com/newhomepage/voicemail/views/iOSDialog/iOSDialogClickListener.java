package com.newhomepage.voicemail.views.iOSDialog;

public interface iOSDialogClickListener{
    void onClick(iOSDialog dialog);
}