package com.newhomepage.voicemail.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.DateUtil;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MLog;
import com.newhomepage.voicemail.models.MOrder;

import java.util.ArrayList;


public class RLogAdapter extends RecyclerView.Adapter<RLogAdapter.ViewHolder> {

    Context mContext;
    private ArrayList<MLog> logs = new ArrayList<>();
    private ClickListener listener;


    public RLogAdapter(Context context, ArrayList<MLog> logs, ClickListener pListener) {
        listener = pListener;
        mContext = context;
        this.logs.addAll(logs);
        notifyDataSetChanged();
    }

    public void setData(ArrayList<MLog> logs) {
        this.logs.clear();
        this.logs.addAll(logs);
        notifyDataSetChanged();
    }

    // ******************************class ViewHoler redefinition ***************************//
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtForwardingNumber, txtPhoneNumber, txtStatus, txtReason, txtTime, txtViewContent, txtType;
        ImageView imgPlay;

        public ViewHolder(View itemView) {
            super(itemView);
            txtForwardingNumber = itemView.findViewById(R.id.txtForwardingNumber);
            txtPhoneNumber = itemView.findViewById(R.id.txtPhoneNumber);
            txtStatus = itemView.findViewById(R.id.txtStatus);
            txtReason = itemView.findViewById(R.id.txtReason);
            txtTime = itemView.findViewById(R.id.txtTime);
            txtViewContent = itemView.findViewById(R.id.txtViewContent);
            txtType = itemView.findViewById(R.id.txtType);
        }

        public void setData(int position) {
            txtForwardingNumber.setText(String.format("Forwarding # : %s", logs.get(position).getForwarding_number()));
            txtPhoneNumber.setText(String.format("Phone # : %s", logs.get(position).getReceiver()));
            txtStatus.setText(String.format("Status : %s", logs.get(position).getStatus()));
            txtReason.setText(String.format("Reason : %s", logs.get(position).getReason()));
            txtTime.setText(String.format("Time : %s", DateUtil.toStringFormat_2(DateUtil.parseDataFromFormat12(logs.get(position).getCreated_at()))));
            txtType.setText(logs.get(position).getType() == 0 ? "Pre-Recorded Audio" : "AIValet Voice");
            txtViewContent.setText(logs.get(position).getType() == 0 ? "Play Recording" : "View Message");
            txtViewContent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 0);
                }
            });
        }
    }


    // ******************************class ViewHoler redefinition ***************************//
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.recycler_log, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, final int position) {
        Vholder.setData(position);
    }

    @Override
    public int getItemCount() {
        return logs.size();
    }
}
