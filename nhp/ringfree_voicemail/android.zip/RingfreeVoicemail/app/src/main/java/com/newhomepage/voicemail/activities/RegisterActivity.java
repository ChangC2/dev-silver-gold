package com.newhomepage.voicemail.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.R;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends BaseActivity{

    EditText editUsername;
    EditText editEmail;
    EditText editPassword;
    EditText editRePassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_register);
        initUI();
        initButtonActions();

    }

    private void initUI(){
        editUsername = findViewById(R.id.editUsername);
        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        editRePassword = findViewById(R.id.editRePassword);
    }

    private void initButtonActions(){
        findViewById(R.id.btnRegister).setOnClickListener(view-> onRegister());
        findViewById(R.id.txtLogin).setOnClickListener(view->moveLogin());
    }

    private void onRegister(){
        apiCallForRegister();
    }

    private void moveOTP(String email){
        showToastMessage(R.string.register_success);
        Intent intent = new Intent(this, RegisterOTPActivity.class);
        intent.putExtra("email", email);
        startActivity(intent);
        finish();
    }

    private void moveLogin(){
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    //***************************************//
    //             API Call Method           //
    //***************************************//

    void apiCallForRegister() {
        if (TextUtils.isEmpty(editEmail.getText()) || TextUtils.isEmpty(editUsername.getText()) || TextUtils.isEmpty(editPassword.getText())){
            showToastMessage(R.string.missing_param);
            return;
        }
        if (!editPassword.getText().toString().equalsIgnoreCase(editRePassword.getText().toString())){
            showToastMessage(R.string.mismatch_pass);
            return;
        }
        showLoading();
        Ion.with(this)
                .load(C.register_account)
                .setBodyParameter("email", editEmail.getText().toString().trim())
                .setBodyParameter("password", editPassword.getText().toString())
                .setBodyParameter("accountname", editUsername.getText().toString())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showDlg(R.string.register_fail, null, true);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    App.setToken(jsonObject.getString("token"));
                                    moveOTP(editEmail.getText().toString().trim());
                                }else{
                                    showToastMessage(jsonObject.optString("message"));
                                }
                            } catch (JSONException jsonException) {
                                showDlg(R.string.register_fail, null, true);
                            }
                        }
                    }
                });
    }

}