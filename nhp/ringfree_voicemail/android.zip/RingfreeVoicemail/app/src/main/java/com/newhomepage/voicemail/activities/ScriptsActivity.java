package com.newhomepage.voicemail.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.koushikdutta.ion.builder.Builders;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.GV;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.adapters.RScriptAdapter;
import com.newhomepage.voicemail.models.MScript;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ScriptsActivity extends BaseActivity {

    RecyclerView recyclerView;
    RScriptAdapter adapter;
    private ArrayList<MScript> scripts = new ArrayList<>();
    ProgressBar pBarLoading;
    EditText editName, editContent;
    Spinner spinnerSalutation;
    List<String> salutationList = new ArrayList<>();
    ArrayAdapter spinnerSalutationAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_scripts);

        //token = getIntent().getStringExtra(C.USER_TOEKN);
        initUI();
        initButtonActions();
        apiCallForGetScripts();
    }

    private void initUI() {
        recyclerView = findViewById(R.id.recyclerView);
    }

    private void setUI() {
        setRecycler();
        findViewById(R.id.txtEmpty).setVisibility(scripts.size() > 0 ? View.GONE : View.VISIBLE);
        if (scripts.size() == 0) onWrite(-1);
    }

    private void initButtonActions() {
        findViewById(R.id.imgBack).setOnClickListener(v -> finish());
        findViewById(R.id.imgAdd).setOnClickListener(v-> onWrite(-1));
    }

    private void setRecycler() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        ClickListener listener = new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                switch (type) {
                    case 1:
                        onWrite(index);
                        break;
                    case 2:
                        apiCallForDeleteScript(index);
                        break;
                    default:
                        break;
                }
            }
        };
        adapter = new RScriptAdapter(this, scripts, listener);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private void onWrite(int index) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_script, null);
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        dlg.setCanceledOnTouchOutside(false);
        editName = dialogView.findViewById(R.id.editName);
        editContent = dialogView.findViewById(R.id.editContent);
        spinnerSalutation = dialogView.findViewById(R.id.spinnerSalutation);
        setSalutationSpinner();
        pBarLoading = dialogView.findViewById(R.id.pBarLoading);
        pBarLoading.setVisibility(View.GONE);
        if (index > -1){
            TextView txtName = dialogView.findViewById(R.id.txtName);
            txtName.setText("Edit Script");
            editName.setText(scripts.get(index).getName());
            editContent.setText(scripts.get(index).getContent());
            if (TextUtils.isEmpty(scripts.get(index).getSalutation())){
                spinnerSalutation.setSelection(7);
            }else{
                for (int i=0;i<salutationList.size();i++){
                    if (scripts.get(index).getSalutation().equalsIgnoreCase(salutationList.get(i))){
                        spinnerSalutation.setSelection(i);
                    }
                }
            }
        }else{
            TextView txtName = dialogView.findViewById(R.id.txtName);
            txtName.setText("Add New Script");
        }
        dialogView.findViewById(R.id.btnClose).setOnClickListener(v -> {
            dlg.dismiss();
        });

        dialogView.findViewById(R.id.btnSave).setOnClickListener(v -> {
            String name = editName.getText().toString();
            String content = editContent.getText().toString();
            if (TextUtils.isEmpty(name)){
                showToastMessage("Please input name.");
                return;
            }

            if (TextUtils.isEmpty(content)){
                showToastMessage("Please input content.");
                return;
            }

            if (index == -1){
                apiCallForAddScript(name, content, spinnerSalutation.getSelectedItemPosition() == 7 ? "" : spinnerSalutation.getSelectedItem().toString());
            }else{
                apiCallForUpdateScript(index, name, content, spinnerSalutation.getSelectedItemPosition() == 7 ? "" : spinnerSalutation.getSelectedItem().toString());
            }
            dlg.dismiss();
        });
        dlg.setCanceledOnTouchOutside(false);
        dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dlg.show();
    }

    private void setSalutationSpinner() {
        salutationList = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.salutation_list)));
        spinnerSalutationAdapter = new ArrayAdapter<String>(this, R.layout.custom_spinner_black, salutationList);
        spinnerSalutationAdapter.setDropDownViewResource(R.layout.custom_spinner_combo);
        spinnerSalutation.setAdapter(spinnerSalutationAdapter);
        spinnerSalutation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinnerSalutation.setSelection(0);
    }

    public void apiCallForGetScripts() {
        showLoading();
        Ion.with(this)
                .load(C.getScripts)
                .setBodyParameter("token", App.getToken())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    scripts = gson.fromJson(jsonObject.getString("scripts"), new TypeToken<ArrayList<MScript>>() {
                                    }.getType());
                                    setUI();
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    void apiCallForAddScript(String name, String content, String salutation) {
        showLoading();
        Ion.with(this)
                .load(C.addScript)
                .setMultipartParameter("token", App.getToken())
                .setMultipartParameter("name", name)
                .setMultipartParameter("salutation", salutation)
                .setMultipartParameter("content", content)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showToastMessage(R.string.connection_fail);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")){
                                    Gson gson = new Gson();
                                    MScript newScript = gson.fromJson(jsonObject.getString("script"), MScript.class);
                                    scripts.add(0, newScript);
                                    adapter.setData(scripts);
                                    findViewById(R.id.txtEmpty).setVisibility(View.GONE);
                                    showToastMessage("Congrats ! You saved your script");
                                }
                            } catch (JSONException jsonException) {
                                showToastMessage(R.string.connection_fail);
                            }
                        }
                    }
                });
    }

    void apiCallForUpdateScript(int index, String name, String content, String salutation) {
        showLoading();
        Builders.Any.B builder =  Ion.with(this)
                .load(C.updateScript);
        builder.setMultipartParameter("id", scripts.get(index).getId())
                .setMultipartParameter("name", name)
                .setMultipartParameter("salutation", salutation)
                .setMultipartParameter("content", content)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showToastMessage(R.string.connection_fail);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")){
                                    scripts.get(index).setName(name);
                                    scripts.get(index).setSalutation(salutation);
                                    scripts.get(index).setContent(content);
                                    adapter.setData(scripts);
                                    findViewById(R.id.txtEmpty).setVisibility(View.GONE);
                                    showToastMessage("Congrats ! You saved your script");
                                }
                            } catch (JSONException jsonException) {
                                hideLoading();
                                showToastMessage(R.string.connection_fail);
                            }
                        }
                    }
                });
    }

    public void apiCallForDeleteScript(int index) {
        showLoading();
        Ion.with(this)
                .load(C.deleteScript)
                .setBodyParameter("id", scripts.get(index).getId())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    scripts.remove(index);
                                    adapter.setData(scripts);
                                    findViewById(R.id.txtEmpty).setVisibility(scripts.size() > 0 ? View.GONE : View.VISIBLE);
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }
}