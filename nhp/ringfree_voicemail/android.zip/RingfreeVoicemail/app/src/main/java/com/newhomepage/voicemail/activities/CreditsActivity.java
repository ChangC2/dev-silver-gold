package com.newhomepage.voicemail.activities;

import android.os.Bundle;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.koushikdutta.async.util.Charsets;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.GF;
import com.newhomepage.voicemail.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class CreditsActivity extends BaseActivity {

    WebView webView;
    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credits);
//        setDarkFullScreen();
        getSupportActionBar().hide();
        initUI();
        initButtonActions();
    }

    private void initUI() {
        webView = findViewById(R.id.webView);
        GF.setUpWebViewDefaults(webView);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }
            @Override
            public void onProgressChanged(WebView view, int newProgress){
                if(newProgress == 100){
                    hideLoading();
                }
            }
        });

        showLoading();
        String token = App.getToken();
        try {
            token = URLEncoder.encode(token, Charsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        url = String.format("%s?token=?%s", C.credits, token);
        webView.loadUrl("https://ringlessvoicemail.leadmarketer.com/credits/manage?token=" + App.getToken());
    }

    private void initButtonActions() {
        findViewById(R.id.imgBack).setOnClickListener(v->onBackPressed());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        GF.sendBroadCast(CreditsActivity.this, C.B_UPDATE_CREDITS);
    }
}