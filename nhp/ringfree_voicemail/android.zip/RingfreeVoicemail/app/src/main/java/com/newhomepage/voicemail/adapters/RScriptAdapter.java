package com.newhomepage.voicemail.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.DateUtil;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MScript;

import java.util.ArrayList;


public class RScriptAdapter extends RecyclerView.Adapter<RScriptAdapter.ViewHolder> {

    Context mContext;
    private ArrayList<MScript> scripts = new ArrayList<>();
    private ClickListener listener;


    public RScriptAdapter(Context context, ArrayList<MScript> scripts, ClickListener pListener) {
        listener = pListener;
        mContext = context;
        this.scripts.addAll(scripts);
        notifyDataSetChanged();
    }

    public void setData(ArrayList<MScript> scripts) {
        this.scripts.clear();
        this.scripts.addAll(scripts);
        notifyDataSetChanged();
    }

    // ******************************class ViewHoler redefinition ***************************//
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtName, txtContent;
        ImageView imgEdit, imgDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            txtContent = itemView.findViewById(R.id.txtContent);
            imgEdit = itemView.findViewById(R.id.imgEdit);
            imgDelete = itemView.findViewById(R.id.imgDelete);
        }

        public void setData(int position) {
            txtName.setText(scripts.get(position).getName());
            txtContent.setText(scripts.get(position).getContent());
            imgEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 1);
                }
            });
            imgDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 2);
                }
            });
        }
    }


    // ******************************class ViewHoler redefinition ***************************//
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return  new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.recycler_script, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, final int position) {
        Vholder.setData(position);
    }

    @Override
    public int getItemCount() {
        return scripts.size();
    }
}
