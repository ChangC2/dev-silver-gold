package com.newhomepage.voicemail.activities;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.koushikdutta.ion.ProgressCallback;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.BroadCastReceiverListener;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.DateUtil;
import com.newhomepage.voicemail.GF;
import com.newhomepage.voicemail.GV;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.fragment.ContactGroupFragment;
import com.newhomepage.voicemail.models.MContact;
import com.newhomepage.voicemail.models.MContactGroup;
import com.newhomepage.voicemail.models.MRecording;
import com.newhomepage.voicemail.models.MScript;
import com.newhomepage.voicemail.models.MVoice;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class SendVoicemailsActivity extends BaseActivity implements TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener {

    ImageView btnNavMenu;
    LinearLayout lytMenu;
    LinearLayout menuRecording, menuScripts, menuProVoices, menuUserVoices, menuPendings, menuScheduled, menuDelivered, menuContacts, menuCredits, menuAccount, menuFaq, menuClose;
    View btnHideMenu;

    Button btnPreRecorded, btnAIVoiceCloning;

    private ImageButton pauseBtn, playBtn;
    private MediaPlayer mPlayer;
    private TextView startTime, voiceTime, txtGroup, txtContacts, txtCosts, txtMedia, txtNumberPerDay;
    private SeekBar voicePrgs;
    private EditText editForwardingNumber, editReForwardingNumber, editContent, editNumberBroadcast, editDaysBetweenEach;
    Spinner spinnerAudio, spinnerScripts;

    CheckBox chkImmediately, chkScheduled, chkBreakup;
    TextView txtDate, txtTime;

    private Handler hdlr = new Handler();

    int type = 0;

    boolean isOpened = false;

    private ArrayList<MRecording> recordings = new ArrayList<>();
    private ArrayList<MVoice> voices = new ArrayList<>();
    private ArrayList<MScript> scripts = new ArrayList<>();
    ArrayList<MContact> contacts = new ArrayList<>();
    ArrayList<MContactGroup> groups = new ArrayList<>();
    ArrayList<MContact> filteredContacts = new ArrayList<>();
    String groupId = null;

    List<String> salutationList = new ArrayList<>();
    String audioUrl = "";
    int signed = 1;
    Spinner spinnerSalutation;
    ArrayAdapter spinnerAudioAdapter, spinnerScriptAdapter, spinnerSalutationAdapter;

    private ContactGroupFragment contactGroupFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        Log.d("Token=>", App.getToken());
        setContentView(R.layout.activity_send_voicemails);

        initUI();
        initButtonActions();
        GF.registerBroadCast(this, new String[]{C.B_UPDATE_APPDATA}, new BroadCastReceiverListener() {
            @Override
            public void onReceive(Context context, Intent intent) {
                apiCallForGetMainData(false);
            }
        });
        GF.registerBroadCast(this, new String[]{C.B_UPDATE_CREDITS}, new BroadCastReceiverListener() {
            @Override
            public void onReceive(Context context, Intent intent) {
                apiCallForGetMainData(true);
            }
        });
        apiCallForGetMainData(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (GV.isDeclined) {
            GV.isDeclined = false;
            finish();
        }
    }

    private void initUI() {
        btnNavMenu = findViewById(R.id.img_nav_menu);
        lytMenu = findViewById(R.id.lyt_menu);
        menuRecording = findViewById(R.id.lyt_recording);
        menuProVoices = findViewById(R.id.lyt_pro_voices);
        menuUserVoices = findViewById(R.id.lyt_user_voices);
        menuScripts = findViewById(R.id.lyt_scripts);
        menuPendings = findViewById(R.id.lyt_pending_orders);
        menuScheduled = findViewById(R.id.lyt_scheduled_orders);
        menuDelivered = findViewById(R.id.lyt_delivered_orders);
        menuContacts = findViewById(R.id.lyt_contacts);
        menuCredits = findViewById(R.id.lyt_credits);
        menuAccount = findViewById(R.id.lyt_account);
        menuFaq = findViewById(R.id.lyt_faq);
        menuClose = findViewById(R.id.lyt_close);
        btnHideMenu = findViewById(R.id.btn_hide_menu);

        btnPreRecorded = findViewById(R.id.btnPreRecorded);
        btnAIVoiceCloning = findViewById(R.id.btnAIVoiceCloning);

        txtGroup = findViewById(R.id.txtGroup);
        txtContacts = findViewById(R.id.txtContacts);
        txtCosts = findViewById(R.id.txtCosts);
        editForwardingNumber = findViewById(R.id.editForwardingNumber);
        editForwardingNumber.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i== EditorInfo.IME_ACTION_DONE){
                    GV.forwarding_number = editForwardingNumber.getText().toString();
                }
                return false;
            }
        });
        editForwardingNumber.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if(!hasFocus){
                    GV.forwarding_number = editForwardingNumber.getText().toString();
                }
            }
        });

        editReForwardingNumber = findViewById(R.id.editReForwardingNumber);
        txtMedia = findViewById(R.id.txtMedia);
        spinnerAudio = findViewById(R.id.spinnerAudio);
        spinnerScripts = findViewById(R.id.spinnerScripts);
        spinnerSalutation = findViewById(R.id.spinnerSalutation);
        editContent = findViewById(R.id.editContent);
        playBtn = (ImageButton) findViewById(R.id.btnPlay);
        pauseBtn = (ImageButton) findViewById(R.id.btnPause);
        pauseBtn.setEnabled(false);
        pauseBtn.setVisibility(View.GONE);
        startTime = (TextView) findViewById(R.id.txtStartTime);
        voiceTime = (TextView) findViewById(R.id.txtSongTime);
        voicePrgs = (SeekBar) findViewById(R.id.sBar);
        voicePrgs.setClickable(false);
        pauseBtn.setEnabled(false);

        chkImmediately = findViewById(R.id.chkImmediately);
        chkScheduled = findViewById(R.id.chkScheduled);
        chkImmediately.setChecked(true);
        chkScheduled.setChecked(false);
        findViewById(R.id.lytSchedule).setVisibility(View.GONE);
        txtDate = findViewById(R.id.txt_date);
        txtTime = findViewById(R.id.txt_time);
        chkBreakup = findViewById(R.id.chkBreakup);
        chkBreakup.setChecked(false);
        findViewById(R.id.lytBreakup).setVisibility(View.GONE);
        txtNumberPerDay = findViewById(R.id.txtNumberPerDay);
        editNumberBroadcast = findViewById(R.id.editNumberBroadcast);
        editNumberBroadcast.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i== EditorInfo.IME_ACTION_DONE){
                    setNumberBroadcast();
                }
                return false;
            }
        });
        editNumberBroadcast.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if(!hasFocus){
                    setNumberBroadcast();
                }
            }
        });

        editDaysBetweenEach = findViewById(R.id.editDaysBetweenEach);
        onPreRecorded();
    }

    private void setNumberBroadcast(){
        int numberBroadcast = 0;
        try {
            numberBroadcast = Integer.parseInt(editNumberBroadcast.getText().toString());
            if (numberBroadcast < 1){
                numberBroadcast = 1;
                editNumberBroadcast.setText("1");
            }
        } catch(NumberFormatException nfe) {
            numberBroadcast = 1;
            editNumberBroadcast.setText("1");
        }
        int numPerDay =((int) (filteredContacts.size() - 1) / numberBroadcast ) + 1;
        txtNumberPerDay.setText(String.format("= %s Attempts per day", numPerDay));
    }

    private void initButtonActions() {
        btnNavMenu.setOnClickListener(view -> onNavMenu());
        btnHideMenu.setOnClickListener(view -> onNavMenu());
        menuRecording.setOnClickListener(view -> onMenuRecording());
        menuProVoices.setOnClickListener(view -> onMenuVoices(1));
        menuUserVoices.setOnClickListener(view -> onMenuVoices(0));
        menuScripts.setOnClickListener(view -> onMenuScript());
        menuPendings.setOnClickListener(view -> onMenuPast(0));
        menuScheduled.setOnClickListener(view -> onMenuPast(1));
        menuDelivered.setOnClickListener(view -> onMenuPast(2));
        menuContacts.setOnClickListener(view -> onMenuContacts());
        menuCredits.setOnClickListener(view -> onMenuCredits());
        menuAccount.setOnClickListener(view -> onMenuAccount());
        menuFaq.setOnClickListener(view -> onMenuFaq());
        menuClose.setOnClickListener(view -> onMenuClose());

        btnPreRecorded.setOnClickListener(v -> onPreRecorded());
        btnAIVoiceCloning.setOnClickListener(v -> onAIVoiceCloning());

        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPlayAudio();
            }
        });
        pauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPauseAudio();
            }
        });

        findViewById(R.id.txtViewContacts).setOnClickListener(v -> {
            Intent intent = new Intent(SendVoicemailsActivity.this, ContactsActivity.class);
            intent.putExtra("group", groupId);
            startActivity(intent);
        });

        chkImmediately.setOnClickListener(v -> {
            if (chkBreakup.isChecked()){
                chkScheduled.setChecked(true);
                chkImmediately.setChecked(false);
                findViewById(R.id.lytSchedule).setVisibility(View.VISIBLE);
                return;
            }
            chkImmediately.setChecked(true);
            chkScheduled.setChecked(false);
            findViewById(R.id.lytSchedule).setVisibility(View.GONE);
        });
        chkScheduled.setOnClickListener(v -> {
            chkScheduled.setChecked(true);
            chkImmediately.setChecked(false);
            findViewById(R.id.lytSchedule).setVisibility(View.VISIBLE);
        });

        chkBreakup.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                findViewById(R.id.lytBreakup).setVisibility(isChecked ? View.VISIBLE : View.GONE);
                chkScheduled.setChecked(true);
                chkImmediately.setChecked(false);
                findViewById(R.id.lytSchedule).setVisibility(View.VISIBLE);
            }
        });

        txtDate.setOnClickListener(view -> onDate());
        txtTime.setOnClickListener(view -> onTime());

        findViewById(R.id.btnSend).setOnClickListener(v -> {
            onSendVoicemail();
        });
        findViewById(R.id.lytGroup).setOnClickListener(v -> onGroup());

        findViewById(R.id.btnTest).setOnClickListener(v -> {
            if (spinnerAudio.getSelectedItemPosition() == 0) {
                showToastMessage(type == 0 ? "Please select a Recording." : "Please select a voice.");
                return;
            }
            if (TextUtils.isEmpty(editForwardingNumber.getText())) {
                showToastMessage("Please input a forwarding number.");
                return;
            }
            if (!editForwardingNumber.getText().toString().equalsIgnoreCase(editReForwardingNumber.getText().toString())) {
                showToastMessage("Mismatch Forwarding Number.");
                return;
            }
            if (type == 1 && TextUtils.isEmpty(editContent.getText())) {
                showToastMessage("Please input a message.");
                return;
            }

            showDlg(String.format("The test voicemail will be sent to the phone on account!\n\nCredits to be used : %.1f\nPhone # : %s", GV.credits_to_send, editForwardingNumber.getText().toString()), new ClickListener() {
                @Override
                public void onClick(int index, int type) {
                    if (index == 0){
                        apiCallForSaveTestMailLog();
                    }
                }
            }, true);
        });
    }

    private void setUI() {
        if (!App.readFaq()) {
            Intent intent = new Intent(SendVoicemailsActivity.this, FaqActivity.class);
            startActivity(intent);
            App.setRaadFaq();
        } else {
            if (recordings.size() == 0) {
                Intent intent = new Intent(SendVoicemailsActivity.this, RecordingsActivity.class);
                startActivity(intent);
            } else if (contacts.size() == 0) {
                Intent intent = new Intent(SendVoicemailsActivity.this, ContactsActivity.class);
                startActivity(intent);
            }
        }
        setContactsInfo();
        editForwardingNumber.setText(GV.forwarding_number);
        editReForwardingNumber.setText(GV.forwarding_number);
        setAudioSpinner();
        setScriptsSpinner();
        setSalutationSpinner();
        if (signed == 0) {
            startActivity(new Intent(SendVoicemailsActivity.this, SignActivity.class));
        }
    }

    private void onGroup() {
        contactGroupFragment = new ContactGroupFragment(this, new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                if (index == 0) {
                    groupId = "";
                } else {
                    groupId = groups.get(index - 1).getId();
                }
                setContactsInfo();
                setNumberBroadcast();
            }
        });
        contactGroupFragment.setCancelable(true);
        MContactGroup g = new MContactGroup();
        g.setName("All Contacts");
        contactGroupFragment.groups.add(g);
        contactGroupFragment.groups.addAll(groups);
        contactGroupFragment.show(getSupportFragmentManager(), contactGroupFragment.getTag());
        contactGroupFragment.needAddButton = false;
        contactGroupFragment.itemTitle = "Group";
    }

    private void setContactsInfo() {
        String groupName = "Select Contacts";
        filteredContacts.clear();
        if (!TextUtils.isEmpty(groupId)) {
            for (MContactGroup cg : groups) {
                if (cg.getId().equalsIgnoreCase(groupId)) {
                    groupName = cg.getName();
                    break;
                }
            }
            for (MContact c : contacts) {
                if (c.getGroup().equalsIgnoreCase(groupId)) {
                    filteredContacts.add(c);
                }
            }
        } else if (groupId != null) {
            groupName = "All Contacts";
            filteredContacts.addAll((contacts));
        }
        txtGroup.setText(groupName);
        txtContacts.setText(String.format("# of Records : %d", filteredContacts.size()));
        if (GV.credits > filteredContacts.size() * GV.credits_to_send){
            txtCosts.setText(String.format("*%.1f Credits Availalbe.You need %.1f credits to send this message.", GV.credits, filteredContacts.size() * GV.credits_to_send));
        }else{
            txtCosts.setText(String.format("*You don't have enough credits to send this message. %.1f Credits Availalbe.You need %.1f credits to send this message. Please click here to refill.", GV.credits, filteredContacts.size() * GV.credits_to_send));
            txtCosts.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(SendVoicemailsActivity.this, CreditsActivity.class);
                    startActivity(intent);
                }
            });
        }
    }

    private void onDate() {
        Calendar now = Calendar.getInstance();
        DatePickerDialog dpd = DatePickerDialog.newInstance(
                this,
                now.get(Calendar.YEAR), // Initial year selection
                now.get(Calendar.MONTH), // Initial month selection
                now.get(Calendar.DAY_OF_MONTH) // Inital day selection
        );
        dpd.setMinDate(now);
        dpd.show(getSupportFragmentManager(), "");
    }

    private void onTime() {
        Calendar now = Calendar.getInstance();
        TimePickerDialog tpd = TimePickerDialog.newInstance(
                this,
                0, // Initial year selection
                0, // Initial month selection
                true// Inital day selection
        );
        tpd.setMinTime(8, 0, 0);
        tpd.setMaxTime(17, 59, 59);
        tpd.show(getSupportFragmentManager(), "");
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        String dateString = DateUtil.getFormattedDate1FromTimestamp(DateUtil.getTimestamp(year, monthOfYear, dayOfMonth));
        txtDate.setText(dateString);
    }

    @Override
    public void onTimeSet(TimePickerDialog view, int hourOfDay, int minute, int second) {
        String timeString = DateUtil.toStringFormat_10(DateUtil.getTime(hourOfDay, minute));
        txtTime.setText(timeString);
    }


    void setAudioSpinner() {
        List<String> listTitles = new ArrayList<String>();
        if (type == 0) {
            listTitles.add("Select Recording");
            for (int i = 0; i < recordings.size(); i++) {
                listTitles.add(recordings.get(i).getName());
            }
        } else {
            listTitles.add("Select Voice");
            for (int i = 0; i < voices.size(); i++) {
                listTitles.add(voices.get(i).getName());
            }
            listTitles.add("+ Create your own Avatar cloned voice\n");
        }
        spinnerAudioAdapter = new ArrayAdapter<String>(this, R.layout.custom_spinner_black, listTitles) {
            @Override
            public boolean isEnabled(int position) {
                if (listTitles.get(position).equalsIgnoreCase("--- Pro Voices ---")
                        || listTitles.get(position).equalsIgnoreCase("--- Your Cloned Voices ---")) {
                    return false;
                }
                return true;
            }

            @Override
            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View mView = super.getDropDownView(position, convertView, parent);
                TextView mTextView = (TextView) mView;
                if (listTitles.get(position).equalsIgnoreCase("--- Pro Voices ---")
                        || listTitles.get(position).equalsIgnoreCase("--- Your Cloned Voices ---")) {
                    mTextView.setTextColor(ContextCompat.getColor(SendVoicemailsActivity.this, R.color.md_grey_500));
                    mTextView.setTextSize(16);
                }else if (listTitles.get(position).equalsIgnoreCase("+ Create your own Avatar cloned voice\n")) {
                    mTextView.setTextColor(ContextCompat.getColor(SendVoicemailsActivity.this, R.color.md_blue_700));
                    mTextView.setTextSize(16);
                } else {
                    mTextView.setTextSize(14);
                    mTextView.setTextColor(Color.BLACK);
                }
                return mView;
            }
        };
        spinnerAudioAdapter.setDropDownViewResource(R.layout.custom_spinner_combo);
        spinnerAudio.setAdapter(spinnerAudioAdapter);
        spinnerAudio.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (type == 0){
                    if (position > 0) {
                        audioUrl = recordings.get(spinnerAudio.getSelectedItemPosition() - 1).getUrl();
                        loadAudio();
                    }else{
                        releasePlayer();
                    }
                }else{
                    if (position == 0) {
                        releasePlayer();
                    }else if (position < voices.size() + 1) {
                        audioUrl = voices.get(spinnerAudio.getSelectedItemPosition() - 1).getUrl();
                        loadAudio();
                    }else{
                        Intent intent = new Intent(SendVoicemailsActivity.this, VoicesActivity.class);
                        intent.putExtra("type", 0);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinnerAudio.setSelection(0);
    }

    void setScriptsSpinner() {
        List<String> listTitles = new ArrayList<String>();
        listTitles.add("Manual Input");
        for (int i = 0; i < scripts.size(); i++) {
            listTitles.add(scripts.get(i).getName());
        }
        spinnerScriptAdapter = new ArrayAdapter<String>(this, R.layout.custom_spinner_black, listTitles);
        spinnerScriptAdapter.setDropDownViewResource(R.layout.custom_spinner_combo);
        spinnerScripts.setAdapter(spinnerScriptAdapter);
        spinnerScripts.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    editContent.setText(TextUtils.isEmpty(scripts.get(position - 1).getSalutation()) ?
                            scripts.get(position - 1).getContent() :
                            String.format("%s.\n%s", scripts.get(position - 1).getSalutation(), scripts.get(position - 1).getContent()));
                    int salutationIndex = TextUtils.isEmpty(scripts.get(position - 1).getSalutation()) ? 7 : salutationList.indexOf(scripts.get(position - 1).getSalutation());
                    spinnerSalutation.setSelection(salutationIndex);
                } else {
                    spinnerSalutation.setSelection(7);
                    editContent.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinnerScripts.setSelection(0);
    }

    private void setSalutationSpinner() {
        salutationList = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.salutation_list)));
        spinnerSalutationAdapter = new ArrayAdapter<String>(this, R.layout.custom_spinner_black, salutationList);
        spinnerSalutationAdapter.setDropDownViewResource(R.layout.custom_spinner_combo);
        spinnerSalutation.setAdapter(spinnerSalutationAdapter);
        spinnerSalutation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spinnerScripts.getSelectedItemPosition() == 0) {
                    editContent.setText(spinnerSalutation.getSelectedItemPosition() == 7 ? "" : spinnerSalutation.getSelectedItem().toString());
                } else {
                    editContent.setText(spinnerSalutation.getSelectedItemPosition() == 7 ? scripts.get(spinnerScripts.getSelectedItemPosition() - 1).getContent() : spinnerSalutation.getSelectedItem().toString() + ".\n" + scripts.get(spinnerScripts.getSelectedItemPosition() - 1).getContent());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinnerSalutation.setSelection(7);
    }

    private void loadAudio() {
        releasePlayer();
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                //onPlayAudio();
                voiceTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()),
                        TimeUnit.MILLISECONDS.toSeconds(mPlayer.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()))));
            }
        });
        File audioFile = new File(getCacheDir(), "audio.wav");
        showLoading();
        Ion.with(this)
                .load(audioUrl)
                .progress(new ProgressCallback() {
                    @Override
                    public void onProgress(long downloaded, long total) {
                        System.out.println("" + downloaded + " / " + total);
                    }
                })
                .write(audioFile)
                .setCallback(new FutureCallback<File>() {
                    @Override
                    public void onCompleted(Exception e, File file) {
                        hideLoading();
                        if (mPlayer == null)
                            return; // When user finish this activity before download complete.
                        if (file != null && file.exists()) {
                            try {
                                mPlayer.setDataSource(file.getPath());
                                mPlayer.prepare(); // might take long! (for buffering, etc)
                            } catch (IllegalArgumentException exception) {
                                Toast.makeText(SendVoicemailsActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            } catch (IllegalStateException exception) {
                                Toast.makeText(SendVoicemailsActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            } catch (IOException exception) {
                                Toast.makeText(SendVoicemailsActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(SendVoicemailsActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void onNavMenu() {
        if (isOpened)
            closeMenu();
        else
            openMenu();
    }

    private void openMenu() {
        lytMenu.setVisibility(View.VISIBLE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) lytMenu.getLayoutParams();
        ValueAnimator anim = ValueAnimator.ofInt(-lytMenu.getMeasuredWidth(), 0);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                int val = (Integer) valueAnimator.getAnimatedValue();
                layoutParams.setMarginStart(val);
                lytMenu.setLayoutParams(layoutParams);
                btnHideMenu.setVisibility(View.VISIBLE);
            }
        });
        anim.setDuration(500);
        anim.start();
        isOpened = true;
    }

    private void closeMenu() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) lytMenu.getLayoutParams();
        ValueAnimator anim = ValueAnimator.ofInt(0, -lytMenu.getMeasuredWidth());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                int val = (Integer) valueAnimator.getAnimatedValue();
                layoutParams.setMarginStart(val);
                lytMenu.setLayoutParams(layoutParams);
                btnHideMenu.setVisibility(View.GONE);
            }
        });
        anim.setDuration(500);
        anim.start();
        isOpened = false;
    }

    private void onPreRecorded() {
        type = 0;
        btnPreRecorded.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_blue));
        btnPreRecorded.setTextColor(ContextCompat.getColor(this, R.color.white));
        btnAIVoiceCloning.setBackground(ContextCompat.getDrawable(this, R.color.transparent));
        btnAIVoiceCloning.setTextColor(ContextCompat.getColor(this, R.color.colorAccent));
        findViewById(R.id.lytAIVoice).setVisibility(View.GONE);
        txtMedia.setText("The pre-recorded message to deliver into your contact's voicemail inbox");
        setAudioSpinner();
        releasePlayer();
    }

    private void onAIVoiceCloning() {
        type = 1;
        btnAIVoiceCloning.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_blue));
        btnAIVoiceCloning.setTextColor(ContextCompat.getColor(this, R.color.white));
        btnPreRecorded.setBackground(ContextCompat.getDrawable(this, R.color.transparent));
        btnPreRecorded.setTextColor(ContextCompat.getColor(this, R.color.colorAccent));
        findViewById(R.id.lytAIVoice).setVisibility(View.VISIBLE);
        txtMedia.setText("AI Avatar Voice to replicate personalized voicemails sending to each of your contacts");
        setAudioSpinner();
        setScriptsSpinner();
        releasePlayer();
    }

    private void onMenuRecording() {
        Intent intent = new Intent(this, RecordingsActivity.class);
        startActivity(intent);
        closeMenu();
    }

    private void onMenuVoices(int type) {
        Intent intent = new Intent(this, VoicesActivity.class);
        intent.putExtra("type", type);
        startActivity(intent);
        closeMenu();
    }


    private void onMenuScript() {
        Intent intent = new Intent(this, ScriptsActivity.class);
        startActivity(intent);
        closeMenu();
    }

    private void onMenuPast(int type) {
        Intent intent = new Intent(this, PastVoicemailsActivity.class);
        intent.putExtra("type", type);
        startActivity(intent);
        closeMenu();
    }

    private void onMenuContacts() {
        Intent intent = new Intent(SendVoicemailsActivity.this, ContactsActivity.class);
        intent.putExtra("group", "");
        startActivity(intent);
        closeMenu();
    }

    private void onMenuCredits() {
        Intent intent = new Intent(SendVoicemailsActivity.this, CreditsActivity.class);
        startActivity(intent);
        closeMenu();
    }

    private void onMenuAccount() {
        Intent intent = new Intent(SendVoicemailsActivity.this, AccountsActivity.class);
        startActivity(intent);
        closeMenu();
    }

    private void onMenuFaq() {
        Intent intent = new Intent(SendVoicemailsActivity.this, FaqActivity.class);
        startActivity(intent);
        closeMenu();
    }

    private void onMenuClose() {
        ClickListener listener = new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                App.logout();
                startActivity(new Intent(SendVoicemailsActivity.this, LoginActivity.class));
                finish();
            }
        };
        showDlg(getString(R.string.logout_confirm), listener, true);
        closeMenu();
    }

    void onSendVoicemail() {
        if (contacts == null || contacts.size() == 0 || filteredContacts.size() == 0) {
            showToastMessage("Please select Contacts.");
            return;
        }
        if (spinnerAudio.getSelectedItemPosition() == 0) {
            showToastMessage(type == 0 ? "Please select a Recording." : "Please select a voice.");
            return;
        }
        if (TextUtils.isEmpty(editForwardingNumber.getText())) {
            showToastMessage("Please input a forwarding number.");
            return;
        }
        if (!editForwardingNumber.getText().toString().equalsIgnoreCase(editReForwardingNumber.getText().toString())) {
            showToastMessage("Mismatch Forwarding Number.");
            return;
        }
        if (type == 1 && TextUtils.isEmpty(editContent.getText())) {
            showToastMessage("Please input a message.");
            return;
        }
        if (chkScheduled.isChecked() && (TextUtils.isEmpty(txtDate.getText()) || TextUtils.isEmpty(txtTime.getText()))) {
            showToastMessage("Please set scheduled date and time.");
            return;
        }

        if (type == 0) {
            moveToConfirm(recordings.get(spinnerAudio.getSelectedItemPosition() - 1).getUrl());
        } else {
            getVoiceUrl();
        }
    }

    void getVoiceUrl() {
        String voice_url = voices.get(spinnerAudio.getSelectedItemPosition() - 1).getUrl();
        String content = editContent.getText().toString().replace("First Name", contacts.get(0).getName());
        showLoading();
        Ion.with(this)
                .load(C.tts_from_url)
                .setTimeout(300000)
                .setBodyParameter("voice_url", voice_url)
                .setBodyParameter("contents", content)
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                String audio_resource_url = jsonObject.getString("url");
                                moveToConfirm(audio_resource_url);
                            } catch (JSONException jsonException) {
                                showDlg(R.string.connection_fail, null, false);
                            }
                        }
                    }
                });
    }

    private void moveToConfirm(String url) {
        Intent intent = new Intent(SendVoicemailsActivity.this, ConfirmVoicemailActivity.class);
        intent.putExtra("type", type);
        if (type == 0) {
            intent.putExtra("audio_url", url);
        } else {
            intent.putExtra("audio_url", voices.get(spinnerAudio.getSelectedItemPosition() - 1).getUrl());
        }
        intent.putExtra("preview_url", url);
        intent.putExtra("audio_name", type == 0 ? recordings.get(spinnerAudio.getSelectedItemPosition() - 1).getName() : voices.get(spinnerAudio.getSelectedItemPosition() - 1).getName());
        intent.putExtra("group", groupId);
        Gson gson = new Gson();
        String json = gson.toJson(filteredContacts);
        intent.putExtra("contacts", json);
        intent.putExtra("content", editContent.getText().toString());
        intent.putExtra("voice_id", type == 0 ? "" : voices.get(spinnerAudio.getSelectedItemPosition() - 1).getId());
        intent.putExtra("is_scheduled", chkScheduled.isChecked());
        String dateString = "", timeString = "";
        if (chkScheduled.isChecked() && !TextUtils.isEmpty(txtDate.getText())) {
            dateString = DateUtil.toStringFormat_13(DateUtil.parseDataFromFormat1(txtDate.getText().toString()));
        }
        if (chkScheduled.isChecked() && !TextUtils.isEmpty(txtTime.getText())) {
            timeString = DateUtil.toStringFormat_21(DateUtil.parseDataFromFormat10(txtTime.getText().toString()));
        }
        intent.putExtra("send_time", chkScheduled.isChecked() ? String.format("%s %s", dateString, timeString) : "");
        intent.putExtra("break_up", chkBreakup.isChecked());
        intent.putExtra("broadcasts_number", editNumberBroadcast.getText().toString());
        intent.putExtra("between_days", editDaysBetweenEach.getText().toString());
        startActivity(intent);
    }

    //***************************************//
    //             API Call Method           //
    //***************************************//
    public void apiCallForGetMainData(boolean shouldShowLoading) {
        if (shouldShowLoading) showLoading();
        Ion.with(this)
                .load(C.getMainData)
                .setBodyParameter("token", App.getToken())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    recordings = gson.fromJson(jsonObject.getJSONObject("data").getString("recordings"), new TypeToken<ArrayList<MRecording>>() {
                                    }.getType());
                                    ArrayList<MVoice> pro_voices = gson.fromJson(jsonObject.getJSONObject("data").getString("pro_voices"), new TypeToken<ArrayList<MVoice>>() {
                                    }.getType());
                                    ArrayList<MVoice> user_voices = gson.fromJson(jsonObject.getJSONObject("data").getString("user_voices"), new TypeToken<ArrayList<MVoice>>() {
                                    }.getType());
                                    voices.clear();
                                    MVoice proVoice = new MVoice();
                                    proVoice.setName("--- Pro Voices ---");
                                    voices.add(proVoice);
                                    voices.addAll(pro_voices);

                                    if (user_voices.size() > 0) {
                                        MVoice userVoice = new MVoice();
                                        userVoice.setName("--- Your Cloned Voices ---");
                                        voices.add(userVoice);
                                        voices.addAll(user_voices);
                                    }
                                    scripts = gson.fromJson(jsonObject.getJSONObject("data").getString("scripts"), new TypeToken<ArrayList<MScript>>() {
                                    }.getType());
                                    contacts = gson.fromJson(jsonObject.getJSONObject("data").getString("contacts"), new TypeToken<ArrayList<MContact>>() {
                                    }.getType());
                                    groupId = null;
                                    groups = gson.fromJson(jsonObject.getJSONObject("data").getString("contact_groups"), new TypeToken<ArrayList<MContactGroup>>() {
                                    }.getType());
                                    GV.forwarding_number = jsonObject.getJSONObject("data").getString("forwarding_number");
                                    GV.credits = jsonObject.getJSONObject("data").getDouble("credits");
                                    GV.credits_to_send = jsonObject.getJSONObject("data").optDouble("credits_to_send");
                                    signed = jsonObject.getJSONObject("data").optInt("signed");
                                    setUI();
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForSaveTestMailLog() {
        String audioName = type == 0 ? recordings.get(spinnerAudio.getSelectedItemPosition() - 1).getName() : voices.get(spinnerAudio.getSelectedItemPosition() - 1).getName();
        String content = type == 0 ? "" : editContent.getText().toString();
        String voiceId = type == 0 ? "" : voices.get(spinnerAudio.getSelectedItemPosition() - 1).getId();
        showLoading();
        Ion.with(this)
                .load(C.saveTestMailLog)
                .setBodyParameter("token", App.getToken())
                .setBodyParameter("type", String.valueOf(type))
                .setBodyParameter("forwarding_number", GV.forwarding_number)
                .setBodyParameter("record_name", audioName)
                .setBodyParameter("audioUrl", audioUrl)
                .setBodyParameter("content", type == 1 ? content : "")
                .setBodyParameter("voice_id", type == 1 ? voiceId : "")
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    showDlg("Your test message is now in Queue.  You can go to Past Voicemails on Left menu to check Status. You will get an email when it is sent.", new ClickListener() {
                                        @Override
                                        public void onClick(int index, int type) {
                                        }
                                    }, false);
                                } else {
                                    showDlg(jsonObject.optString("message"), new ClickListener() {
                                        @Override
                                        public void onClick(int index, int type) {
                                        }
                                    }, false);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    private void onPlayAudio() {
        mPlayer.start();
        voiceTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()),
                TimeUnit.MILLISECONDS.toSeconds(mPlayer.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()))));
        startTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()),
                TimeUnit.MILLISECONDS.toSeconds(mPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()))));
        voicePrgs.setMax(mPlayer.getDuration());
        voicePrgs.setProgress(mPlayer.getCurrentPosition());
        hdlr.postDelayed(UpdateSongTime, 100);
        pauseBtn.setEnabled(true);
        pauseBtn.setVisibility(View.VISIBLE);
        playBtn.setEnabled(false);
        playBtn.setVisibility(View.GONE);
    }

    private void onPauseAudio() {
        mPlayer.pause();
        pauseBtn.setEnabled(false);
        pauseBtn.setVisibility(View.GONE);
        playBtn.setEnabled(true);
        playBtn.setVisibility(View.VISIBLE);
    }

    private Runnable UpdateSongTime = new Runnable() {
        @Override
        public void run() {
            if (mPlayer == null) return;
            startTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()),
                    TimeUnit.MILLISECONDS.toSeconds(mPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()))));
            int currentPosition = mPlayer.getCurrentPosition();
            voicePrgs.setProgress(currentPosition);
            hdlr.postDelayed(this, 200);
        }
    };

    void releasePlayer() {
        voicePrgs.setProgress(0);
        startTime.setText("00:00");
        voiceTime.setText("00:00");
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
        pauseBtn.setEnabled(false);
        pauseBtn.setVisibility(View.GONE);
        playBtn.setEnabled(true);
        playBtn.setVisibility(View.VISIBLE);
        hdlr.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}