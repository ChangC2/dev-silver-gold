package com.newhomepage.voicemail;

public interface ClickListener {
    void onClick(int index, int type);
}