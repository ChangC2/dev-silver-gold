package com.newhomepage.voicemail.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.koushikdutta.ion.ProgressCallback;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.GF;
import com.newhomepage.voicemail.GV;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.adapters.RPastVoicemailAdapter;
import com.newhomepage.voicemail.models.MOrder;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class PastVoicemailsActivity extends BaseActivity {

    RecyclerView recyclerView;

    RPastVoicemailAdapter adapter;
    private ArrayList<MOrder> orders = new ArrayList<>();

    private ImageButton pauseBtn, playBtn;
    private MediaPlayer mPlayer;
    private TextView startTime, voiceTime;
    private SeekBar voicePrgs;
    ProgressBar pBarLoading;
    private Handler hdlr = new Handler();
    AlertDialog dlg; //Player dialog
    int type = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_past_voicemails);
        type = getIntent().getIntExtra("type", 0);
        initUI();
        initButtonActions();
        apiCallForGetOrders();
    }

    private void initUI() {
        TextView txtTitle = findViewById(R.id.txt_title);
        if (type == 0){
            txtTitle.setText("Pending Orders");
        }else if (type == 1){
            txtTitle.setText("Scheduled Orders");
        }else{
            txtTitle.setText("Delivered Orders");
        }
        recyclerView = findViewById(R.id.recyclerView);
    }

    private void initButtonActions() {
        findViewById(R.id.imgBack).setOnClickListener(v -> finish());
    }


    private void setRecycler() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        ClickListener listener = new ClickListener() {
            @Override
            public void onClick(int index, int type) {
                switch (type) {
                    case 0:
                        onShowContent(index);
                        break;
                    case 1:
                        onView10(index);
                        break;
                    case 2:
                        apiCallForCancelOrder(index);
                        break;
                    default:
                        break;
                }
            }
        };
        adapter = new RPastVoicemailAdapter(this, orders, listener);
        recyclerView.setAdapter(adapter);
    }

    private void onShowContent(int index) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_player, null);
        dlg = new android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        dlg.setCanceledOnTouchOutside(false);
        TextView txtName = dialogView.findViewById(R.id.txtName);
        txtName.setText(orders.get(index).getType() == 0 ? "Play Recording" : "Voicemail Content");
        dialogView.findViewById(R.id.btnClose).setOnClickListener(v -> {
            if (mPlayer != null) {
                mPlayer.release();
                mPlayer = null;
            }
            hdlr.removeCallbacksAndMessages(null);
            dlg.dismiss();
        });
        pBarLoading = dialogView.findViewById(R.id.pBarLoading);
        txtName.setText(String.format("Recording : %s", orders.get(index).getRecord_name()));
        playBtn = (ImageButton) dialogView.findViewById(R.id.btnPlay);
        pauseBtn = (ImageButton) dialogView.findViewById(R.id.btnPause);
        pauseBtn.setEnabled(false);
        pauseBtn.setVisibility(View.GONE);
        startTime = (TextView) dialogView.findViewById(R.id.txtStartTime);
        voiceTime = (TextView) dialogView.findViewById(R.id.txtSongTime);
        voicePrgs = (SeekBar) dialogView.findViewById(R.id.sBar);
        voicePrgs.setClickable(false);
        pauseBtn.setEnabled(false);
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

        pBarLoading.setVisibility(View.VISIBLE);
        File audioFile = new File(getCacheDir(), "audio.wav");
        Ion.with(this)
                .load(orders.get(index).getUrl())
                .progress(new ProgressCallback() {
                    @Override
                    public void onProgress(long downloaded, long total) {
                        System.out.println("" + downloaded + " / " + total);
                    }
                })
                .write(audioFile)
                .setCallback(new FutureCallback<File>() {
                    @Override
                    public void onCompleted(Exception e, File file) {
                        pBarLoading.setVisibility(View.GONE);
                        if (mPlayer == null)
                            return; // When user finish this activity before download complete.
                        if (file != null && file.exists()) {
                            try {
                                mPlayer.setDataSource(file.getPath());
                                mPlayer.prepare(); // might take long! (for buffering, etc)
                            } catch (IllegalArgumentException exception) {
                                Toast.makeText(PastVoicemailsActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            } catch (IllegalStateException exception) {
                                Toast.makeText(PastVoicemailsActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            } catch (IOException exception) {
                                Toast.makeText(PastVoicemailsActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(PastVoicemailsActivity.this, "Fail to load.", Toast.LENGTH_LONG).show();
                        }
                    }
                });

        mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mPlayer.seekTo(0);
                onPauseAudio();
            }
        });
        mPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                onPlayAudio();
            }
        });

        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPlayAudio();
            }
        });

        pauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPauseAudio();
            }
        });
        if (orders.get(index).getType() == 0) {
            dialogView.findViewById(R.id.txtContent).setVisibility(View.GONE);
        } else {
            txtName.setText(String.format("AI Voice Avatar : %s", orders.get(index).getRecord_name()));
            dialogView.findViewById(R.id.txtContent).setVisibility(View.VISIBLE);
            ((TextView)dialogView.findViewById(R.id.txtContent)).setText(orders.get(index).getContent());
        }
        dlg.setCanceledOnTouchOutside(false);
        dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dlg.show();
    }

    private void onPlayAudio() {
        mPlayer.start();
        voiceTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()),
                TimeUnit.MILLISECONDS.toSeconds(mPlayer.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getDuration()))));
        startTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()),
                TimeUnit.MILLISECONDS.toSeconds(mPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()))));
        voicePrgs.setMax(mPlayer.getDuration());
        voicePrgs.setProgress(mPlayer.getCurrentPosition());
        hdlr.postDelayed(UpdateSongTime, 100);
        pauseBtn.setEnabled(true);
        pauseBtn.setVisibility(View.VISIBLE);
        playBtn.setEnabled(false);
        playBtn.setVisibility(View.GONE);
    }

    private void onPauseAudio() {
        mPlayer.pause();
        pauseBtn.setEnabled(false);
        pauseBtn.setVisibility(View.GONE);
        playBtn.setEnabled(true);
        playBtn.setVisibility(View.VISIBLE);
    }

    private Runnable UpdateSongTime = new Runnable() {
        @Override
        public void run() {
            if (mPlayer == null) return;
            startTime.setText(String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()),
                    TimeUnit.MILLISECONDS.toSeconds(mPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mPlayer.getCurrentPosition()))));
            int currentPosition = mPlayer.getCurrentPosition();
            voicePrgs.setProgress(currentPosition);
            hdlr.postDelayed(this, 100);
        }
    };

    private void onView10(int index) {
        Intent intent = new Intent(this, MailLogsActivity.class);
        intent.putExtra("order_id", orders.get(index).getId());
        startActivity(intent);
    }

    public void apiCallForGetOrders() {
        showLoading();
        String api = "";
        if (type == 0){
            api = C.getPendingOrders;
        }else if (type == 1){
            api = C.getScheduledOrders;
        }else{
            api = C.getDeliveredOrders;
        }
        Ion.with(this)
                .load(api)
                .setBodyParameter("token", App.getToken())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    Gson gson = new Gson();
                                    orders = gson.fromJson(jsonObject.getString("orders"), new TypeToken<ArrayList<MOrder>>() {
                                    }.getType());
                                    if (orders.size() > 0) {
                                        setRecycler();
                                    } else {
                                        showDlg("You don't have any items.", new ClickListener() {
                                            @Override
                                            public void onClick(int index, int type) {
                                                finish();
                                            }
                                        }, false);
                                    }
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    public void apiCallForCancelOrder(int index) {
        showLoading();
        Ion.with(this)
                .load(C.cancelOrder)
                .setBodyParameter("id", orders.get(index).getId())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null) {
                            showDlg(R.string.connection_fail, null, false);
                        } else {
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    orders.remove(index);
                                    adapter.setData(orders);
                                } else {
                                    showDlg(jsonObject.optString("message"), null, true);
                                }
                            } catch (JSONException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
        hdlr.removeCallbacksAndMessages(null);
        if (dlg != null && dlg.isShowing()) {
            dlg.dismiss();
            dlg = null;
        }
        super.onDestroy();
    }
}