package com.newhomepage.voicemail.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.DateUtil;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MVoice;

import java.util.ArrayList;


public class RVoiceAdapter extends RecyclerView.Adapter<RVoiceAdapter.ViewHolder> {

    Context mContext;
    private ArrayList<MVoice> voices = new ArrayList<>();
    private ClickListener listener;
    private int type = 0; // 0 : Your Cloned Voices, 1 : Pro Voices


    public RVoiceAdapter(Context context, ArrayList<MVoice> voices, ClickListener pListener, int type) {
        listener = pListener;
        mContext = context;
        this.voices.addAll(voices);
        this.type = type;
        notifyDataSetChanged();
    }

    public void setData(ArrayList<MVoice> voices) {
        this.voices.clear();
        this.voices.addAll(voices);
        notifyDataSetChanged();
    }

    // ******************************class ViewHoler redefinition ***************************//
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtName, txtTime, txtStatus;
        ImageView imgPlay, imgEdit, imgDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            txtStatus = itemView.findViewById(R.id.txtStatus);
            txtTime = itemView.findViewById(R.id.txtTime);
            imgPlay = itemView.findViewById(R.id.imgPlay);
            imgEdit = itemView.findViewById(R.id.imgEdit);
            imgDelete = itemView.findViewById(R.id.imgDelete);
        }

        public void setData(int position) {
            txtName.setText(voices.get(position).getName());
            txtStatus.setText(voices.get(position).getActive() == 0 ? "Processing" : "Approved");
            txtTime.setText(DateUtil.toStringFormat_2(DateUtil.parseDataFromFormat12(voices.get(position).getCreated_at())));
            imgEdit.setVisibility(type == 0 ? View.VISIBLE : View.GONE);
            imgDelete.setVisibility(type == 0 ? View.VISIBLE : View.GONE);
            imgPlay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 0);
                }
            });
            imgEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 1);
                }
            });
            imgDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(position, 2);
                }
            });
        }
    }

    // ******************************class ViewHoler redefinition ***************************//
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return  new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.recycler_voice, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, final int position) {
        Vholder.setData(position);
    }

    @Override
    public int getItemCount() {
        return voices.size();
    }
}
