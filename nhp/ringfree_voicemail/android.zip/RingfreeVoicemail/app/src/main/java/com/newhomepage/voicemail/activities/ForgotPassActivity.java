package com.newhomepage.voicemail.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.newhomepage.voicemail.App;
import com.newhomepage.voicemail.BaseActivity;
import com.newhomepage.voicemail.C;
import com.newhomepage.voicemail.R;

import org.json.JSONException;
import org.json.JSONObject;

public class ForgotPassActivity extends BaseActivity{

    EditText editEmail;
    EditText editPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDarkFullScreen();
        setContentView(R.layout.activity_forgot_pass);

        initUI();
        initButtonActions();
    }

    private void initUI(){
        editEmail = findViewById(R.id.editEmail);
        editEmail.setText("mzhou9954@gmail.com");
    }

    private void initButtonActions(){
        findViewById(R.id.btnReset).setOnClickListener(view-> onReset());
        findViewById(R.id.btnCancel).setOnClickListener(view->moveLogin());
    }

    private void onReset(){
        apiCallForResetPassword();
    }


    private void moveLogin(){
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void moveOTP(String email){
        showToastMessage(R.string.sent_verification);
        Intent intent = new Intent(this, RegisterOTPActivity.class);
        intent.putExtra("email", email);
        startActivity(intent);
        finish();
    }

    //***************************************//
    //             API Call Method           //
    //***************************************//

    void apiCallForResetPassword() {
        if (TextUtils.isEmpty(editEmail.getText())){
            showToastMessage(R.string.missing_param);
            return;
        }
        showLoading();
        Ion.with(this)
                .load(C.reset_password)
                .setBodyParameter("email", editEmail.getText().toString().trim())
                .asString()
                .setCallback(new FutureCallback<String>() {
                    @Override
                    public void onCompleted(Exception e, String result) {
                        hideLoading();
                        if (e != null){
                            showDlg(R.string.connection_fail, null, false);
                        }else{
                            try {
                                JSONObject jsonObject = new JSONObject(result);
                                if (jsonObject.getBoolean("status")) {
                                    App.setToken(jsonObject.getString("token"));
                                    moveOTP(editEmail.getText().toString().trim());
                                }else{
                                    showToastMessage(jsonObject.optString("message"));
                                }
                            } catch (JSONException jsonException) {
                                showDlg(R.string.connection_fail, null, false);
                            }
                        }
                    }
                });
    }

}