package com.newhomepage.voicemail;


public class GV {
    public static String forwarding_number = "";
    public static double credits = 0;
    public static double credits_to_send = 0;
    public static boolean isDeclined = false;
}
