package com.newhomepage.voicemail.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.newhomepage.voicemail.ClickListener;
import com.newhomepage.voicemail.R;
import com.newhomepage.voicemail.models.MContact;

import java.util.ArrayList;


public class RContactAdapter extends RecyclerView.Adapter<RContactAdapter.ViewHolder> {

    Context mContext;
    private ArrayList<MContact> contacts = new ArrayList<>();
    private ClickListener listener;


    public RContactAdapter(Context context, ArrayList<MContact> contacts, ClickListener pListener) {
        listener = pListener;
        mContext = context;
        this.contacts.addAll(contacts);
        notifyDataSetChanged();
    }

    public void setData(ArrayList<MContact> contacts) {
        this.contacts.clear();
        this.contacts.addAll(contacts);
        notifyDataSetChanged();
    }

    // ******************************class ViewHoler redefinition ***************************//
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtName, txtPhoneNumber, txtEmail, txtGroup;
        ImageView imgEdit, imgDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            txtPhoneNumber = itemView.findViewById(R.id.txtPhoneNumber);
            txtEmail = itemView.findViewById(R.id.txtEmail);
            txtGroup = itemView.findViewById(R.id.txtGroup);
            imgEdit = itemView.findViewById(R.id.imgEdit);
            imgDelete = itemView.findViewById(R.id.imgDelete);
        }

        public void setData(int position) {
            txtName.setText(contacts.get(position).getName());
            txtPhoneNumber.setText(String.format("Mobile Number : %s", contacts.get(position).getPhone()));
            txtEmail.setText(String.format("Email : %s", contacts.get(position).getEmail()));
            txtGroup.setText(String.format("Group : %s", contacts.get(position).getGroup_name()));
            imgEdit.setOnClickListener(v->listener.onClick(position, 0));
            imgDelete.setOnClickListener(v->listener.onClick(position, 1));
        }
    }

    // ******************************class ViewHoler redefinition ***************************//
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return  new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.recycler_contact, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, final int position) {
        Vholder.setData(position);
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }
}
