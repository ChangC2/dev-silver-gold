# d3-gantt-chart
Scrolling Zooming Gantt Chart with Hover

Resources used so far:

Most Basic Gantt Chart:
http://bl.ocks.org/dk8996/5449641